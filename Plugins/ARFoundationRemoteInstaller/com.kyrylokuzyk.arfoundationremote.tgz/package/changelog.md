## [1.4.18-release.1] - 2022-01-23
### Fixed
Fixed: the plugin throws AssertionException in ARFaceEditorMemorySafetyErrorFixer on every scene start with AR Foundation 4.1.9.
Fixed: platforms that don't support XRCameraSubsystem (pass-through video) like HoloLens throw an exception on scene start and don't create other subsystems because of it.

## [1.4.18-release.0] - 2022-01-10
### Added
- AR Foundation 5.0.0-pre.7 support.
- ARRaycastManager.Raycast() now supports TrackableType.Depth. The plugin blocks the main Unity Editor thread while performing the TrackableType.Depth raycast, so it's not suitable for calling every Update().
### Changed
- TrackableType.PlaneWithinInfinity is now **not** supported on Android to reflect the actual behavior of ARCore. Please see [this post](https://github.com/Unity-Technologies/arfoundation-samples/issues/893#issuecomment-953698353) for more info. 

## [1.4.17-release.0] - 2022-01-05 
### Added
- The plugin can now work with the disabled 'Project Settings/Editor/Enter Play Mode Settings/Reload Domain' setting.

## [1.4.16-release.1] - 2021-12-22
### Added
- If you don't have a macOS computer and want to develop an AR app for iOS on Windows, the AR Companion app can now be built with Unity Cloud Build.
### Fixed
- Fixed: the plugin uses Windows line endings to modify the AR Foundation package scripts, resulting in warnings during the first installation.

## [1.4.16-release.0] - 2021-12-09
### Added
- AR Foundation 5.0.0-pre.6 support.

## [1.4.15-release.2] - 2021-12-07
### Fixed
- Fixed: the plugin used the `\\` directory separator character on Windows in the manifest.json file, causing an import error on macOS and in Unity Cloud Build.

## [1.4.15-release.1] - 2021-12-02
### Added
- Check if a project's git repository is private to prevent people from accidentally adding the plugin to open-source projects.
### Fixed
- Fixed: the plugin adds itself to the .gitignore every time the project is re-imported. This caused issues with sharing the plugin in a team and caused Unity Cloud Build to fail.
- Fixed: the plugin throws errors when it's disabled in the 'XR Plugin Management' window and the 'Project Settings/Editor/Reload Domain' setting is also disabled.

## [1.4.15-release.0] - 2021-11-09
### Added
- Gyroscope support.
- Compass support.
- AR Foundation 5.0.0-pre.5 support.
- Added support for the new XRMeshSubsystem interface available in 2021.2, which allows providers to specify a separate transform for each mesh.
### Fixed
- Fixed: EnvironmentalHDR light estimation is not working.
- Fixed: AR Companion app throws an exception if ARKit Mesh Classification is set to false.

## [1.4.14-release.1] - 2021-10-27
### Fixed
- Fixed: the plugin doesn't work with Unity 2021.2 because a bug with IL2CPP and generic delegate methods.

## [1.4.14-release.0] - 2021-10-18
### Added
- Check [BinaryFormatter.Deserialize()](https://issuetracker.unity3d.com/issues/serialization-il2cpp-binaryformatter-dot-deserialize-method-fails-to-deserialize-a-nullable-struct-field-with-multiple-fields) bug in beta Unity versions 2021.2 and 2022.1.
- Send AR Companion app's errors back to the Editor.
### Changed
- The first XRCpuImage.Convert() now returns the correct result immediately, matching the behavior of ARCore/ARKit providers.
### Fixed
- Fix compilation error with AR Foundation 4.0.x.

## [1.4.13-release.3] - 2021-09-16
### Changed
- Upscale raw CPU image planes in the Editor to restore the original size.
### Fixed
- Fixed: camera CPU images are not working with AR Foundation 3.0.

## [1.4.13-release.1] - 2021-09-13
### Added
- Downscale support for raw CPU image planes.
### Changed
- Sync CPU images and camera video with camera pose.
### Fixed
- Fixed: TryAcquireEnvironmentDepthCpuImage is not working with AR Foundation 4.1.7.
- Fixed: Input.location.isEnabledByUser returns correct value with delay.
- Fixed: input remoting is not working in Unity 2021.1.12 because of changed number of parameters of UnityEngine.Input.SimulateTouch().

## [1.4.12-release.2] - 2021-08-27
### Changed
- Increase max network message size to support large image tracking libraries.
### Fixed
- Fixed compilation errors with AR Foundation 4.1.7.

## [1.4.12-release.0] - 2021-08-26
### Added
- Configuration Chooser support.
- Occlusion CPU images support.
- Sync camera pose with CPU images.

## [1.4.11-release.16] - 2021-08-17
### Changed
- Install plugin from tarball to speed up installation and prevent rare installation failures.

## [1.4.11-release.15] - 2021-08-13
### Added
- Add link to AR Foundation Remote 2.0.
### Changed
- Refine examples.

## [1.4.11-release.14] - 2021-08-09
### Fixed
- Fixed: simulated input is not working on UI elements in Unity 2021.1.
- Fixed: this plugin throws an exception if RenderTexture.active != null.

## [1.4.11-release.13] - 2021-08-05
### Fixed
- Fixed: Input Manager input simulation throws exception in Unity 2021.1.
- Fixed: plugin installer throws exception if AR Foundation package is not installed.

## [1.4.11-release.12] - 2021-08-04
### Fixed
- Fixed: plugin installation may fail under some conditions.

## [1.4.11-release.11] - 2021-08-02
### Changed
- Downgrade major version for compatibility with Version 2.0.
- Reduce AR Companion app's framerate while idle to reduce battery usage.
- Improve documentation.
### Fixed
- Fix touch simulation in Unity 2021.2.
- Add AR Foundation 4.0.1 features to CameraSubsystem descriptor.

## [4.11.10] - 2021-06-03
### Changed
- AR Foundation package embedding is now required.
- Android: don't apply displayMatrix to camera texture before sending it to Unity Editor.
### Fixed
- Fixed: Unity Editor is freezing after AR Companion installation.
- Fixed: sometimes meshing (ARMeshManager) is not working because Unity Package Manager reverts AR Foundation fixes before the AR Companion app build.
- Fixed: Camera background is not working in Unity >= 2020.3.6 and Android.
- Don't create plugin components if the plugin is not enabled in the XR Plugin Window.

## [4.11.3] - 2021-04-29
### Fixed
- Fixed: re-enabling AR subsystems can throw error.

## [4.11.0] - 2021-04-15
### Changed
- Send the whole image reference library to the AR Companion app only if required. This speeds up the startup of scenes with image tracking.
### Fixed
- Fixed: environment depth confidence texture is not working.
- Fixed: the plugin is not visible in the XR Plugin Management window after the installation in Unity 2020.2 or newer.
- Fixed: when performing ARRaycastManager.Raycast() simultaneously against planes and cloud points, the first hit result is empty.
- Fixed: Unity Cloud Build failing with plugin installed.

## [4.9.3] - 2021-03-02
### Added
- Location Services (GPS) support.
- Environment occlusion now supports AR Session Origin scaling.
### Fixed
- Fixed input remoting and simulation in Unity Editor 2019.2.
- Fixed: AR Companion can't start the server after resuming from the background.

## [4.8.22] - 2021-02-03
### Fixed
- Fixed camera video rendering in linear color space.
- Fixed null ref on SceneUnloaded event.
- Fixed two issues with image tracking: the 'editor image guid not found' and 'image already added'.
- Fixed: the plugin should not register subsystems if it's not enabled in XR Plugin Management.
- Fixed: 'Parameter name: _unity_self' error may occur after the meshing scene restart.

## [4.8.11] - 2021-01-20
### Added
- Added check for enabled 'Reload Domain' setting.
### Fixed
- Proper support for XRManagerSettings.InitializeLoader()/DeinitializeLoader().
- Fixed image tracking with disabled 'Keep Texture at Runtime' setting.

## [4.8.7] - 2021-01-16
### Added
- Companion app now can display contents of Editor Game Window!
### Fixed
- Fixed: Unity Editor freezes on the next scene start after unsuccessful connection attempt to companion app.
- Fixed camera video serialization on Android with URP.

## [4.7.11] - 2020-12-25
### Added
- Image reference libraries can now be embedded into AR Companion app.
### Fixed
- Fixed: ARAnchorManager.anchorsChanged event is not working, hence anchors are not working with ARKit World Map.
- Fixed: Camera CPU images are not working with Android and AR Foundation 4.0.x.
- Fixed: eye poses and fixation point have wrong values.

## [4.7.4] - 2020-12-12
### Added
- Camera CPU images support added.
- Send camera autofocus setting to AR Companion app.
- XRManagerSettings.DeinitializeLoader() support added.
- Device orientation can now be accessed in Editor via ARFoundationRemoteUtils.ScreenOrientation field.
### Fixed
- Fixed: setting camera configuration will fail because m_NativeConfigurationHandle was removed in version 4.6.9.
- Fixed: ARKit video shader for Windows Unity Editor doesn't contain human segmentation and environment depth textures.

## [4.6.9] - 2020-12-03
### Added
- Wikitude integration: support for camera raw image planes and camera intrinsics.
- Add ARFoundationRemote.Runtime.InputTracking.GetNodeStates().
### Changed
- Plugin now installs itself to Packages folder instead of the root project folder. This enables the plugin to work with Unity Collaborate and Unity Cloud Build.
- Documentation: image tracking on Android is unreliable with AR Foundation 4.0.x. Please use AR Foundation 3.x.x or AR Foundation 4.1.x of you experience issues with Image Tracking on Android.
- The plugin can now be installed into project without any AR Foundation packages present.
### Fixed
- Fixed: when companion app is open and is not connected to the Editor, it will still send AR data which results in a big message queue and produces long connection delays.
- Fixed: mesh colliders don't get updated while using Meshing.
- Fixed: Unity Editor crashes after calling LoaderUtility.Deinitialize() because of invalid XRTextureDescriptor.
- Fixed: when 'Initialize XR on Startup' is not enabled in 'XR Plug-in Management', Meshing will not work.

## [4.5.0] - 2020-11-10
### Added
- ARKit Object Tracking support.
- ARKit World Map support.
- Unity 2020.2 support.
### Fixed
- Fixed: Receiver is destroyed when unloading an AR scene which results in a lost connection to companion app.
- Fixed: TCP connection is not closing after stopping AR scene in Editor.
- 'Initialize XR on startup' setting is now not required for AR Companion app.
- Fixed: current camera configuration will sometimes not be restored to the initial value after closing AR scene in Editor.
- Fixed: light estimation is not working with AR Foundation >= 4.0.

## [4.4.2] - 2020-10-15
### Changed
- The plugin now installs from a local folder instead of a git repository. This removes the dependency on git and prevents people from accidentally committing plugin's source code to public repositories.
### Fixed
- Fixed: clear occlusion texture cache when occlusion settings change in runtime.
- Fixed: Meshing will not work after calling ARSessionOrigin.MakeContentAppearAt(). This method creates a new parent for ARMeshManager, but ARMeshManager requires to be a child of ARSessionOrigin.

## [4.3.4] - 2020-10-09
### Added
- ARKit 2D and 3D Body Tracking support.
- Camera configurations support.
- Face Tracking settings: you can disable unnecessary Face Tracking data to increase FPS.
### Changed
- Face indices and UVs are now cached. This reduces the amount of data and increases performance.
### Fixed
- Fixed mesh flickering while using Meshing.

## [4.2.3] - 2020-09-30
### Added
- AROcclusionManager support.
- ARKit depth/stencil human segmentation.
- ARKit/ARCore environment occlusion.
### Fixed
- Fixed Universal Render Pipeline support (was broken in version 3.11.3).
- Camera background video now works on iOS + Windows Unity Editor.

## [4.1.3] - 2020-09-21
### Changed
- Improve plugin performance by moving networking logic to background thread.
- Camera video settings can now be changed without making a new build of AR Companion app.
### Fixed
- Fixed minor Meshing bugs.

## [4.0.19] - 2020-09-14
### Fixed
- Fixed: sometimes the IP will not be shown in AR Companion app on Android.

## [4.0.17] - 2020-09-11
### Added
- ARMeshManager support.
- ARKit mesh classification support.
- ARAnchorManager support.
### Fixed
- Disable camera video in Windows Unity Editor 2019.2 to prevent crash.
- Fixed: UI Event System is not working after loading new AR scene at runtime.
- Fixed: BoundedPlane.center should be in local space coordinates instead of the world.
### Changed
- Plugin's settings were moved into Packages folder.
- Move GetBlendShapeCoefficients() to ARFoundationRemote.Runtime.FaceSubsystem to replicate ARKitFaceSubsystem interface.

## [3.11.3] - 2020-08-12
### Added
- Camera facing direction can now be changed at runtime by setting ARCameraManager.requestedFacingDirection.
### Changed
- All sender scenes combined into once scene.
- Increased max message size between Editor and AR Companion to be able to send bigger Reference Image Library to AR Companion.
### Fixed
- AR Companion IP address is not displayed if local network doesn't start from 192.168.
- 'Keep Texture at Runtime' is not required anymore for Image Tracking to work in Editor.

## [3.10.12] - 2020-08-01
### Changed
- Verbose Telepathy TCP logs can be enabled in plugin Settings.
### Fixed
- Port 7777 could be taken by other apps. The default port was changed and exposed in Settings.
- Fixed compilation error on iOS when face tracking is not installed.

## [3.10.8] - 2020-07-29
### Changed
- Unity's built-in PlayerConnection/EditorConnection has multiple limitations so it was replaced with Telepathy TCP solution.
- UPGRADE GUIDE: please make a new build of AR Companion app and enter device IP in settings.
### Fixed
- Camera background video is green when Color Space is set to Linear.
- Touch Input remoting fixes: touch phase Began was reported multiple times in a row; phase Update can be received in the same frame as Began and will overwrite it.
- Fixed Unity Editor crash when running on OpenGLES3 with AR Foundation < 4.0.2.
- Improved integration with Unity 2019.2.

## [3.9.10] - 2020-07-21
### Changed
- Improved image tracking quality.
### Fixed
- Null ref when creating empty runtime image library.

## [3.9.9] - 2020-07-17
### Added
- Light Estimation ambient spherical harmonics support.
- Universal Render Pipeline support.
### Fixed
- AR camera background now works in AR Foundation 4.0.2 or newer.

## [3.9.7] - 2020-07-14
### Changed
- Check the minimum required version of XR Plugins before installing the plugin.
- Minor documentation changes.

## [3.9.4] - 2020-07-13
### Fixed
- Fixed mirrored camera in Face Tracking on Android.
- Set camera autofocus to true for AR Foundation versions less than 4.
### Changed
- Touch input remoting now works seamlessly in Editor without any setup. Previously it was required to add this line on top of every script that used UnityEngine.Input: using Input = ARFoundationRemote.Input;
- Improved Face Tracking performance.

## [3.8.9] - 2020-07-04
### Added
- Editor camera background support.
- Light Estimation support.

## [3.7.1] - 2020-06-22
### Fixed
- Editor can't connect to ARCompanion app after making Android build on Windows.
- Face Tracking on Android throws null ref because of unsupported eye tracking.

## [3.7.0] - 2020-06-22
### Added
- ARRaycastManager support. Please use it instead of ARPlaneManager.Raycast() and ARPointCloudManager.Raycast().

## [3.6.2] - 2020-06-19
### Changed
- All sender scenes combined into one ARCompanion app.
### Fixed
- Fixed compilation errors in some versions of Unity.

## [3.5.6] - 2020-06-18
### Added
- Add scripting defines symbols automatically to simplify installation.
### Fixed
- Move reference image library out of Packages to fix Android build.
- Fixed compilation errors that appeared in Unity 2019.3.0.
### Changed
- Downgrade com.unity.xr.management dependency to v.3.0.3 to support seamless installation in Unity 2019.2. Unity 2019.3 or newer will install v.3.2.10 nevertheless.

## [3.5.2] - 2020-06-17
### Added
- Apply ARPointCloudManager.Append method fix automatically. This enables ARPointCloudManager.Raycast() to work in Editor.
### Fixed
- If sender scene build fails, project name and app id will not be restored to original values.
- Fix compilation error in Unity 2019.2.

## [3.5.1] - 2020-06-16
### Added
- Image Tracking.
- Multi-touch input remoting.
### Fixed
- Trackables have wrong positions when ARSessionOrigin in not located at zero position and has non-uniform scale. Fixed by using local positions instead of global (face, eyes, planes, point cloud).

## [3.3.5] - 2020-06-05
### Added
- ARKit Blendshapes.

## [3.2.0] - 2020-06-03
### Added
- Face Tracking (face mesh, face pose, eye tracking).
### Changed
- Separate scenes into sender and receiver scenes. This is done for backward compatibility with AR Foundation 3.0 (this version does not support changing camera facing direction).

## [3.1.3] - 2020-05-26
### Added
- Initial version of AR Foundation Editor Remote plugin.
- Plane Tracking.
- Depth Tracking.