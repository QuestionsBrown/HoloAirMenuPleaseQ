#if UNITY_EDITOR
using UnityEngine;


namespace ARFoundationRemote.Runtime {
    public class GyroscopeReceiver : MonoBehaviour {
        public static GyroscopeDataPlayer data { get; private set; }

        
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        static void register() {
            Utils.TryCreatePersistentEditorObject<GyroscopeReceiver>();
        }

        void OnEnable() {
            Connection.Register<GyroscopeDataPlayer>(_ => data = _);
        }

        void OnDisable() {
            Connection.UnRegister<GyroscopeDataPlayer>();
        }
    }
}
#endif
