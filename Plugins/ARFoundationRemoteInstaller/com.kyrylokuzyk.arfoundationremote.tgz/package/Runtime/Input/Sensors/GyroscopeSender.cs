using System;
using System.Diagnostics;
using UnityEngine;
using Debug = UnityEngine.Debug;


namespace ARFoundationRemote.Runtime {
    public class GyroscopeSender : MonoBehaviour {
        readonly Throttler throttler = new Throttler(() => 15);


        void OnEnable() {
            Connection.Register<GyroscopeDataEditor>(data => {
                if (data.enabled.HasValue) {
                    var gyroEnabled = data.enabled.Value;
                    UnityEngine.Input.gyro.enabled = gyroEnabled;
                    log($"set gyroEnabled to {gyroEnabled}, result: {UnityEngine.Input.gyro.enabled}");
                } else if (data.updateInterval.HasValue) {
                    var updateInterval = data.updateInterval.Value;
                    UnityEngine.Input.gyro.updateInterval = updateInterval;
                    log($"set updateInterval to {updateInterval}, result: {UnityEngine.Input.gyro.updateInterval}");
                } else {
                    throw new Exception();
                }
            });
        }

        void OnDisable() {
            Connection.UnRegister<GyroscopeDataEditor>();
        }

        void Update() {
            if (throttler.CheckIfAvailableAndRecordUsage()) {
                var gyro = UnityEngine.Input.gyro;
                Connection.Send(new GyroscopeDataPlayer {
                    attitude = QuaternionSerializable.Create(gyro.attitude),
                    gravity = Vector3Serializable.Create(gyro.gravity),
                    rotationRate = Vector3Serializable.Create(gyro.rotationRate),
                    userAcceleration = Vector3Serializable.Create(gyro.userAcceleration),
                    rotationRateUnbiased = Vector3Serializable.Create(gyro.rotationRateUnbiased),
                    acceleration = Vector3Serializable.Create(UnityEngine.Input.acceleration),
                    updateInterval = gyro.updateInterval,
                    gyroEnabled = gyro.enabled
                });
            }
        }
        
        
        [Conditional("_")]
        void log(string msg) {
            Debug.Log(msg);
        }
    }


    [Serializable]
    public struct GyroscopeDataEditor {
        public bool? enabled;
        public float? updateInterval;
    }


    [Serializable]
    public struct GyroscopeDataPlayer {
        public QuaternionSerializable attitude;
        public Vector3Serializable gravity;
        public Vector3Serializable rotationRate;
        public Vector3Serializable userAcceleration;
        public Vector3Serializable rotationRateUnbiased;
        public Vector3Serializable acceleration;
        public float updateInterval;
        public bool gyroEnabled;
    }
}
