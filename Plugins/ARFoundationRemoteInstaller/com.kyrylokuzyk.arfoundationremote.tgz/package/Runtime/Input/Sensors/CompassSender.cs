using System;
using System.Diagnostics;
using UnityEngine;
using Debug = UnityEngine.Debug;


namespace ARFoundationRemote.Runtime {
    public class CompassSender : MonoBehaviour {
        readonly Throttler throttler = new Throttler(() => 15);


        void OnEnable() {
            Connection.Register<CompassDataEditor>(_ => {
                var compassEnabled = _.compassEnabled;
                UnityEngine.Input.compass.enabled = compassEnabled;
                log($"set compass.enabled to {compassEnabled}, result: {UnityEngine.Input.compass.enabled}");
            });
        }

        void OnDisable() {
            Connection.UnRegister<CompassDataEditor>();
        }

        void Update() {
            if (throttler.CheckIfAvailableAndRecordUsage()) {
                var compass = UnityEngine.Input.compass;
                Connection.Send(new CompassDataPlayer {
                    compassEnabled = compass.enabled,
                    timestamp = compass.timestamp,
                    headingAccuracy = compass.headingAccuracy,
                    magneticHeading = compass.magneticHeading,
                    rawVector = Vector3Serializable.Create(compass.rawVector),
                    trueHeading = compass.trueHeading
                });
            }
        }
         
        
        [Conditional("_")]
        void log(string msg) {
            Debug.Log(msg);
        }
    }


    [Serializable]
    public struct CompassDataEditor {
        public bool compassEnabled;
    }


    [Serializable]
    public struct CompassDataPlayer {
        public bool compassEnabled;
        public double timestamp;
        public float headingAccuracy;
        public float magneticHeading;
        public Vector3Serializable rawVector;
        public float trueHeading;
    }
}
