using ARFoundationRemote.Runtime;
using JetBrains.Annotations;
using UnityEngine;


namespace ARFoundationRemote {
    public static partial class Input {
        public static readonly Gyroscope gyro = new Gyroscope();
        public static Vector3 acceleration {
            get {
                #if UNITY_EDITOR
                if (!UnityEditor.EditorApplication.isRemoteConnected) {
                    return GyroscopeReceiver.data.acceleration.Value;
                }
                #endif

                return UnityEngine.Input.acceleration;
            }
        }
    }
    
    
    public class Gyroscope {
        public bool enabled {
            [PublicAPI]
            get {
                #if UNITY_EDITOR
                if (!UnityEditor.EditorApplication.isRemoteConnected) {
                    return GyroscopeReceiver.data.gyroEnabled;
                }
                #endif

                return UnityEngine.Input.gyro.enabled;
            }
            set {
                #if UNITY_EDITOR
                if (!UnityEditor.EditorApplication.isRemoteConnected) {
                    Connection.Send(new GyroscopeDataEditor {
                        enabled = value
                    });
                    
                    return;
                }
                #endif

                UnityEngine.Input.gyro.enabled = value;
            }
        }

        public float updateInterval {
            get {
                #if UNITY_EDITOR
                if (!UnityEditor.EditorApplication.isRemoteConnected) {
                    return GyroscopeReceiver.data.updateInterval;
                }
                #endif
                
                return UnityEngine.Input.gyro.updateInterval;
            }
            [PublicAPI] set {
                #if UNITY_EDITOR
                if (!UnityEditor.EditorApplication.isRemoteConnected) {
                    Connection.Send(new GyroscopeDataEditor {
                        updateInterval = value
                    });
                    
                    return;
                }
                #endif

                UnityEngine.Input.gyro.updateInterval = value;
            }
        }

        public Quaternion attitude {
            get {
                #if UNITY_EDITOR
                if (!UnityEditor.EditorApplication.isRemoteConnected) {
                    return GyroscopeReceiver.data.attitude.Quaternion;
                }
                #endif

                return UnityEngine.Input.gyro.attitude;
            }
        }

        public Vector3 gravity {
            get {
                #if UNITY_EDITOR
                if (!UnityEditor.EditorApplication.isRemoteConnected) {
                    return GyroscopeReceiver.data.gravity.Value;
                }
                #endif

                return UnityEngine.Input.gyro.gravity;
            }
        }

        public Vector3 rotationRate {
            get 
            {
                #if UNITY_EDITOR
                if (!UnityEditor.EditorApplication.isRemoteConnected) {
                    return GyroscopeReceiver.data.rotationRate.Value;
                }
                #endif

                return UnityEngine.Input.gyro.rotationRate;
            }
        }

        public Vector3 userAcceleration {
            get {
                #if UNITY_EDITOR
                if (!UnityEditor.EditorApplication.isRemoteConnected) {
                    return GyroscopeReceiver.data.userAcceleration.Value;
                }
                #endif

                return UnityEngine.Input.gyro.userAcceleration;
            }
        }

        public Vector3 rotationRateUnbiased {
            get {
                #if UNITY_EDITOR
                if (!UnityEditor.EditorApplication.isRemoteConnected) {
                    return GyroscopeReceiver.data.rotationRateUnbiased.Value;
                }
                #endif

                return UnityEngine.Input.gyro.rotationRateUnbiased;
            }
        }
    }
}
