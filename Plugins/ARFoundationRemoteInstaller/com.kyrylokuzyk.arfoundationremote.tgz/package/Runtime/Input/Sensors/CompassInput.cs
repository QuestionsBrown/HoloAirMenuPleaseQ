using ARFoundationRemote.Runtime;
using JetBrains.Annotations;
using UnityEngine;


namespace ARFoundationRemote {
    public static partial class Input {
        public static readonly Compass compass = new Compass();
    }


    public class Compass {
        public bool enabled {
            [PublicAPI] get {
                #if UNITY_EDITOR
                if (!UnityEditor.EditorApplication.isRemoteConnected) {
                    return CompassReceiver.data.compassEnabled;
                }
                #endif

                return UnityEngine.Input.compass.enabled;
            }
            set {
                #if UNITY_EDITOR
                if (!UnityEditor.EditorApplication.isRemoteConnected) {
                    Connection.Send(new CompassDataEditor {
                        compassEnabled = value
                    });
                    
                    return;
                }
                #endif

                UnityEngine.Input.compass.enabled = value;
            }
        }

        public double timestamp {
            get {
                #if UNITY_EDITOR
                if (!UnityEditor.EditorApplication.isRemoteConnected) {
                    return CompassReceiver.data.timestamp;
                }
                #endif

                return UnityEngine.Input.compass.timestamp;
            }
        }

        public float headingAccuracy {
            get {
                #if UNITY_EDITOR
                if (!UnityEditor.EditorApplication.isRemoteConnected) {
                    return CompassReceiver.data.headingAccuracy;
                }
                #endif

                return UnityEngine.Input.compass.headingAccuracy;
            }
        }

        public float magneticHeading {
            get {
                #if UNITY_EDITOR
                if (!UnityEditor.EditorApplication.isRemoteConnected) {
                    return CompassReceiver.data.magneticHeading;
                }
                #endif

                return UnityEngine.Input.compass.magneticHeading;
            }
        }

        public Vector3 rawVector {
            get {
                #if UNITY_EDITOR
                if (!UnityEditor.EditorApplication.isRemoteConnected) {
                    return CompassReceiver.data.rawVector.Value;
                }
                #endif

                return UnityEngine.Input.compass.rawVector;
            }
        }

        public float trueHeading {
            get {
                #if UNITY_EDITOR
                if (!UnityEditor.EditorApplication.isRemoteConnected) {
                    return CompassReceiver.data.trueHeading;
                }
                #endif

                return UnityEngine.Input.compass.trueHeading;
            }
        }
    }
}
