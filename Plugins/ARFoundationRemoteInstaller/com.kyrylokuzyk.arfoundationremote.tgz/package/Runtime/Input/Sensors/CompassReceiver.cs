#if UNITY_EDITOR
using UnityEngine;


namespace ARFoundationRemote.Runtime {
    public class CompassReceiver : MonoBehaviour {
        public static CompassDataPlayer data { get; private set; }

        
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        static void register() {
            Utils.TryCreatePersistentEditorObject<CompassReceiver>();
        }

        void OnEnable() {
            Connection.Register<CompassDataPlayer>(_ => data = _);
        }

        void OnDisable() {
            Connection.UnRegister<CompassDataPlayer>();
        }
    }
}
#endif
