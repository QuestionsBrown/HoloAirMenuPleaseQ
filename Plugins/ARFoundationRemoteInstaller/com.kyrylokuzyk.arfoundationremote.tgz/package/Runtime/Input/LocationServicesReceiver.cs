#if UNITY_EDITOR
using JetBrains.Annotations;
using UnityEngine;


namespace ARFoundationRemote.Runtime {
    public class LocationServicesReceiver : MonoBehaviour {
        [CanBeNull] public static LocationDataPlayer locationData;


        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        static void register() {
             Utils.TryCreatePersistentEditorObject<LocationServicesReceiver>();
        }

        void OnEnable() {
            Connection.Register<LocationDataPlayer>(ReceiveLocationData);
        }

        public static void ReceiveLocationData(LocationDataPlayer data) {
            LocationServicesSender.log($"receive location data: {data.AllFieldsAndPropsToString()}");
            locationData = data;
        }

        void OnDisable() {
            Connection.UnRegister<LocationDataPlayer>();
        }
    }
}
#endif
