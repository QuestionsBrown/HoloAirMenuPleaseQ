using System;
using System.Collections.Generic;
using System.Linq;
using JetBrains.Annotations;
using UnityEngine;
using UnityEngine.Assertions;


namespace ARFoundationRemote.Runtime {
    [Serializable]
    public struct LegacyInputData {
        [NotNull] public TouchSerializable[] legacyTouches;

        
        public override string ToString() {
            return string.Join("\n\n", legacyTouches.Select(_ => _.AllFieldsAndPropsToString()));
        }
    }
    
    
    public class TouchesReceiver<T> where T: ITouch {
        readonly Dictionary<int, T> currentTouches = new Dictionary<int, T>();
        [CanBeNull] T[] currentFrameTouches;
        int lastUpdateFrame = -1;
        [NotNull] T[] touches = new T[0];

            
        [NotNull]
        public T[] Touches {
            get {
                updateTouchesIfNewFrame();
                return touches;
            }
        }
            
        void updateTouchesIfNewFrame() {
            var currentFrame = Time.frameCount;
            if (currentFrame != lastUpdateFrame) {
                lastUpdateFrame = currentFrame;
                touches = currentFrameTouches ?? new T[0];
                currentFrameTouches = null;
            }
        }
            
        public void Receive([NotNull] T[] receivedTouches) {
            if (!Defines.isLegacyInputManagerEnabled) {
                return;    
            }
            
            Assert.IsNull(currentFrameTouches);
            currentFrameTouches = receivedTouches;
            foreach (var touch in receivedTouches) {
                // Debug.Log($"receive {Time.time}, Time.frameCount: {Time.frameCount}, {touch.AllFieldsAndPropsToString()}");
                var id = touch.id;
                switch (touch.phase) {
                    case TouchPhase.Began:
                        currentTouches.Add(id, touch);
                        break;
                    case TouchPhase.Stationary:
                    case TouchPhase.Moved: {
                        Assert.IsTrue(currentTouches.ContainsKey(id));
                        currentTouches[id] = touch;
                        break;
                    }
                    case TouchPhase.Canceled:
                    case TouchPhase.Ended: {
                        var removed = currentTouches.Remove(id);
                        Assert.IsTrue(removed);
                        break;
                    }
                    default:
                        throw new Exception();
                }
            }
        }
    }
    
    
    public interface ITouch {
        int id { get; }
        TouchPhase phase { get; }
    }
    
    
    public static class TouchUtils {
        public static Vector2Serializable NormalizeByScreenSize(Vector2 v) {
            var result = new Vector2(v.x / Screen.width, v.y / Screen.height);
            return Vector2Serializable.Create(result);
        }

        public static Vector2 FromNormalizedToScreenPos(Vector2Serializable ser) {
            var v = ser.Value;
            return new Vector2(v.x * Screen.width, v.y * Screen.height);            
        }
    }
}
