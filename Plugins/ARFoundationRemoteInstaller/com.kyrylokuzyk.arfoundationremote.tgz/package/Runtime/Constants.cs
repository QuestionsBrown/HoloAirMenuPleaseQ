

namespace ARFoundationRemote.Runtime {
    public static class Constants {
        public const string packageName = "AR Foundation Remote";
        public static string silentStartupErrorsMessage => GetSilentLogMessage("Log Startup Errors");


        static string GetSilentLogMessage(string settingName) {
            return $"To silent this error, please disable the 'Settings/Debug Settings/{settingName}'.";
        }

        public const int simulatedMouseFingerId = 11;
        public const string version2_0_url = "https://assetstore.unity.com/packages/slug/201106";
    }
}
