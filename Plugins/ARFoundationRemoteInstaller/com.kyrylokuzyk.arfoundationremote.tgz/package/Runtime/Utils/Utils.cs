using JetBrains.Annotations;
using UnityEngine;
using UnityEngine.Assertions;


namespace ARFoundationRemote.Runtime {
    public static class Utils {
        #if UNITY_EDITOR
        [CanBeNull]
        public static T TryCreatePersistentEditorObject<T>() where T : Component {
            if (Global.IsPluginEnabled()) {
                return CreatePersistentObject<T>();
            } else {
                return null;
            }
        }
        #endif

        [CanBeNull]
        public static T TryCreatePersistentCompanionAppObject<T>() where T : Component {
            if (Defines.isARCompanionDefine && !Application.isEditor) {
                return CreatePersistentObject<T>();
            } else {
                return null;
            }
        }

        [NotNull]
        public static T CreatePersistentObject<T>() where T : Component {
            Assert.IsNull(Object.FindObjectOfType<T>());
            var go = new GameObject(typeof(T).Name);
            Object.DontDestroyOnLoad(go);
            go.transform.parent = GetOrCreatePersistentPluginParent();
            return go.AddComponent<T>();
        }

        [CanBeNull] static Transform persistentParent;
        
        [NotNull]
        static Transform GetOrCreatePersistentPluginParent() {
            if (persistentParent == null) {
                var go = new GameObject($"{Constants.packageName} Persistent");
                Object.DontDestroyOnLoad(go);
                persistentParent = go.transform;
            }
            
            return persistentParent;
        }
        
        public static bool isSessionRecordingPlayback() {
            #if UNITY_EDITOR && AR_FOUNDATION_REMOTE_2_0_OR_NEWER
            return Connection.receiverConnection is PlaybackReceiverConnection;
            #else
            return false;
            #endif
        }

        public static int divideWithoutRemainder(int a, int b, string debug = null) {
            Assert.AreEqual(0, a % b, $"can't divide without remainder, {debug}, {a}, {b}");
            return a / b;
        }
    }
}
