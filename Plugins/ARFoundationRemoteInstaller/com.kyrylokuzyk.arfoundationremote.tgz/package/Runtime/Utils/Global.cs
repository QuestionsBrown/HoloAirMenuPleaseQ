#if UNITY_EDITOR
using System.Collections.Generic;
using System.Linq;
using JetBrains.Annotations;
using UnityEditor;
using UnityEditor.XR.Management;
using UnityEngine;
using UnityEngine.XR.Management;


namespace ARFoundationRemote.Runtime {
    public static class Global {
        public static bool? IsInitialized;
        public static PlayModeStateChange? playModeState;


        public static bool IsPluginEnabled() {
            return Application.isEditor && isPluginEnabledInXRManagementWindow();
        }

        static bool isPluginEnabledInXRManagementWindow() {
            if (EditorBuildSettings.TryGetConfigObject(XRGeneralSettings.k_SettingsKey, out XRGeneralSettingsPerBuildTarget buildTargetSettings)) {
                var xrGeneralSettings = buildTargetSettings.SettingsForBuildTarget(BuildTargetGroup.Standalone);
                if (xrGeneralSettings != null) {
                    var xrManagerSettings = xrGeneralSettings.Manager;
                    if (xrManagerSettings != null) {
                        var loaders = getLoaders(xrManagerSettings);
                        if (loaders != null) {
                            // Debug.Log($"loaders: {string.Join(", ", loaders)}");
                            return loaders.Any(_ => _ != null && _.GetType().Name == "ARFoundationRemoteLoader");    
                        }
                    }
                }
            }

            return false;
        }

        [CanBeNull]
        static IReadOnlyList<XRLoader> getLoaders(XRManagerSettings manager) {
            return manager.
                #if XR_MANAGEMENT_4_0_1_OR_NEWER
                    activeLoaders;
                #else
                    loaders;
                #endif
        }
    }
}
#endif
