#if AR_FOUNDATION_5_0_OR_NEWER
    using ARSessionOrigin = Unity.XR.CoreUtils.XROrigin;
#else
    using UnityEngine.XR.ARFoundation;
#endif
using UnityEngine;


namespace ARFoundationRemote.Runtime {
    public static class XROriginExtensions {
        public static Transform GetTrackablesParent(this ARSessionOrigin origin) {
            return origin.
                #if AR_FOUNDATION_5_0_OR_NEWER
                TrackablesParent;
                #else
                trackablesParent;
                #endif
        }

        public static Camera GetCamera(this ARSessionOrigin origin) {
            return origin.
                #if AR_FOUNDATION_5_0_OR_NEWER
                Camera;
                #else
                camera;
                #endif
        }
    }
}
