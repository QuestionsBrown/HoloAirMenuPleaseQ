using System;
using UnityEngine;
using UnityEngine.Assertions;


namespace ARFoundationRemote.Runtime {
    public class Throttler {
        readonly float minFps;
        readonly Func<float> getMaxFps;
        float lastUsageTime;
        int lastUpdateFrame = -1;
        bool cachedCanUseThisFrame;


        public Throttler(Func<float> getMaxFps, float minFps = Settings.minFps) {
            Assert.IsTrue(minFps > 0);
            Assert.IsTrue(getMaxFps() > 0);
            Assert.IsTrue(minFps <= getMaxFps());
            this.getMaxFps = getMaxFps;
            this.minFps = minFps;
        }

        public void RecordUsage() {
            lastUsageTime = Time.time;
        }
        
        public bool CanUseThisFrame {
            get {
                if (lastUpdateFrame != Time.frameCount) {
                    lastUpdateFrame = Time.frameCount;
                    cachedCanUseThisFrame = Time.time - lastUsageTime > 1f / calculateTargetFps(LatencyMeasure.Instance.SmoothedLatency);
                }

                return cachedCanUseThisFrame;
            }
        }
        
        float calculateTargetFps(float curLatency) {
            var maxLatency = Settings.Instance.arCompanionSettings.maxLatency;
            var normalLatency = Settings.Instance.arCompanionSettings.normalLatency;
            return Mathf.Lerp(getMaxFps(), minFps, (curLatency - normalLatency) / (maxLatency - normalLatency));
        }

        public bool CheckIfAvailableAndRecordUsage() {
            if (CanUseThisFrame) {
                RecordUsage();
                return true;
            } else {
                return false;
            }
        }
    }
}
