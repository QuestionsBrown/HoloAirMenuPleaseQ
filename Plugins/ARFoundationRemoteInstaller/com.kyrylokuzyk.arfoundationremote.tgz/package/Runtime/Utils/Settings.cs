﻿using System;
using UnityEngine;
using UnityEngine.XR.ARSubsystems;


namespace ARFoundationRemote.Runtime {
    public class Settings : ScriptableObjectSingleton<Settings> {
        public const string maxFPSTooltip = "This sets only the upper bound. Actual FPS depend on the performance of your AR device.";
        public const float minFps = 0.5f;

        [Header("Connection Settings")]
        [SerializeField] public string ARCompanionAppIP = "192.168.0.";

        [Header("AR Companion Settings")] 
        [Tooltip("Please restart AR scene in Editor to apply settings. Building new AR Companion app is not required.")]
        [SerializeField] public ARCompanionSettings arCompanionSettings;

        [Tooltip("The plugin sends Editor Game View back to the companion app. Setting higher resolution scale will result in higher latency and lower frames-per-second.")]
        [SerializeField] 
        public EditorViewSettings editorGameViewSettings;

        [SerializeField] [HideInInspector] public PackageVersionData[] packages = new PackageVersionData[0];
        [SerializeField] [HideInInspector] public InputHandlingData inputHandlingData;

        [Header("Debug")] 
        [SerializeField] 
        public DebugSettings debugSettings;

        [Header("New AR Companion app build is required after modification.")] 
        [SerializeField] 
        public int port = 44819;

        [Space]
        [SerializeField] 
        public XRReferenceImageLibrary[] embeddedImageLibraries = new XRReferenceImageLibrary[0];
        

        public bool logStartupErrors => debugSettings.logStartupErrors;
        public bool showTelepathyLogs => debugSettings.showTelepathyLogs;
        public bool showTelepathyWarningsAndErrors => debugSettings.showTelepathyWarningsAndErrors;

        public static bool EnableBackgroundVideo => cameraVideoSettings.enableVideo;
        public static CameraVideoSettings cameraVideoSettings => Instance.arCompanionSettings.cameraVideoSettings;
        public static OcclusionSettings occlusionSettings => Instance.arCompanionSettings.occlusionSettings;
        public static FaceTrackingSettings faceTrackingSettings => Instance.arCompanionSettings.faceTrackingSettings;
    }


    [Serializable]
    public class ARCompanionSettings {
        public CameraVideoSettings cameraVideoSettings;
        public OcclusionSettings occlusionSettings;
        [Tooltip("Disable unnecessary face tracking features to increase FPS.")]
        [SerializeField] 
        public FaceTrackingSettings faceTrackingSettings;
        [SerializeField] public CpuImagePlaneMode CPUImagePlaneMode = CpuImagePlaneMode.Disabled;
        [SerializeField] [HideInInspector] public float maxLatency = 0.75f;
        [SerializeField] [HideInInspector] public float latencyReduceSpeed = 0.3f;
        [SerializeField] [HideInInspector] public float normalLatency = 0.25f;
        [Tooltip("Setting lower framerate will increase the AR Companion app's performance. " +
                 "Please keep in mind that some AR features (for examples, Face Tracking on Android) have framerate threshold under which these features will not work.")]
        [SerializeField]
        public int targetFrameRate = 30;
        
        
        public int cpuImagePlaneDownsample {
            get {
                switch (CPUImagePlaneMode) {
                    case CpuImagePlaneMode.FullSize:
                        return 1;
                    case CpuImagePlaneMode.HalfSize:
                        return 2;
                    case CpuImagePlaneMode.Fastest:
                        return 5;
                    default:
                        throw new Exception();
                }
            }
        }
    }


    [Serializable]
    public class FaceTrackingSettings {
        [Tooltip(Settings.maxFPSTooltip), Range(Settings.minFps, 60f)] 
        [SerializeField] public float maxFPS = 30;
        [SerializeField] public bool sendVertices = true;
        [SerializeField] public bool sendNormals = true;
        [SerializeField] public bool sendARKitBlendshapes = true;
    }
    

    [Serializable]
    public class CameraVideoSettings {
        [SerializeField] public bool enableVideo = true;
        [SerializeField] public bool syncCameraPoseWithVideo = true;
        [SerializeField, Range(.01f, 1f)] public float resolutionScale = 1f/3; 
        [SerializeField, Range(0, 100)] public int quality = 95;
        [SerializeField, Tooltip(Settings.maxFPSTooltip), Range(Settings.minFps, 30f)] public float maxVideoFps = 15;
        [SerializeField, Tooltip(Settings.maxFPSTooltip), Range(Settings.minFps, 30f)] public float maxCpuImagesFps = 15;
        [SerializeField, Tooltip(Settings.maxFPSTooltip), Range(Settings.minFps, 30f)] public float maxCameraIntrinsicsFps = 1;
    }


    public enum CpuImagePlaneMode {
        Disabled,
        Fastest,
        [InspectorName("Half Size (Recommended)")]
        HalfSize,
        FullSize
    }
    

    [Serializable]
    public class OcclusionSettings {
        [Tooltip(Settings.maxFPSTooltip), Range(Settings.minFps, 20f)] 
        [SerializeField] public float maxFPS = 10f;
        /// setting scale to 1 will clip the texture, don't know why
        /// also, this may cause companion app crashes
        [SerializeField] [Range(.01f, 0.95f)] public float resolutionScale = 1f/3;
    }
    
    
    [Serializable]
    public class DebugSettings {
        [SerializeField] public bool logStartupErrors = true;
        [SerializeField] public bool showTelepathyLogs;
        [SerializeField] public bool showTelepathyWarningsAndErrors = true;
        [SerializeField] public bool printCompanionAppIPsToConsole = true;
        [SerializeField] public bool warnIfReceiverConnectionWasDestroyed = false;
        [SerializeField] public bool overrideDisplayMatrix;
        [SerializeField] public Matrix4x4 displayMatrix;
        [SerializeField] public bool overrideProjectionMatrix;
        [SerializeField] public Matrix4x4 projectionMatrix;
        [SerializeField] public bool checkPackageVersions = true;
    }


    [Serializable]
    public class EditorViewSettings {
        [SerializeField] [Range(.01f, 1f)] public float resolutionScale = 1f/3;
        [Tooltip(Settings.maxFPSTooltip), Range(Settings.minFps, 30f)]
        public float maxEditorViewFps = 10;
    }
}
