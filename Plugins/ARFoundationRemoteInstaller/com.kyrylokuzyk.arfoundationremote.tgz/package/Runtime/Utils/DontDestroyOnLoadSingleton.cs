﻿using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;
using UnityEngine.Assertions;
using Debug = UnityEngine.Debug;


namespace ARFoundationRemote.Runtime {
    public class DontDestroyOnLoadSingleton : MonoBehaviour {
        public static List<string> runningCoroutineNames { get; } = new List<string>();

        static DontDestroyOnLoadSingleton instance;


        #if UNITY_EDITOR
            /// use <see cref="AddCoroutine"/> in player instead
            public static DontDestroyOnLoadSingleton Instance => getInstance();
        #endif

        static DontDestroyOnLoadSingleton getInstance() {
            if (instance == null) {
                instance = Utils.CreatePersistentObject<DontDestroyOnLoadSingleton>();
            }

            return instance;
        }
        
        public static void AddCoroutine(IEnumerator routine, string name) {
            getInstance().StartCoroutine(getInstance().countCoroutinesNumber(routine, name));
        }

        IEnumerator countCoroutinesNumber(IEnumerator routine, string debugName) {
            runningCoroutineNames.Add(debugName);
            logRunningCoroutines();
            while (routine.MoveNext()) {
                yield return routine.Current;
            }
            
            var removed = runningCoroutineNames.Remove(debugName);
            Assert.IsTrue(removed);
            logRunningCoroutines();
        }

        void logRunningCoroutines() {
            log($"running coroutines {runningCoroutineNames.Count}: {string.Join(", ", runningCoroutineNames)}");
        }
        
        [Conditional("_")]
        void log(string msg) {
            Debug.Log(msg);
        }
    }
}
