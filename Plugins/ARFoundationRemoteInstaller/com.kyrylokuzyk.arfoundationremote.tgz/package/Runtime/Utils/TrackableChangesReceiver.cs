﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using JetBrains.Annotations;
using Unity.Collections;
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.XR.ARSubsystems;
using Debug = UnityEngine.Debug;


namespace ARFoundationRemote.Runtime {
    public class TrackableChangesReceiver<T, V> where V : struct, ITrackable where T : ISerializableTrackable<V> {
        #if UNITY_2020_3_OR_NEWER // ItemNotNull may have appeared earlier than 2020.3, but I don't want to search for the specific version
        [ItemNotNull]
        #endif
        readonly Queue<TrackableChangesData<T>> queue = new Queue<TrackableChangesData<T>>();
        public readonly Dictionary<TrackableId, T> all = new Dictionary<TrackableId, T>();
        readonly bool debug;


        public TrackableChangesReceiver(bool debug = false) {
            this.debug = debug;
            log("TrackableChangesReceiverBase()");
        }
        
        public void Receive([CanBeNull] TrackableChangesData<T> data) {
            if (data != null) {
                queue.Enqueue(data);
            }
        }

        public void Receive([NotNull] T[] dataAdded, [NotNull] T[] dataUpdated, [NotNull] T[] dataRemoved) {
            queue.Enqueue(new TrackableChangesData<T> {
                added = dataAdded,
                updated = dataUpdated,
                removed = dataRemoved
            });
        }

        [Conditional("_")]
        void log(string msg, LogType logType = LogType.Log) {
            if (debug) {
                Debug.unityLogger.Log(logType, $"{typeof(V).Name}, {GetHashCode()}: " + msg);
            }
        }

        public void Reset() {
            Assert.IsFalse(Defines.UNITY_2020_2_OR_NEWER);
            log("Reset()");
            queue.Clear();
            all.Clear();
        }
        
        public TrackableChanges<V> GetChanges(Allocator allocator) {
            if (queue.Count == 0) {
                return new TrackableChanges<V>();
            }

            var data = queue.Dequeue();
            var updated = data.updated;
            foreach (var updatedItem in updated) {
                var id = updatedItem.trackableId;
                if (!all.ContainsKey(id)) {
                    Debug.LogWarning($"trackable {typeof(V)} {id} was updated but wasn't present in the 'all' dictionary. This can happen if a new subsystem provider was created in the same session.");
                    return new TrackableChanges<V>();
                }
                
                all[id] = updatedItem; // save the most recent trackable (update plane boundaries, etc.)
            }
            
            var added = data.added;
            foreach (var addedItem in added) {
                var id = addedItem.trackableId;
                all.Add(id, addedItem);
                log($"added {id}, {addedItem.AllFieldsAndPropsToString()}");
            }
       
            var removed = data.removed.Select(_ => _.trackableId).ToArray();
            foreach (var removedItemId in removed) {
                var isRemoved = all.Remove(removedItemId);
                Assert.IsTrue(isRemoved);
                log($"removed {removedItemId}");
            }
            
            Assert.IsTrue(updated.Select(_ => _.trackableId).All(all.ContainsKey));
            Assert.IsFalse(removed.Any(all.ContainsKey));
            if (added.Any() || removed.Any()) {
                // log($"GetChanges added: {added.Length}, updated: {updated.Length}, removed: {removed.Length}");
            }
            
            return TrackableChanges<V>.CopyFrom(
                new NativeArray<V>(added.Select(_ => _.Value).ToArray(), allocator),
                new NativeArray<V>(updated.Select(_ => _.Value).ToArray(), allocator),
                new NativeArray<TrackableId>(removed, allocator),
                allocator
            );
        }
    }
}
