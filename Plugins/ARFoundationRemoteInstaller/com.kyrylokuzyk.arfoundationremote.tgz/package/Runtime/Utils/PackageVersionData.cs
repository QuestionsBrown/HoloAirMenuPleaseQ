#if UNITY_EDITOR
    using UnityEditor.PackageManager;
    using System.Linq;
#endif
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Assertions;


namespace ARFoundationRemote.Runtime {
    [Serializable]
    public struct PackageVersionData {
        #pragma warning disable 649
        [SerializeField] string displayName;
        [SerializeField] string version;
        [SerializeField] string id;
        #pragma warning restore 649


        #if UNITY_EDITOR
        public static PackageVersionData[] Create(PackageCollection packages) {
            return new[] {
                    "com.kyrylokuzyk.arfoundationremote",
                    "com.unity.xr.arfoundation",
                    "com.unity.xr.arcore",
                    "com.unity.xr.arkit",
                    "com.unity.xr.arkit-face-tracking",
                    "com.kyrylokuzyk.arfoundationremote.arcoreextensions",
                    "com.unity.inputsystem",
                    "com.unity.xr.arsubsystems"
                }.Select(dep => packages.SingleOrDefault(_ => _.name == dep))
                .Where(_ => _ != null)
                .Select(_ => new PackageVersionData {displayName = _.displayName, version = _.version, id = _.name})
                .ToArray();
        }
        #endif

        public static bool CheckVersions(PackageVersionData[] companionAppPackages, PackageVersionData[] editorPackages) {
            var result = true;
            var log = "";
            var isPlayingBack = Utils.isSessionRecordingPlayback();
            foreach (var currentPackage in companionAppPackages) {
                var i = Array.FindIndex(editorPackages, _ => _.id == currentPackage.id);
                if (i != -1) {
                    var editorPackage = editorPackages[i];
                    if (currentPackage.version != editorPackage.version) {
                        var arDataSourceName = isPlayingBack ? "Session Record" : "AR Companion";
                        log += "Package version mismatch\n" +
                               $"{currentPackage.displayName}\n" +
                               $"{arDataSourceName}'s version: {currentPackage.version}\n" +
                               $"Editor version: {editorPackage.version}\n\n";
                        result = false;
                    }
                }
            }

            if (!result) {
                Assert.IsFalse(string.IsNullOrEmpty(log));
                if (isPlayingBack) {
                    const string arFoundationPackageId = "com.unity.xr.arfoundation";
                    var arfInRecording = singleOrNull(companionAppPackages, _ => _.id == arFoundationPackageId);
                    if (!arfInRecording.HasValue) {
                        Debug.LogError($"{Constants.packageName}: AR Foundation was not installed when session record was made.");
                        return false;
                    }
                    
                    var currentArf = singleOrNull(editorPackages, _ => _.id == arFoundationPackageId);
                    if (!currentArf.HasValue) {
                        Debug.LogError($"{Constants.packageName}: AR Foundation is not installed.");
                        return false;
                    }

                    if (parseUnityPackageManagerVersion(arfInRecording.Value.version) < new Version(5, 0) && parseUnityPackageManagerVersion(currentArf.Value.version) >= new Version(5, 0)) {
                        Debug.LogError($"{Constants.packageName}: incompatible AR Foundation versions, can't play session record correctly.\n{log}.");
                        return false;
                    }
                }
                
                var logType = isPlayingBack ? LogType.Warning : LogType.Error;
                var msg = isPlayingBack ? "Session Playback may be inconsistent." : "Please make a new build of AR Companion app to fix the error.";
                Debug.unityLogger.Log(logType, $"{Constants.packageName}: {msg}\n{log}");
            }
            
            return result;
        }

        static PackageVersionData? singleOrNull(PackageVersionData[] collection, Predicate<PackageVersionData> predicate) {
            var i = Array.FindIndex(collection, predicate);
            if (i == -1) {
                return null;
            } else {
                return collection[i];
            }
        }
        
        /// <see cref="ARFoundationRemoteInstaller.parseUnityPackageManagerVersion()"/>
        static Version parseUnityPackageManagerVersion(string version) {
            var versionNumbersStrings = version.Split('.', '-');
            const int numOfVersionComponents = 3;
            Assert.IsTrue(versionNumbersStrings.Length >= numOfVersionComponents);
            var numbers = new List<int>();
            for (int i = 0; i < numOfVersionComponents; i++) {
                var str = versionNumbersStrings[i];
                if (int.TryParse(str, out int num)) {
                    numbers.Add(num);
                } else {
                    throw new Exception("cant parse " + str + " in " + version);
                }
            }

            return new Version(numbers[0], numbers[1], numbers[2]);
        }

        public override string ToString() {
            return $"{displayName}: {version}";
        }
    }


    [Serializable]
    public struct InputHandlingData {
        public const string oldInputManagerName = "Input Manager (Old)";
        public const string inputSystemPackageName = "Input System Package (New)";
        
        [SerializeField] bool isLegacyInputManagerEnabled;
        [SerializeField] bool isNewInputSystemEnabled;


        public static InputHandlingData Create() {
            return new InputHandlingData {
                isLegacyInputManagerEnabled = Defines.isLegacyInputManagerEnabled,
                isNewInputSystemEnabled = Defines.isNewInputSystemEnabled
            };
        }

        public void AssertIsEqualTo(InputHandlingData other) {
            if (isLegacyInputManagerEnabled != other.isLegacyInputManagerEnabled) {
                logInputHandlingMismatch(oldInputManagerName);
            }

            if (isNewInputSystemEnabled != other.isNewInputSystemEnabled) {
                logInputHandlingMismatch(inputSystemPackageName);
            }
        }

        static void logInputHandlingMismatch(string inputHandlingMethod) {
            var isPlayingBack = Utils.isSessionRecordingPlayback();
            var logType = isPlayingBack ? LogType.Warning : LogType.Error;
            var arDataSourceName = isPlayingBack ? "Session Record" : "AR Companion";
            var msg = isPlayingBack ? "Session Playback may be inconsistent" : "Please make a new build of AR Companion app to fix the error";
            Debug.unityLogger.Log(logType, $"{Constants.packageName}: {msg}.\n'Active Input Handling' mismatch between {arDataSourceName} and Unity Editor, mismatch in: {inputHandlingMethod}.\n");
        }

        public override string ToString() {
            string result = "";
            if (isLegacyInputManagerEnabled) {
                result += $"{oldInputManagerName}";
            }

            if (isNewInputSystemEnabled) {
                result += $"\n{inputSystemPackageName}";
            }

            return result;
        }
    }
}
