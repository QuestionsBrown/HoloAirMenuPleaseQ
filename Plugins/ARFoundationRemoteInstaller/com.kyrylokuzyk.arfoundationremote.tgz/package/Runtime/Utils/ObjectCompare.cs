// credits: https://github.com/miptleha/cs-obj-compare/blob/master/Comparer.cs
using System;
using System.Linq;
using System.Reflection;
using JetBrains.Annotations;


namespace ARFoundationRemote.Runtime
{
    public static class Comparer
    {
        /// <summary>Returns description of difference or empty value if equal</summary>
        [CanBeNull]
        public static string CompareApprox(object obj1, object obj2, string path = "", params string[] ignoreFieldInfoPaths)
        {
            string path1 = string.IsNullOrEmpty(path) ? "" : path + ": ";
            if (obj1 == null && obj2 != null)
                return path1 + "null != not null";
            else if (obj2 == null && obj1 != null)
                return path1 + "not null != null";
            else if (obj1 == null && obj2 == null)
                return null;

            if (!obj1.GetType().Equals(obj2.GetType()))
                return "different types: " + obj1.GetType() + " and " + obj2.GetType();

            Type type = obj1.GetType();
            if (path == "")
                path = type.Name;

            if (obj1 is float f1) {
                var f2 = (float) obj2;
                if (Math.Abs(f1 - f2) > 0.05f) {
                    return path1 + "'" + obj1 + "' !~ '" + obj2 + "'";
                } else {
                    return null;
                }
            }
            if (type.IsPrimitive || typeof(string).Equals(type))
            {
                if (!obj1.Equals(obj2))
                    return path1 + "'" + obj1 + "' != '" + obj2 + "'";
                return null;
            }
            if (type.IsArray)
            {
                Array first = obj1 as Array;
                Array second = obj2 as Array;
                if (first.Length != second.Length)
                    return path1 + "array size differs (" + first.Length + " vs " + second.Length + ")";

                var en = first.GetEnumerator();
                int i = 0;
                while (en.MoveNext())
                {
                    string res = CompareApprox(en.Current, second.GetValue(i), path, ignoreFieldInfoPaths);
                    if (res != null)
                        return res + " (Index " + i + ")";
                    i++;
                }
            }
            else if (typeof(System.Collections.IEnumerable).IsAssignableFrom(type))
            {
                System.Collections.IEnumerable first = obj1 as System.Collections.IEnumerable;
                System.Collections.IEnumerable second = obj2 as System.Collections.IEnumerable;

                var en = first.GetEnumerator();
                var en2 = second.GetEnumerator();
                int i = 0;
                while (en.MoveNext())
                {
                    if (!en2.MoveNext())
                        return path + ": enumerable size differs";

                    string res = CompareApprox(en.Current, en2.Current, path, ignoreFieldInfoPaths);
                    if (res != null)
                        return res + " (Index " + i + ")";
                    i++;
                }
            }
            else
            {
                foreach (FieldInfo fi in type.GetFields(BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Public))
                {
                    var val = fi.GetValue(obj1);
                    var tval = fi.GetValue(obj2);
                    if (path.EndsWith("." + fi.Name))
                        return null;
                    var pathNew = (path.Length == 0 ? "" : path + ".") + fi.Name;
                    if (ignoreFieldInfoPaths != null && ignoreFieldInfoPaths.Any(pathNew.Contains)) {
                        // Debug.LogWarning($"ignore path {pathNew}");
                        return null;
                    }
                    
                    string res = CompareApprox(val, tval, pathNew, ignoreFieldInfoPaths);
                    if (res != null)
                        return res;
                }
            }
            return null;
        }
    }
}
