﻿#if UNITY_EDITOR
using System.Collections;
using System.Net;
using ARFoundationRemote.Runtime;
using Telepathy;
using UnityEngine.Assertions;
using Debug = UnityEngine.Debug;


namespace ARFoundationRemote.RuntimeEditor {
    // todoo batch editor messages to reduce network load and to unify the sender and receiver?
    public class TelepathyReceiverConnection : TelepathyConnection {
        readonly Client client = new Client();


        protected override IEnumerator startConnectionCor() {
            var ip = Settings.Instance.ARCompanionAppIP;
            if (!IPAddress.TryParse(ip, out _)) {
                Debug.LogError("Please enter correct AR Companion app IP in 'Project Settings/XR Plug-in Management/AR Foundation Remote'");
                yield break;
            }
            
            client.MaxMessageSize = maxMessageSize;
            client.Connect(ip, port);
            
            while (client.Connecting) {
                yield return null;
            }
            
            if (Settings.Instance.logStartupErrors && !isConnected_internal) {
                Debug.LogError($"{Constants.packageName}: connection to AR Companion app failed. Please check that:\n" +
                               "1. Unity Editor and AR Device are on the same Wi-Fi network.\n" +
                               "2. AR Companion is running and device is unlocked.\n" +
                               "3. The IP is correct in Assets/Plugins/ARFoundationRemoteInstaller/Resources/Settings\n\n" +
                               "If the connection is still failing, please try to configure your AR Device's Wi-Fi to have a static IP.\n" +
                               "iOS: https://www.mobi-pos.com/web/guide/settings/static-ip-configuration\n" +
                               "Android: https://service.uoregon.edu/TDClient/2030/Portal/KB/ArticleDet?ID=33742\n\n" +
                               "OR\n" +
                               "Try to create a hotspot on your AR device and then connect your computer to it.\n\n" +
                               "OR\n" +
                               "Try a wired connection (see Documentation).\n");
            }
        }

        protected override Common getCommon() {
            return client;
        }

        protected override bool isConnected_internal => client.Connected;

        public override void SendInstantly(object msg) {
            logSendInstantly(msg);
            Assert.IsNotNull(connectionDelegate);
            client.Send(msg);
        }
        
        protected override void onDestroyInternal() {
            client.Disconnect();
        }
    }
}
#endif
