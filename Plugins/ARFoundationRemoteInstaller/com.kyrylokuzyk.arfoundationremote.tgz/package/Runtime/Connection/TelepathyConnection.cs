﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using JetBrains.Annotations;
using UnityEngine;
using Telepathy;
using UnityEngine.Assertions;
using Debug = UnityEngine.Debug;
using EventType = Telepathy.EventType;


namespace ARFoundationRemote.Runtime {
    public abstract class TelepathyConnection : MonoBehaviour, IConnection {
        protected const int maxMessageSize = 1000 * 1024 * 1024;
        protected static int port => Settings.Instance.port;
        
        readonly Dictionary<Type, Action<object>> callbacks = new Dictionary<Type, Action<object>>();
        protected int connectionId = -1;
        protected IConnectionDelegate connectionDelegate;
        bool didStart;
        #pragma warning disable 649
        /// should be called before registered callback
        /// should be also called if a callback is not registered. This can happen for blocking message responses (for example, AnchorSubsystemMethodsResponse)
        /// should be called for blocking messages
        [CanBeNull] internal Action<object> onBeforeIncomingMessageProcessed;
        #pragma warning restore 649
        List<object> currentFrameMessages = new List<object>();
        readonly BlockingCallsFrequency blockingCallsFrequencyChecker = new BlockingCallsFrequency();


        protected abstract IEnumerator startConnectionCor();

        void IConnection.StartConnection(IConnectionDelegate del) {
            Assert.IsNull(connectionDelegate);
            Assert.IsNotNull(del);
            connectionDelegate = del;
            if (!didStart) {
                didStart = true;
                StartCoroutine(startConnectionCor());
                StartCoroutine(processIncomingMessagesCor());
            }
        }

        void Awake() {
            log($"{GetType().Name} {nameof(Awake)}()");
            if (Settings.Instance.showTelepathyLogs) {
                Telepathy.Logger.Log = Debug.Log;
            }

            if (Settings.Instance.showTelepathyWarningsAndErrors) {
                Telepathy.Logger.LogWarning = msg => {
                    if (!Application.isEditor) {
                        Sender.waitingErrorMessage += msg + "\n";
                    }

                    Debug.LogWarning(msg);
                };
                
                Telepathy.Logger.LogError = msg => {
                    Sender.waitingErrorMessage += msg + "\n";
                    Debug.LogError(msg);
                };
            }
        }

        IEnumerator Start() {
            var waitForEndOfFrame = new WaitForEndOfFrame();
            while (true) {
                yield return waitForEndOfFrame;
                if (currentFrameMessages.Any()) {
                    var batch = new MessagesFrameBatch(currentFrameMessages);
                    SendInstantly(batch);
                    currentFrameMessages = new List<object>(); // new instead of Clear() to not clear the MessagesFrameBatch.messages
                }
            }
        }

        [Conditional("_")]
        void log(string s) {
            Debug.Log(s);
        }

        void OnDestroy() {
            onDestroyInternal();
        }

        protected virtual void onDestroyInternal() { }

        IEnumerator processIncomingMessagesCor() {
            var waitForEndOfFrame = new WaitForEndOfFrame();
            var lastSimulatedFrame = -1;
            while (true) {
                yield return waitForEndOfFrame;
                if (lastSimulatedFrame != Time.frameCount) {
                    lastSimulatedFrame = Time.frameCount;
                    processIncomingMessages();
                }
            }
        }
        
        void processIncomingMessages() {
            if (connectionDelegate != null) {
                while (getCommon().GetNextMessage(out var msg)) {
                    var id = msg.connectionId;
                    switch (msg.eventType) {
                        case EventType.Connected:
                            connectionId = id;
                            connectionDelegate.OnConnected();
                            break;
                        case EventType.Data:
                            var message = msg.data;
                            Assert.IsNotNull(message);
                            if (message is MessagesFrameBatch batch) {
                                logIncomingMessage($"receive batch count {batch.messages.Count}");
                                foreach (var _ in batch.messages) {
                                    processIncomingMessage(_);
                                }
                            
                                return; // receive only one frame batch in one frame    
                            } else {
                                var blockingMessage = message as BlockingMessage;
                                Assert.IsNotNull(blockingMessage);
                                Assert.IsTrue(blockingMessage.blockingMessageGuid.HasValue);
                                if (!blockingMessage.isProcessed) {
                                    logIncomingMessage("receive");
                                    blockingMessage.isProcessed = true;
                                    processIncomingMessage(message);
                                }
                                
                                break;
                            }
                        case EventType.Disconnected:
                            Assert.AreEqual(connectionId, id);
                            connectionId = -1;
                            connectionDelegate.OnDisconnected();
                            outgoingMessageIndex = 0;
                            break;
                        default: 
                            throw new Exception();
                    }
                }
            }
        }

        void processIncomingMessage([NotNull] object message) {
            if (onBeforeIncomingMessageProcessed != null) {
                onBeforeIncomingMessageProcessed(message);
            }

            var type = message.GetType();
            if (callbacks.TryGetValue(type, out var callback)) {
                try {
                    callback(message);
                } catch (Exception e) {
                    Debug.LogError(e.ToString());
                }
            } else {
                // callback can be null if we Stop some AR subsystem without closing the AR scene entirely 
                // Debug.LogError($"callback is not registered for type {type}");
            }
        }

        protected abstract Common getCommon();
        bool IConnection.isConnected => isConnected_internal;
        protected abstract bool isConnected_internal { get; }

        void IConnection.Register<T>(Action<T> callback, bool unregisterOldCallbackIfDuplicate) {
            var type = typeof(T);
            if (unregisterOldCallbackIfDuplicate && callbacks.ContainsKey(type)) {
                unregister_internal<T>();
            }
            
            Assert.IsFalse(callbacks.ContainsKey(type));
            callbacks.Add(type, data => {
                Assert.IsTrue(data is T);
                callback((T) data);
            });
        }

        void IConnection.UnRegister<T>() {
            unregister_internal<T>();
        }

        void unregister_internal<T>() {
            var type = typeof(T);
            Assert.IsTrue(callbacks.ContainsKey(type));
            callbacks.Remove(type);
        }

        public void Send(object msg) {
            currentFrameMessages.Add(msg);
        }

        public abstract void SendInstantly(object msg);
     
        ResponseType IConnection.BlockUntilReceive<ResponseType>(Guid guid) {
            logBlockingMessage($"BlockUntilReceive {typeof(ResponseType)}, {guid}\n");
            blockingCallsFrequencyChecker.Check();
            Assert.AreNotEqual(guid, Guid.Empty);
            var stopwatch = Stopwatch.StartNew();
            while (true) {
                if (!isConnected_internal) {
                    throw new Exception($"{Constants.packageName}: please don't call blocking methods while AR Companion is not connected. " +
                                        "You can check if the AR Companion app is connected with this property: ARFoundationRemote.Runtime.Connection.Instance.isConnected");
                }
                
                const double timeoutInSeconds = 10;
                if (stopwatch.Elapsed > TimeSpan.FromSeconds(timeoutInSeconds)) {
                    throw new Exception($"{Constants.packageName}: BlockUntilReceive() timeout.");
                }

                foreach (var msg in getCommon().GetIncomingMessages()) {
                    if (msg.eventType == EventType.Data) {
                        var message = msg.data;
                        Assert.IsNotNull(message);
                        if (message is MessagesFrameBatch batch) {
                            foreach (var _ in batch.messages) {
                                if (checkMessage(_, out var _)) {
                                    throw new Exception("Blocking responses should not be sent via Batch");
                                }
                            }    
                        } else {
                            Assert.IsTrue(message is BlockingMessage blockingMessage && blockingMessage.blockingMessageGuid.HasValue, 
                                "message is BlockingMessage blockingMessage && blockingMessage.blockingMessageGuid.HasValue");
                            if (checkMessage(message, out var result)) {
                                if (onBeforeIncomingMessageProcessed != null) {
                                    onBeforeIncomingMessageProcessed(result);
                                }
                                
                                return result;
                            }
                        }

                        bool checkMessage(object o, out ResponseType result) {
                            if (o is BlockingMessage blockingMessage && blockingMessage.blockingMessageGuid == guid) {
                                Assert.IsFalse(blockingMessage.isProcessed);
                                blockingMessage.isProcessed = true;
                                Assert.IsTrue(blockingMessage is ResponseType, $"BlockUntilReceive expected type {typeof(ResponseType)}, but received {blockingMessage.GetType()}");
                                result = (ResponseType) blockingMessage;
                                return true;
                            } else {
                                result = default;
                                return false;
                            }
                        }
                    }
                }
            }
        }


        class BlockingCallsFrequency {
            readonly RollingFilter<object> rollingFilter = new RollingFilter<object>(1);
            
            public void Check() {
                rollingFilter.AddNewEntryAndRemoveOldEntries(null);
                if (rollingFilter.entries.Count > 20) {
                    Debug.LogError($"{Constants.packageName}: you're calling synchronous AR Foundation API too often.\n" +
                                   "When the synchronous AR Foundation API is called, the plugin blocks main Unity Editor thread and waits for AR Companion app's response. Examples:\n" +
                                   " - ARCameraManager.currentConfiguration \n" +
                                   " - ARCameraManager.GetConfigurations() \n" +
                                   " - ARAnchorManager.AddAnchor() \n" +
                                   " - ARAnchorManager.TryRemoveAnchor() \n" +
                                   " - ARRaycastManager.Raycast() \n" +
                                   "Please call synchronous API less frequently to prevent Editor freezes.\n");
                }
            }
        }


        #region debug
        static int outgoingMessageIndex;
        static int incomingMessageIndex;
        
        [Conditional("_")]
        protected void logSendInstantly(object msg) {
            if (msg is MessagesFrameBatch batch) {
                logOutgoingMessage($"send batch count {batch.messages.Count}");
                foreach (object _ in batch.messages) {
                    if (tryLogBlockingMessage(_)) {
                        throw new Exception("Blocking messages should not be sent in batches");
                    }
                }
            } else {
                logOutgoingMessage("send");
                tryLogBlockingMessage(msg);
            }

            bool tryLogBlockingMessage(object o) {
                if (o is BlockingMessage blockingMessage && blockingMessage.blockingMessageGuid.HasValue) {
                    logBlockingMessage($"{blockingMessage.GetType()}, {blockingMessage.blockingMessageGuid.Value}\n");
                    return true;
                } else {
                    return false;
                }
            }
        }

        [Conditional("_")]
        static void logBlockingMessage(string log) {
            Debug.Log(log);
        }

        [Conditional("_")]
        void logOutgoingMessage(string m) {
            Debug.Log($"{m}: {outgoingMessageIndex}");
            outgoingMessageIndex++;
        }
        
        [Conditional("_")]
        void logIncomingMessage(string m) {
            Debug.Log($"{m}: {incomingMessageIndex}");
            incomingMessageIndex++;
        }
        #endregion

        void IConnection.PauseConnection(IConnectionDelegate del) {
            Assert.AreEqual(connectionDelegate, del);
            connectionDelegate = null;
        }
    }
}
