﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using UnityEngine;
using Telepathy;
using UnityEngine.Assertions;


namespace ARFoundationRemote.Runtime {
    [Serializable]
    public class MessagesFrameBatch {
        public readonly List<object> messages;


        public MessagesFrameBatch(List<object> messages) {
            this.messages = messages;
        }
    }
    
    
    public class TelepathySenderConnection : TelepathyConnection {
        readonly Server server = new Server();


        [SuppressMessage("ReSharper", "IteratorNeverReturns")]
        protected override IEnumerator startConnectionCor() {
            server.MaxMessageSize = maxMessageSize;
            while (true) {
                if (!isActive) {
                    server.Start(port);
                }
                
                yield return new WaitForSeconds(1);
            }
        }

        protected override Common getCommon() {
            return server;
        }

        protected override bool isConnected_internal => Interlocked.CompareExchange(ref connectionId, 0, 0) != -1;

        public override void SendInstantly(object msg) {
            logSendInstantly(msg);
            server.Send(connectionId, msg);
        }

        public bool isActive => server.Active;

        protected override void onDestroyInternal() {
            server.Stop();
        }
    }
}
