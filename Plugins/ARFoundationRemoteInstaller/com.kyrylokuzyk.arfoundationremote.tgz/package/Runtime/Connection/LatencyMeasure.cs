using System;
using System.Collections;
using UnityEngine;


namespace ARFoundationRemote.Runtime {
    public class LatencyMeasure : MonoBehaviour {
        public static LatencyMeasure Instance { get; private set; }
        public float SmoothedLatency { get; private set; }

        float receivedLatency = Settings.Instance.arCompanionSettings.maxLatency / 2;
        float curLatency = Settings.Instance.arCompanionSettings.maxLatency / 2;
        bool requestRunning;


        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void register() {
            if (shouldCreate()) {
                Instance = Utils.CreatePersistentObject<LatencyMeasure>();
            }
        }

        static bool shouldCreate() {
            #if UNITY_EDITOR
            if (Application.isEditor) {
                return Global.IsPluginEnabled();
            }
            #endif

            return Defines.isARCompanionDefine;
        }

        void OnEnable() {
            Connection.Register<LatencyMeasureRequest>(request => {
                Connection.Send(new LatencyMeasureResponse(request));
            });
            
            Connection.Register<LatencyMeasureResponse>(response => {
                requestRunning = false;
                receivedLatency = response.request.TimeSinceCreated;
            });
        }

        void Awake() {
            StartCoroutine(measure());
        }

        void OnDisable() {
            Connection.UnRegister<LatencyMeasureRequest>();
            Connection.UnRegister<LatencyMeasureResponse>();
        }

        void Update() {
            var target = Mathf.Max(receivedLatency, curLatency);
            SmoothedLatency = Mathf.Max(target, Mathf.Lerp(SmoothedLatency, target, Time.deltaTime * Settings.Instance.arCompanionSettings.latencyReduceSpeed));
        }

        IEnumerator measure() {
            var waitForSeconds = new WaitForSeconds(0.5f);
            while (true) {
                while (!Connection.Instance.isConnected) {
                    yield return null;
                }

                yield return waitForSeconds;
                requestRunning = true;
                var request = new LatencyMeasureRequest();
                Connection.Send(request);

                while (true) {
                    if (!requestRunning) {
                        break;
                    }
                
                    if (!Connection.Instance.isConnected) {
                        requestRunning = false;
                        break;
                    }

                    curLatency = request.TimeSinceCreated; 
                    yield return null;
                }
            }
        }
    }


    [Serializable]
    public class LatencyMeasureRequest {
        readonly float timeCreated;
        
        
        public LatencyMeasureRequest() {
            timeCreated = curTime;
        }
        
        public float TimeSinceCreated => curTime - timeCreated;
        
        static float curTime => Time.realtimeSinceStartup;
    }
    
    
    [Serializable]
    public class LatencyMeasureResponse : BlockingMessage {
        public readonly LatencyMeasureRequest request;

        
        public LatencyMeasureResponse(LatencyMeasureRequest request) {
            this.request = request;
        }
    }
}
