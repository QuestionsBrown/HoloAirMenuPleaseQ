﻿using System;
using JetBrains.Annotations;
using UnityEditor;
using UnityEngine;
using UnityEngine.Assertions;
using Object = UnityEngine.Object;


namespace ARFoundationRemote.Runtime {
    public static class Connection {
        [CanBeNull] static TelepathySenderConnection _senderConnection;


        static TelepathySenderConnection senderConnection {
            get {
                if (Application.isEditor) {
                    throw new Exception("senderConnection getter in Editor!");
                }

                if (_senderConnection == null) {
                    _senderConnection = Utils.CreatePersistentObject<TelepathySenderConnection>();
                }

                return _senderConnection;
            }
        }

        public static bool IsSenderConnectionActive => senderConnection.isActive;

        #if UNITY_EDITOR
        static IConnection _receiverConnection;

        [NotNull]
        public static IConnection receiverConnection {
            get {
                // cast to UnityEngine.Object because Unity Engine uses custom null check
                //     plain C# object will still be alive on the second scene Play if Reload Domain is disabled
                if (_receiverConnection as Object == null) {
                    if (Global.playModeState != PlayModeStateChange.ExitingPlayMode) {
                        _receiverConnection = createReceiverConnection();
                    } else {
                        if (Settings.Instance.debugSettings.warnIfReceiverConnectionWasDestroyed) {
                            Debug.LogWarning($"{Constants.packageName}: receiverConnection was destroyed");
                        }
                    }
                }

                return _receiverConnection;
            }
        }

        static IConnection createReceiverConnection() {
            #if AR_FOUNDATION_REMOTE_2_0_OR_NEWER
            if (SessionRecordings.Instance.isRecording) {
                return Utils.TryCreatePersistentEditorObject<RecordingReceiverConnection>();
            } else if (SessionRecordings.Instance.playbackRecordedSession) {
                return Utils.TryCreatePersistentEditorObject<PlaybackReceiverConnection>();
            }
            #endif

            return Utils.TryCreatePersistentEditorObject<RuntimeEditor.TelepathyReceiverConnection>();
        }

        public static void ClearReceiverConnection() {
            _receiverConnection = null;
        }
        
        #if AR_FOUNDATION_REMOTE_2_0_OR_NEWER
        public static void TryRecordMessage(object msg) {
            if (receiverConnection is RecordingReceiverConnection recordingConnection) {
                recordingConnection.RecordPlayerMessage(msg);
            }
        }
        #endif
        #endif // UNITY_EDITOR

        public static ResponseType BlockUntilReceive<ResponseType>(BlockingMessage payload) where ResponseType : BlockingMessage {
            var guid = payload.CreateBlockingMessageGuid();
            Instance.SendInstantly(payload);
            return Instance.BlockUntilReceive<ResponseType>(guid);
        }

        public static IConnection Instance {
            get {
                #if UNITY_EDITOR
                if (Application.isEditor) {
                    return receiverConnection;
                }
                #endif

                return senderConnection;
            }
        }

        public static void Register<T>([NotNull] Action<T> callback, bool unregisterOldCallbackIfDuplicate = false) {
            Instance.Register(callback, unregisterOldCallbackIfDuplicate);
        }

        public static void UnRegister<T>() {
            Instance.UnRegister<T>();
        }

        public static void Send([NotNull] object msg) {
            if (!Application.isEditor && msg is BlockingMessage iguid) {
                Assert.IsFalse(iguid.blockingMessageGuid.HasValue, "Assert.IsFalse(iguid.guid.HasValue), use Connection.SendResponseInstantly() instead.");
            }

            #if UNITY_EDITOR
            if (Global.playModeState == PlayModeStateChange.ExitingPlayMode) {
                return;
            }
            #endif
            
            Instance.Send(msg);
        }

        public static void SendResponseInstantly([NotNull] BlockingMessage response, BlockingMessage request) {
            response.SetBlockingMessageGuid(request.GetBlockingMessageGuid());
            Instance.SendInstantly(response);
        }
    }
    
        
    [Serializable]
    public abstract class BlockingMessage {
        /// can have private setter, but it would require changing the path in <see cref="PlaybackReceiverConnection.ignorePathsInMessageCompare"/>
        public Guid? blockingMessageGuid;
        public bool isProcessed;

        public Guid CreateBlockingMessageGuid() {
            var result = Guid.NewGuid();
            SetBlockingMessageGuid(result);
            return result;
        }

        public void SetBlockingMessageGuid(Guid guid) {
            Assert.IsFalse(blockingMessageGuid.HasValue);
            Assert.AreNotEqual(Guid.Empty, guid);
            blockingMessageGuid = guid;
        }

        public Guid GetBlockingMessageGuid() {
            Assert.IsTrue(blockingMessageGuid.HasValue);
            Assert.AreNotEqual(Guid.Empty, blockingMessageGuid.Value);
            return blockingMessageGuid.Value;
        }
    }
    
    
    public interface IConnection {
        bool isConnected { get; }
        void Register<T>([NotNull] Action<T> callback, bool unregisterOldCallbackIfDuplicate);
        void UnRegister<T>();
        void Send([NotNull] object msg);
        void SendInstantly([NotNull] object msg);
        void StartConnection([NotNull] IConnectionDelegate del);
        void PauseConnection([NotNull] IConnectionDelegate del);
        ResponseType BlockUntilReceive<ResponseType>(Guid guid) where ResponseType : BlockingMessage;
    }
    

    public interface IConnectionDelegate {
        void OnConnected();
        void OnDisconnected();
    }
}
