﻿// incoming message queue of <connectionId, message>
// (not a HashSet because one connection can have multiple new messages)
// -> a struct to minimize GC
using ARFoundationRemote.Runtime;
using JetBrains.Annotations;


namespace Telepathy
{
    public readonly struct Message
    {
        public readonly int connectionId;
        public readonly EventType eventType;
        [CanBeNull] public readonly object data;
        
        public Message(int connectionId, EventType eventType, [CanBeNull] byte[] bytes)
        {
            this.connectionId = connectionId;
            this.eventType = eventType;
            if (bytes != null) {
                bytes.TryDeserialize(out data, true);
            } else {
                data = null;
            }
        }
    }
}
