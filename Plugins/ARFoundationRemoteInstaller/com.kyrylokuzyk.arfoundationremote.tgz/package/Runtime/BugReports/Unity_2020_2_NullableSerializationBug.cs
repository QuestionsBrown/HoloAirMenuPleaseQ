using UnityEngine.Assertions;
using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using JetBrains.Annotations;
using UnityEngine;


namespace ARFoundationRemote.Runtime.BugReports {
    public class Unity_2020_2_NullableSerializationBug : MonoBehaviour {
        const float dummyFloatValue = 123.456f;


        [CanBeNull]
        public static string CheckBug() {
            var serialized = serializeData();
            using (var memoryStream = new MemoryStream(serialized)) {
                var deserialized = (StructWithNullableField) new BinaryFormatter().Deserialize(memoryStream);
                return check(deserialized);
            }
        }

        static byte[] serializeData() {
            var instance = new StructWithNullableField {
                innerStruct = new InnerStruct {
                    floatValue = dummyFloatValue
                }
            };

            using (var memoryStream = new MemoryStream()) {
                new BinaryFormatter().Serialize(memoryStream, instance);
                return memoryStream.ToArray();
            }
        }

        [CanBeNull]
        static string check(StructWithNullableField deserialized) {
            var innerStruct = deserialized.innerStruct;
            Assert.IsTrue(innerStruct.HasValue);
            var deserializedFloatValue = innerStruct.Value.floatValue;
            if (!Mathf.Approximately(dummyFloatValue, deserializedFloatValue)) {
                return $"Unity {Application.unityVersion} has a bug that prevents the plugin from working correctly. Please follow this bug report to track the status:\n" +
                    "https://issuetracker.unity3d.com/issues/serialization-il2cpp-binaryformatter-dot-deserialize-method-fails-to-deserialize-a-nullable-struct-field-with-multiple-fields";
            } else {
                return null;
            }
        }


        [Serializable]
        struct StructWithNullableField {
            public InnerStruct? innerStruct;
        }


        [Serializable]
        struct InnerStruct {
            public float floatValue;
            [UsedImplicitly] public bool boolValue; // deserialization works ok without this field
        }
    }
}
