﻿#if ARFOUNDATION_4_0_2_OR_NEWER
using System;
using System.Collections;
using JetBrains.Annotations;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using System.Linq;
using UnityEngine.Assertions;
using UnityEngine.XR.ARSubsystems;


namespace ARFoundationRemote.Runtime {
    public class OcclusionSubsystemSender : MonoBehaviour {
        AROcclusionManager manager;
        bool isSending;
        Throttler throttler;

        
        void Awake() {
            throttler = new Throttler(() => Settings.occlusionSettings.maxFPS);
            manager = Sender.Instance.GetOrCreateOcclusionManager();
            manager.frameReceived += args => {
                if (!isSending && throttler.CanUseThisFrame && args.textures.Any() && CameraSubsystemSender.Instance.canRunAsyncConversion) {
                    throttler.RecordUsage();
                    // AR Companion will crash on scene reload if CpuImageSerializer is running
                    // DontDestroyOnLoadSingleton.AddCoroutine ensures that all coroutines are finished before calling scene reload
                    CameraSubsystemSender.Instance.AddAsyncConversionCoroutine(sendTextures(args), nameof(sendTextures));
                }
            };
        }

        IEnumerator sendTextures(AROcclusionFrameEventArgs args) {
            isSending = true;

            var descriptor = getDescriptor();
            Assert.IsNotNull(descriptor);
            var resolutionScale = Settings.occlusionSettings.resolutionScale;
            var humanStencilSerializer = new CpuImageSerializer(descriptor.supportsHumanSegmentationStencilImage(), () => manager.humanStencilTexture, manager.TryAcquireHumanStencilCpuImage, args, resolutionScale);
            var humanDepthSerializer = new CpuImageSerializer(descriptor.supportsHumanSegmentationDepthImage(), () => manager.humanDepthTexture, manager.TryAcquireHumanDepthCpuImage, args, resolutionScale);

            #if ARFOUNDATION_4_1_OR_NEWER
                var depthSerializer = new CpuImageSerializer(descriptor.supportsEnvironmentDepthImage(), () => manager.environmentDepthTexture, manager.TryAcquireEnvironmentDepthCpuImage, args, resolutionScale);
                var environmentDepthConfidenceSerializer = new CpuImageSerializer(descriptor.supportsEnvironmentDepthConfidenceImage(), () => manager.environmentDepthConfidenceTexture, manager.TryAcquireEnvironmentDepthConfidenceCpuImage, args, resolutionScale);
            #endif
            
            var serializers = new[] {
                humanStencilSerializer, 
                humanDepthSerializer, 
                #if ARFOUNDATION_4_1_OR_NEWER
                    depthSerializer, 
                    environmentDepthConfidenceSerializer
                #endif
            };
            
            while (serializers.Any(_ => !_.IsDone)) {
                yield return null;
            }

            if (Sender.isConnected) {
                Connection.Send(new OcclusionData {
                    humanStencil = humanStencilSerializer.result,
                    humanDepth = humanDepthSerializer.result
                });
                
                #if ARFOUNDATION_4_1_OR_NEWER
                Connection.Send(new OcclusionDataDepth {
                    environmentDepth = depthSerializer.result,
                    environmentDepthConfidence = environmentDepthConfidenceSerializer.result
                });
                #endif
            }

            isSending = false;
        }
     
        void OnEnable() {
            Connection.Register<OcclusionDataEditor>(occlusionData => {
                if (occlusionData.requestedHumanDepthMode.HasValue) {
                    manager.requestedHumanDepthMode = occlusionData.requestedHumanDepthMode.Value;
                }
            
                if (occlusionData.requestedHumanStencilMode.HasValue) {
                    manager.requestedHumanStencilMode = occlusionData.requestedHumanStencilMode.Value;
                }

                if (occlusionData.enableOcclusion.HasValue) {
                    Sender.Instance.SetManagerEnabled(manager, occlusionData.enableOcclusion.Value);
                }
            });
            
            #if ARFOUNDATION_4_1_OR_NEWER
            Connection.Register<OcclusionDataDepthEditor>(occlusionData => {
                if (occlusionData.requestedEnvironmentDepthMode.HasValue) {
                    manager.requestedEnvironmentDepthMode = occlusionData.requestedEnvironmentDepthMode.Value;
                }

                if (occlusionData.requestedOcclusionPreferenceMode.HasValue) {
                    manager.requestedOcclusionPreferenceMode = occlusionData.requestedOcclusionPreferenceMode.Value;
                }
            });            
            #endif
        }

        void OnDisable() {
            Connection.UnRegister<OcclusionDataEditor>();
            #if ARFOUNDATION_4_1_OR_NEWER
            Connection.UnRegister<OcclusionDataDepthEditor>();
            #endif
        }

        [CanBeNull]
        XROcclusionSubsystemDescriptor getDescriptor() => manager.descriptor;
    }


    [Serializable]
    public class OcclusionData {
        public SerializedTextureAndPropId? humanStencil;
        public SerializedTextureAndPropId? humanDepth;
    }

    
    #if ARFOUNDATION_4_1_OR_NEWER
    [Serializable]
    public class OcclusionDataDepth {
        public SerializedTextureAndPropId? environmentDepth;
        public SerializedTextureAndPropId? environmentDepthConfidence;
    }
    #endif

    
    [Serializable]
    public class OcclusionDataEditor {
        public HumanSegmentationDepthMode? requestedHumanDepthMode;
        public HumanSegmentationStencilMode? requestedHumanStencilMode;
        public bool? enableOcclusion;
    }
  
    
    #if ARFOUNDATION_4_1_OR_NEWER
    [Serializable]
    public class OcclusionDataDepthEditor {
        public EnvironmentDepthMode? requestedEnvironmentDepthMode;
        public OcclusionPreferenceMode? requestedOcclusionPreferenceMode;
    }
    #endif


    static class XROcclusionSubsystemDescriptorExtensions {
        public static bool supportsHumanSegmentationDepthImage([NotNull] this XROcclusionSubsystemDescriptor descriptor) {
            #if AR_SUBSYSTEMS_4_2_OR_NEWER || AR_FOUNDATION_5_0_OR_NEWER
            return descriptor.humanSegmentationDepthImageSupported != Supported.Unsupported;
            #endif

            #pragma warning disable
            return descriptor.supportsHumanSegmentationDepthImage;
            #pragma warning restore
        }
        
        public static bool supportsHumanSegmentationStencilImage([NotNull] this XROcclusionSubsystemDescriptor descriptor) {
            #if AR_SUBSYSTEMS_4_2_OR_NEWER || AR_FOUNDATION_5_0_OR_NEWER
            return descriptor.humanSegmentationStencilImageSupported != Supported.Unsupported;
            #endif

            #pragma warning disable
            return descriptor.supportsHumanSegmentationStencilImage;
            #pragma warning restore
        }
        
        #if ARFOUNDATION_4_1_OR_NEWER
        public static bool supportsEnvironmentDepthImage([NotNull] this XROcclusionSubsystemDescriptor descriptor) {
            #if AR_SUBSYSTEMS_4_2_OR_NEWER || AR_FOUNDATION_5_0_OR_NEWER
            return descriptor.environmentDepthImageSupported != Supported.Unsupported;
            #endif

            #pragma warning disable
            return descriptor.supportsEnvironmentDepthImage;
            #pragma warning restore
        }

        public static bool supportsEnvironmentDepthConfidenceImage([NotNull] this XROcclusionSubsystemDescriptor descriptor) {
            #if AR_SUBSYSTEMS_4_2_OR_NEWER || AR_FOUNDATION_5_0_OR_NEWER
            return descriptor.environmentDepthConfidenceImageSupported != Supported.Unsupported;
            #endif

            #pragma warning disable
            return descriptor.supportsEnvironmentDepthConfidenceImage;
            #pragma warning restore
        }
        #endif
    }
}
#endif
