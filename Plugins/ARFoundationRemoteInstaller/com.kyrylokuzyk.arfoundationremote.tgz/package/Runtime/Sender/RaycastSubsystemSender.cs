using System;
using System.Linq;
using Unity.Collections;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;


namespace ARFoundationRemote.Runtime {
    public class RaycastSubsystemSender : MonoBehaviour {
        ARRaycastManager manager;
        
        
        void Awake() {
            manager = Sender.Instance.origin.gameObject.AddComponent<ARRaycastManager>();
        }

        void OnEnable() {
            Connection.Register<RaycastRequest>(request => {
                var ray = new Ray(request.rayOrigin.Value, request.rayDirection.Value);
                var hits = manager.subsystem.Raycast(ray, request.trackableTypeMask, Allocator.Temp);
                using (hits) {
                    Connection.SendResponseInstantly(new RaycastResponse {
                        hits = hits.IsCreated ? hits.Select(XRRaycastHitSerializable.Create).ToArray() : new XRRaycastHitSerializable[0]
                    }, request);
                }
            });
        }

        void OnDisable() {
            Connection.UnRegister<RaycastRequest>();
        }
    }


    [Serializable]
    public class RaycastRequest : BlockingMessage {
        public Vector3Serializable rayOrigin;
        public Vector3Serializable rayDirection;
        public TrackableType trackableTypeMask;
    }


    [Serializable]
    public class RaycastResponse : BlockingMessage {
        public XRRaycastHitSerializable[] hits;
    }


    [Serializable]
    public struct XRRaycastHitSerializable {
        float distance;
        PoseSerializable pose;
        TrackableType hitType;
        TrackableIdSerializable trackableId;


        public static XRRaycastHitSerializable Create(XRRaycastHit _) {
            return new XRRaycastHitSerializable {
                distance = _.distance,
                pose = PoseSerializable.Create(_.pose),
                hitType = _.hitType,
                trackableId = TrackableIdSerializable.Create(_.trackableId)
            };
        }

        public XRRaycastHit Deserialize() {
            return new XRRaycastHit(trackableId.Value, pose.Value, distance, hitType);
        }
    }
}
