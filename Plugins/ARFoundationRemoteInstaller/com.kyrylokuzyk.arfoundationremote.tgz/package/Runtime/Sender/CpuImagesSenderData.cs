#if ARFOUNDATION_4_0_2_OR_NEWER
    using XRCameraImagePlane = UnityEngine.XR.ARSubsystems.XRCpuImage.Plane;
    using CameraImageFormat = UnityEngine.XR.ARSubsystems.XRCpuImage.Format;
    using XRCameraImageConversionParams = UnityEngine.XR.ARSubsystems.XRCpuImage.ConversionParams;
    using CameraImageTransformation = UnityEngine.XR.ARSubsystems.XRCpuImage.Transformation;
#else
    using XRCpuImage = UnityEngine.XR.ARSubsystems.XRCameraImage;
#endif
using System;
using System.Collections.Generic;
using System.Linq;
using JetBrains.Annotations;
using Unity.Collections;
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.XR.ARSubsystems;


namespace ARFoundationRemote.Runtime {
    [Serializable]
    public class ConvertedCpuImage : BlockingMessage {
        public readonly CpuImageType type;
        public readonly ConversionParamsSerializable conversionParams;
        [NotNull] public readonly byte[] bytes;

        public ConvertedCpuImage(CpuImageType type, ConversionParamsSerializable conversionParams, [NotNull] byte[] bytes) {
            this.type = type;
            this.conversionParams = conversionParams;
            this.bytes = bytes;
        }
    }
    

    [Serializable]
    public struct XRCpuImageSerializable {
        public int width { get; private set; }
        public int height { get; private set; }
        public int planeCount { get; private set; }
        public CameraImageFormat format { get; private set; }
        public double timestamp { get; private set; }
        [NotNull] public XRCpuImagePlaneSerializable?[] serializedPlanes { get; private set; }


        public static XRCpuImageSerializable Create(XRCpuImage i) {
            return new XRCpuImageSerializable {
                width = i.width,
                height = i.height,
                planeCount = i.planeCount,
                format = i.format,
                timestamp = i.timestamp,
                serializedPlanes = trySerializePlanes()
            };

            XRCpuImagePlaneSerializable?[] trySerializePlanes() {
                if (Settings.Instance.arCompanionSettings.CPUImagePlaneMode == CpuImagePlaneMode.Disabled) {
                    return new XRCpuImagePlaneSerializable?[0];
                }
                
                var serializedPlanes = i
                    .GetPlanes()
                    .Select(_ => _.HasValue ? XRCpuImagePlaneSerializable.Create(_.Value) : null)
                    .ToArray();

                Assert.AreEqual(i.planeCount, serializedPlanes.Length);
                return serializedPlanes;
            }
        }


        public override string ToString() {
            return $"{GetHashCode()}, ({width}, {height}), planeCount: {planeCount}, format: {format}, timestamp: {timestamp}, serializedPlanes: {serializedPlanes.Length}\n" +
                   $"{string.Join("\n", serializedPlanes)}";
        }
    }


    [Serializable]
    public struct XRCpuImagePlaneSerializable {
        public int rowStride { get; private set; }
        public int pixelStride { get; private set; }
        [NotNull] byte[] data;
        int downsample;
        public int originalDataLength { get; private set; }


        public static XRCpuImagePlaneSerializable? Create(XRCameraImagePlane plane) {
            var nativeData = plane.data; // data is a "view" into memory, no need to Dispose()
            if (nativeData.IsCreated) {
                var planeRowStride = plane.rowStride;
                var planePixelStride = plane.pixelStride;
                return new XRCpuImagePlaneSerializable {
                    rowStride = planeRowStride,
                    pixelStride = planePixelStride,
                    data = downsampleNativeData(nativeData, planeRowStride, planePixelStride, out var downsample),
                    downsample = downsample,
                    originalDataLength = nativeData.Length
                };
            } else {
                return null;
            }
        }

        [NotNull]
        static byte[] downsampleNativeData(NativeArray<byte> nativeData/*, int downsample*/, int rowStride, int pixelStride, out int downsample) {
            var origW = Utils.divideWithoutRemainder(rowStride, pixelStride);
            var origH = Mathf.RoundToInt((float) nativeData.Length / rowStride); // nativeData.Length is smaller by 1 for U and V textures on Android (maybe this is a _bug in ARCore), so I use RoundToInt 
            downsample = determineSupportedDownsample();
            Assert.IsTrue(downsample >= 1);
            if (downsample == 1) {
                return nativeData.ToArray();
            }
            
            var result = new byte[Utils.divideWithoutRemainder(origW * origH * pixelStride, downsample * downsample)];
            var diff = result.Length * downsample * downsample - nativeData.Length;
            Assert.IsTrue(diff <= 1, $"diff <= 1, {diff}");
            var downsampledRowStride = Utils.divideWithoutRemainder(rowStride, downsample, "rowStride, downsample");
            for (int i = 0; i < result.Length; i += pixelStride) {
                var rowNumber = i / downsampledRowStride;
                var columnNumber = i % downsampledRowStride;
                var inOriginalArray = downsample * (rowNumber * rowStride + columnNumber);
                for (int j = 0; j < pixelStride; j++) {
                    result[i + j] = nativeData[inOriginalArray + j];
                }
            }
            
            return result;

            int determineSupportedDownsample() {
                for (int i = Settings.Instance.arCompanionSettings.cpuImagePlaneDownsample; i > 0; i--) {
                    if (origW % i == 0 && origH % i == 0) {
                        return i;
                    }
                }

                throw new Exception();
            }
        }

        public NativeArray<byte> getData(Allocator allocator) {
            return upsample(allocator, downsample, data, rowStride, originalDataLength, pixelStride);
        }

        static NativeArray<byte> upsample(Allocator allocator, int downsample, byte[] data, int rowStride, int originalDataLength, int pixelStride) {
            Assert.IsTrue(downsample >= 1);
            if (downsample == 1) {
                return new NativeArray<byte>(data, allocator);
            }

            var downsampledRowStride = Utils.divideWithoutRemainder(rowStride, downsample, "rowStride, downsample");
            var downsampledHeight = Utils.divideWithoutRemainder(data.Length, downsampledRowStride);
            var expectedDataLength = rowStride * downsampledHeight * downsample;
            var diff = expectedDataLength - originalDataLength;
            // Debug.Log($"originalDataLength: {originalDataLength}, expectedDataLength: {expectedDataLength}, rowStride: {rowStride}, pixelStride: {pixelStride}, downsample: {downsample}");
            Assert.IsTrue(diff == 0 || diff == 1, "diff == 0 || diff == 1");
            var result = new NativeArray<byte>(expectedDataLength, allocator);
            // var sb = new StringBuilder();
            for (int i = 0; i < data.Length; i += pixelStride) {
                var rowNumber = i / downsampledRowStride;
                var columnNumber = i % downsampledRowStride;
                var inOriginalArray = downsample * (rowNumber * rowStride + columnNumber);
                for (int ps = 0; ps < pixelStride; ps++) {
                    var i0 = i + ps;
                    var b = data[i0];
                    for (int ux = 0; ux < downsample; ux++) {
                        for (int uy = 0; uy < downsample; uy++) {
                            var i1 = inOriginalArray + ux * pixelStride + uy * rowStride + ps;
                            // sb.Append($"{i0},{i1}   ");
                            result[i1] = b;
                        }
                    }
                }
            }

            // Debug.Log(sb.ToString());
            return result;
        }

        public override string ToString() {
            return $"{GetHashCode()}, ({rowStride}, {pixelStride}, downsample: {downsample}, originalDataLength: {originalDataLength}, data.Length: {data.Length})";
        }
    }


    public static class XRCpuImageExtensions {
        public static bool TryGetPlane(this XRCpuImage image, int index, out XRCameraImagePlane plane) {
            try {
                plane = image.GetPlane(index);
                return true;
            } catch (InvalidOperationException) {
                plane = default;
                return false;
            }
        }

        public static IEnumerable<XRCameraImagePlane?> GetPlanes(this XRCpuImage image) {
            for (int i = 0; i < image.planeCount; i++) {
                if (image.TryGetPlane(i, out var plane)) {
                    yield return plane;
                } else {
                    yield return null;
                }
            }
        }
    }


    [Serializable]
    public struct ConversionParamsSerializable {
        RectIntSerializable inputRect;
        Vector2IntSerializable outputDimensions;
        TextureFormat format;
        bool mirrorX, mirrorY;


        public static ConversionParamsSerializable Create(XRCameraImageConversionParams _) {
            return new ConversionParamsSerializable {
                inputRect = RectIntSerializable.Create(_.inputRect),
                outputDimensions = Vector2IntSerializable.Create(_.outputDimensions),
                format = _.outputFormat,
                mirrorX = _.transformation.HasFlag(CameraImageTransformation.MirrorX),
                mirrorY = _.transformation.HasFlag(CameraImageTransformation.MirrorY),
            };
        }

        public XRCameraImageConversionParams Deserialize() {
            return new XRCameraImageConversionParams {
                transformation = GetTransformation(mirrorX, mirrorY),
                inputRect = inputRect.Deserialize(),
                outputDimensions = outputDimensions.Deserialize(),
                outputFormat = format
            };
        }

        /// CameraImageTransformation enum has changed between different AR Foundation versions
        /// This method makes CameraImageTransformation compatible between different AR Foundation versions
        public  static CameraImageTransformation GetTransformation(bool mirrorX, bool mirrorY) {
            var result = CameraImageTransformation.None;
            if (mirrorX) {
                result |= CameraImageTransformation.MirrorX;
            }

            if (mirrorY) {
                result |= CameraImageTransformation.MirrorY;
            }

            return result;
        }

        public override string ToString() {
            return this.AllFieldsAndPropsToString();
        }
    }


    [Serializable]
    public struct RectIntSerializable {
        int x, y, w, h;
        
        public static RectIntSerializable Create(RectInt _) {
            return new RectIntSerializable {
                x = _.x,
                y = _.y,
                w = _.width,
                h = _.height
            };
        }

        public RectInt Deserialize() {
            return new RectInt(x, y, w, h);
        }
    }


    [Serializable]
    public struct Vector2IntSerializable {
        int x, y;
        
        public static Vector2IntSerializable Create(Vector2Int _) {
            return new Vector2IntSerializable {
                x = _.x,
                y = _.y
            };
        }

        public Vector2Int Deserialize() {
            return new Vector2Int(x, y);
        }
    }


    public static class CpuImageExtensions {
        public static
            #if !ARFOUNDATION_4_0_2_OR_NEWER
            unsafe
            #endif
            void ConvertSync(this XRCpuImage cpuImage, XRCameraImageConversionParams conversionParams, NativeArray<byte> buffer) {
            cpuImage.Convert(conversionParams, 
                #if ARFOUNDATION_4_0_2_OR_NEWER
                    buffer);
                #else
                    new IntPtr(Unity.Collections.LowLevel.Unsafe.NativeArrayUnsafeUtility.GetUnsafePtr(buffer)), buffer.Length);
                #endif
        }
    }
}
