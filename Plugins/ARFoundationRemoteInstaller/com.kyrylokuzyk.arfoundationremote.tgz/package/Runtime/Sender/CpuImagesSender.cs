#if ARFOUNDATION_4_0_2_OR_NEWER
    using UnityEngine.XR.ARSubsystems;
#else
    using XRCpuImage = UnityEngine.XR.ARSubsystems.XRCameraImage; 
#endif
using UnityEngine.Assertions;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using JetBrains.Annotations;
using Unity.Collections;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using Debug = UnityEngine.Debug;


namespace ARFoundationRemote.Runtime {
    public class CpuImagesSender : MonoBehaviour {
        public static CpuImagesSender Instance { get; private set; }
        readonly Dictionary<CpuImageType, CpuImageSender> senders = new Dictionary<CpuImageType, CpuImageSender>();
        ARCameraManager cameraManager;


        #if ARFOUNDATION_4_0_2_OR_NEWER
        AROcclusionManager occlusionManager;
        [CanBeNull] XROcclusionSubsystemDescriptor occlusionDescriptor => occlusionManager.descriptor;
        void Awake() {
            occlusionManager = Sender.Instance.GetOrCreateOcclusionManager();
            Assert.IsNotNull(occlusionManager);
        }
        #endif

        void OnEnable() {
            Instance = this;
            cameraManager = Sender.Instance.setuper.cameraManager;
            Connection.Register<CpuImageRequest>(request => getOrAddSender(request.type).OnCpuImageRequested(request));
        }
   
        void OnDisable() {
            StopAllCoroutines();
            Connection.UnRegister<CpuImageRequest>();
        }

        [NotNull]
        CpuImageSender getOrAddSender(CpuImageType type) {
            if (senders.TryGetValue(type, out var result)) {
                return result;
            } else {
                var newSender = createSender(type);
                senders.Add(type, newSender);
                return newSender;
            }
        }

        [NotNull]
        CpuImageSender createSender(CpuImageType type) {
            switch (type) {
                case CpuImageType.Camera:
                    return new CpuImageSender(type, () => cameraManager.descriptor?.supportsCameraImage == true, cameraManager.TryAcquireLatestCpuImageVersionAgnostic);
                #if ARFOUNDATION_4_0_2_OR_NEWER
                case CpuImageType.HumanDepth:
                    return new CpuImageSender(type, () => occlusionDescriptor?.supportsHumanSegmentationDepthImage() == true, occlusionManager.TryAcquireHumanDepthCpuImage);
                case CpuImageType.HumanStencil:
                    return new CpuImageSender(type, () => occlusionDescriptor?.supportsHumanSegmentationStencilImage() == true, occlusionManager.TryAcquireHumanStencilCpuImage);
                #endif
                #if ARFOUNDATION_4_1_OR_NEWER
                case CpuImageType.EnvironmentDepthConfidence:
                    return new CpuImageSender(type, () => occlusionDescriptor?.supportsEnvironmentDepthConfidenceImage() == true, occlusionManager.TryAcquireEnvironmentDepthConfidenceCpuImage);
                    #if !AR_FOUNDATION_4_2_OR_NEWER
                    case CpuImageType.SmoothedEnvironmentDepth:
                        return new CpuImageSender(type, () => occlusionDescriptor?.supportsEnvironmentDepthImage() == true, occlusionManager.TryAcquireEnvironmentDepthCpuImage);
                    #endif
                #endif
                #if AR_FOUNDATION_4_2_OR_NEWER
                case CpuImageType.SmoothedEnvironmentDepth:
                    return new CpuImageSender(type, () => occlusionDescriptor?.environmentDepthImageSupported != Supported.Unsupported, occlusionManager.TryAcquireSmoothedEnvironmentDepthCpuImage);
                case CpuImageType.RawEnvironmentDepth:
                    return new CpuImageSender(type, () => occlusionDescriptor?.environmentDepthImageSupported != Supported.Unsupported, occlusionManager.TryAcquireRawEnvironmentDepthCpuImage);
                #endif
                default:
                    throw new Exception($"Cpu image type is not supported: {type}");
            }
        }

        public void TrySendCpuImages() {
            foreach (var _ in senders.Values) {
                _.TrySend();
            }
        }
    }


    class CpuImageSender {
        readonly Throttler throttler = new Throttler(() => Settings.cameraVideoSettings.maxCpuImagesFps);
        readonly CpuImageType type;
        readonly Func<bool> isSupported;
        readonly TryAcquireCpuImageDelegate<XRCpuImage> acquireCpuImage;
        ConversionParamsSerializable? maybeSerializedConversionParams;
        float lastRequestTime;
        bool sentOnceAfterLastRequest;
        bool canSendFromUpdate;


        public CpuImageSender(CpuImageType type, Func<bool> isSupported, TryAcquireCpuImageDelegate<XRCpuImage> acquireCpuImage) {
            this.type = type;
            this.isSupported = isSupported;
            this.acquireCpuImage = acquireCpuImage;
            CpuImagesSender.Instance.StartCoroutine(waitForTheFirstImageAndReport());
        }

        IEnumerator waitForTheFirstImageAndReport() {
            logCpuImages($"waitForTheFirstImageAndReport() {type}");
            while (true) {
                if (acquireCpuImage(out var image)) {
                    image.Dispose();
                    logCpuImages($"send FirstCpuImageReceived {type}");
                    Connection.Send(new FirstCpuImageReceived {type = type});
                    yield break;
                }
                
                yield return null;
            }
        }
        
        public void OnCpuImageRequested(CpuImageRequest request) {
            logCpuImages($"OnCpuImageRequested {type}");
            lastRequestTime = Time.time;
            sentOnceAfterLastRequest = false;
            if (request.blockingMessageGuid.HasValue) {
                trySend(request.blockingMessageGuid.Value);
                canSendFromUpdate = true;
            } else if (request.conversionParams.HasValue) {
                logCpuImages($"receive conversionParams non-blocking {request.conversionParams.Value}");
                maybeSerializedConversionParams = request.conversionParams.Value;
            }
        }
        
        public bool TrySend() {
            logCpuImages("TrySend blockingRequestGuid");
            if (!canSendFromUpdate) {
                logCpuImages($"!canSendFromUpdate, {type}");
                return false;
            }
            
            if (!isSupported()) {
                Sender.AddRuntimeErrorOnce($"Cpu image type is not supported: {type}");
                return false;
            }

            if (!throttler.CanUseThisFrame) {
                return false;
            }
        
            const float cooldown = 2;
            if (sentOnceAfterLastRequest && Time.time - lastRequestTime > cooldown) {
                return false;
            }    

            return trySend();
        }

        bool trySend(Guid? blockingRequestGuid = null) {
            if (!acquireCpuImage(out var cpuImage)) {
                Sender.AddRuntimeErrorOnce("!acquireCpuImage(out var cpuImage)");
                return false;
            }

            if (!cpuImage.valid) {
                Sender.AddRuntimeError("!cpuImage.valid");
                return false;
            }

            using (cpuImage) {
                var cpuImageResponse = new CpuImageResponse {
                    type = type,
                    cpuImage = XRCpuImageSerializable.Create(cpuImage)
                };

                if (blockingRequestGuid.HasValue) {
                    logCpuImages($"send cpu image blocking {type}");
                    Connection.Instance.SendInstantly(new BlockingMessageContainer<CpuImageResponse>(blockingRequestGuid.Value, cpuImageResponse, out var payloadGuid));
                    var cpuImageRequest = Connection.Instance.BlockUntilReceive<BlockingMessageContainer<CpuImageRequest>>(payloadGuid).payload;
                    var conversionParams = cpuImageRequest.conversionParams;
                    if (conversionParams.HasValue) {
                        maybeSerializedConversionParams = conversionParams;
                        Connection.SendResponseInstantly(tryConvertImage(), cpuImageRequest);
                    }
                } else {
                    Connection.Send(cpuImageResponse);
                    var convertedCpuImage = tryConvertImage();
                    logCpuImages($"send cpu image non-blocking {type}, convertedCpuImage != null: {convertedCpuImage != null}");
                    if (convertedCpuImage != null) {
                        Connection.Send(convertedCpuImage);
                    }
                }

                throttler.RecordUsage();
                sentOnceAfterLastRequest = true;
                return true;

                ConvertedCpuImage tryConvertImage() {
                    if (!maybeSerializedConversionParams.HasValue) {
                        logCpuImages("tryConvertImage(), !maybeSerializedConversionParams.HasValue");
                        return null;
                    }

                    var serializedConversionParams = maybeSerializedConversionParams.Value;
                    var conversionParams = serializedConversionParams.Deserialize();
                    if (conversionParams.outputDimensions.x > cpuImage.width || conversionParams.outputDimensions.y > cpuImage.height) {
                        logCpuImages("tryConvertImage(), conversionParams.outputDimensions.x > cpuImage.width || conversionParams.outputDimensions.y > cpuImage.height");
                        return null;
                    }

                    var size = tryGetSize();
                    if (size.HasValue) {
                        using (var nativeArray = new NativeArray<byte>(size.Value, Allocator.Temp)) {
                            if (tryConvertSync()) {
                                return new ConvertedCpuImage(type, serializedConversionParams, nativeArray.ToArray());
                            }

                            bool tryConvertSync() {
                                try {
                                    cpuImage.ConvertSync(conversionParams, nativeArray);
                                    return true;
                                } catch (Exception e) {
                                    Debug.LogError($"tryConvertSync() failed: {e}");
                                    return false;
                                }
                            }
                        }
                    }

                    int? tryGetSize() {
                        try {
                            return cpuImage.GetConvertedDataSize(conversionParams);
                        } catch (Exception e) {
                            Debug.LogError($"tryGetSize() failed: {e}");
                            return null;
                        }
                    }

                    return null;
                }
            }
        }


        [Conditional("_")]
        static void logCpuImages(string msg) {
            Debug.Log($"{nameof(CpuImagesSender)}: {msg}");
        }
    }
    

    [Serializable]
    public class CpuImageRequest : BlockingMessage {
        public CpuImageType type;
        public ConversionParamsSerializable? conversionParams;
    }


    [Serializable]
    public class BlockingMessageContainer<T> : BlockingMessage, IBlockingMessageContainer where T: BlockingMessage {
        [NotNull] public readonly T payload;

        public BlockingMessageContainer(Guid responseGuid, [NotNull] T payload, out Guid payloadGuid) {
            Assert.IsFalse(payload.blockingMessageGuid.HasValue);
            payloadGuid = payload.CreateBlockingMessageGuid();
            this.payload = payload;
            SetBlockingMessageGuid(responseGuid);
        }

        Guid IBlockingMessageContainer.payloadBlockingMessageGuid => payload.GetBlockingMessageGuid();
    }


    public interface IBlockingMessageContainer {
        Guid payloadBlockingMessageGuid { get; }
    }


    [Serializable]
    public class CpuImageResponse : BlockingMessage {
        public CpuImageType type;
        public XRCpuImageSerializable cpuImage;
    }

    
    public enum CpuImageType {
        Camera,
        HumanDepth,
        HumanStencil,
        SmoothedEnvironmentDepth,
        RawEnvironmentDepth,
        EnvironmentDepthConfidence
    }
    

    public delegate bool TryAcquireCpuImageDelegate<TResult>(out TResult res);


    [Serializable]
    public struct FirstCpuImageReceived {
        public CpuImageType type;
    }
}
