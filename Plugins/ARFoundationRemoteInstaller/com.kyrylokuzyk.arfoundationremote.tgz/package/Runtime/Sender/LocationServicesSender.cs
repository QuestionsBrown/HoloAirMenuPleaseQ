using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using JetBrains.Annotations;
using UnityEngine;
using UnityEngine.Assertions;
using Debug = UnityEngine.Debug;
#if ENABLE_AR_FOUNDATION_REMOTE_LOCATION_SERVICES
    using LocationService = UnityEngine.LocationService;
    using LocationServiceStatus = UnityEngine.LocationServiceStatus;
#else
    using LocationService = ARFoundationRemote.LocationServiceRemote;
    using LocationServiceStatus = ARFoundationRemote.LocationServiceStatusDummy;
#endif


namespace ARFoundationRemote.Runtime {
    public class LocationServicesSender : MonoBehaviour {
        [CanBeNull] LocationDataPlayer locationData;

       
        void OnEnable() {
            Connection.Register<LocationDataEditor>(receiveLocationData);
            if (Defines.isAndroid && !Defines.isLegacyInputManagerEnabled && Defines.enableLocationServices) {
                Debug.LogError("Location Services do not work on Android if Input Manager (Old) is disabled.");
            }
        }

        void OnDisable() {
            Connection.UnRegister<LocationDataEditor>();
            if (Defines.enableLocationServices) {
                location.Stop();
            }
        }

        void receiveLocationData(LocationDataEditor request) {
            if (request.isStart) {
                log("location.Start()");
                if (Defines.isAndroid) {
                    RequestFineLocationPermission();
                }
                
                Assert.IsTrue(request.desiredAccuracyInMeters.HasValue);
                Assert.IsTrue(request.updateDistanceInMeters.HasValue);
                location.Start(request.desiredAccuracyInMeters.Value, request.updateDistanceInMeters.Value);
                tryUpdateLocationData();
                Assert.IsNotNull(locationData);
                Connection.SendResponseInstantly(locationData, request);
            } else {
                log("location.Stop();");
                location.Stop();
            }
        }

        public static void RequestFineLocationPermission() {
            #if ANDROID_JNI_INSTALLED
            UnityEngine.Android.Permission.RequestUserPermission(UnityEngine.Android.Permission.FineLocation);
            return;
            #endif
            
            #pragma warning disable 162
            Debug.LogError($"{Constants.packageName}: please install 'com.unity.modules.androidjni' via Package Manager/Built-in packages.");
            #pragma warning restore 162
        }

        void Update() {
            if (!Defines.enableLocationServices || !Sender.isConnected) {
                return;
            }

            if (tryUpdateLocationData()) {
                log("send location data");
                Assert.IsNotNull(locationData);
                Connection.Send(locationData);
            }
        }

        bool tryUpdateLocationData() {
            var newData = new LocationDataPlayer {
                status = location.status,
                lastData = location.status == LocationServiceStatus.Running ? LocationInfoSerializable.Create(location.lastData) : (LocationInfoSerializable?) null,
                isEnabledByUser = location.isEnabledByUser,
            };
            
            if (!newData.EqualsTo(locationData)) {
                locationData = newData;
                return true;
            } else {
                return false;
            }
        }

        static LocationService location {
            get {
                #if ENABLE_AR_FOUNDATION_REMOTE_LOCATION_SERVICES
                    return UnityEngine.Input.location;
                #else
                    throw new Exception(LocationServiceRemote.missingDefineError);;
                #endif
            }
        }
        
        
        [Conditional("_")]
        public static void log(string msg) {
            Debug.Log(msg);
        }
    }
    

    [Serializable]
    public class LocationDataPlayer : BlockingMessage {
        public LocationServiceStatus status;
        public LocationInfoSerializable? lastData;
        public bool isEnabledByUser;


        public bool EqualsTo([CanBeNull] LocationDataPlayer other) {
            if (other == null) {
                return false;
            }
            
            return other.status == status 
                   && other.lastData.Equals(lastData)
                   && other.isEnabledByUser == isEnabledByUser;
        }
    }


    [Serializable]
    [StructLayout(LayoutKind.Sequential)]
    public struct LocationInfoSerializable {
        [SerializeField] double m_Timestamp;
        [SerializeField] float m_Latitude;
        [SerializeField] float m_Longitude;
        [SerializeField] float m_Altitude;
        [SerializeField] float m_HorizontalAccuracy;
        [SerializeField] float m_VerticalAccuracy;

        
        public static LocationInfoSerializable Create(LocationInfo _) {
            return new Union {nonSerializable = _}.serializable;
        }

        public LocationInfo Deserialize() {
            return new Union {serializable = this}.nonSerializable;
        }
        
        [StructLayout(LayoutKind.Explicit)]
        struct Union {
            [FieldOffset(0)] public LocationInfoSerializable serializable;
            [FieldOffset(0)] public LocationInfo nonSerializable;
        }
    }
}
