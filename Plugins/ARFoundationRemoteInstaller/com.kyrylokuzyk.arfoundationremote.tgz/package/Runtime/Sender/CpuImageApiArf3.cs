#if !ARFOUNDATION_4_0_2_OR_NEWER
using UnityEngine.XR.ARSubsystems;
using CameraImagePlaneCinfo = ARFoundationRemote.Runtime.CameraImagePlaneCinfoWrapper;
using OnImageRequestCompleteDelegate = ARFoundationRemote.Runtime.OnImageRequestCompleteDelegateWrapper;
using System;
using System.Diagnostics.CodeAnalysis;
using UnityEngine;


namespace ARFoundationRemote.Runtime {
    [SuppressMessage("ReSharper", "UnusedMemberInSuper.Global")]
    public abstract class CpuImageApiArf3 {
        public abstract bool TryGetPlane(int nativeHandle, int planeIndex, out CameraImagePlaneCinfo planeCinfo);
        public abstract bool TryGetConvertedDataSize(int nativeHandle, Vector2Int dimensions, TextureFormat format, out int size);
        public abstract bool TryConvert(int nativeHandle, XRCameraImageConversionParams conversionParams, IntPtr destinationBuffer, int bufferLength);
        public abstract int ConvertAsync(int nativeHandle, XRCameraImageConversionParams conversionParams);
        public abstract void ConvertAsync(int nativeHandle, XRCameraImageConversionParams conversionParams, OnImageRequestCompleteDelegate callback, IntPtr context);
        public abstract bool NativeHandleValid(int nativeHandle);
        public abstract bool TryGetAsyncRequestData(int requestId, out IntPtr dataPtr, out int dataLength);
        public abstract void DisposeImage(int nativeHandle);
        public abstract void DisposeAsyncRequest(int requestId);
        public abstract AsyncCameraImageConversionStatus GetAsyncRequestStatus(int requestId);
    }


    public readonly struct CameraImagePlaneCinfoWrapper {
        public readonly IntPtr dataPtr;
        public readonly int dataLength;
        public readonly int rowStride;
        public readonly int pixelStride;

        
        public CameraImagePlaneCinfoWrapper(IntPtr dataPtr, int dataLength, int rowStride, int pixelStride) {
            this.dataPtr = dataPtr;
            this.dataLength = dataLength;
            this.rowStride = rowStride;
            this.pixelStride = pixelStride;
        }
    }
    
    
    public delegate void OnImageRequestCompleteDelegateWrapper(
        AsyncCameraImageConversionStatus status,
        XRCameraImageConversionParams conversionParams,
        IntPtr dataPtr,
        int dataLength,
        IntPtr context);


    public readonly struct CameraImageCinfoWrapper {
        public readonly int nativeHandle;
        public readonly Vector2Int dimensions;
        public readonly int planeCount;
        public readonly double timestamp;
        public readonly CameraImageFormat format;

        
        public CameraImageCinfoWrapper(int nativeHandle, Vector2Int dimensions, int planeCount, double timestamp, CameraImageFormat format) {
            this.nativeHandle = nativeHandle;
            this.dimensions = dimensions;
            this.planeCount = planeCount;
            this.timestamp = timestamp;
            this.format = format;
        }
    }
}
#endif
