#if ARFOUNDATION_4_0_2_OR_NEWER
using System;
using System.Linq;
using JetBrains.Annotations;
using Unity.Collections;
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.XR.ARSubsystems;


namespace ARFoundationRemote.Runtime {
    public class ConfigurationDescriptorsSender : MonoBehaviour {
        Feature? oldRequestedFeatures;
        

        void OnEnable() {
            Connection.Register<GetConfigurationDescriptorsRequest>(request => Connection.SendResponseInstantly(new GetConfigurationDescriptorsResponse(getDescriptorsOrEmptyArray()), request));
        }

        void OnDisable() {
            Connection.UnRegister<GetConfigurationDescriptorsRequest>();
        }

        [NotNull]
        ConfigurationDescriptorSerializable[] getDescriptorsOrEmptyArray() {
            Assert.IsNotNull(subsystem);
            var descriptors = subsystem.GetConfigurationDescriptors(Allocator.Temp);
            if (!descriptors.IsCreated) {
                return new ConfigurationDescriptorSerializable[0];
            }

            using (descriptors) {
                return descriptors
                    .Select(ConfigurationDescriptorSerializable.Create)
                    .ToArray();
            }
        }

        void Update() {
            sendRequestedFeatures();
        }

        void sendRequestedFeatures() {
            if (subsystem == null) {
                return;
            }

            var newRequestedFeatures = subsystem.requestedFeatures;
            if (newRequestedFeatures != oldRequestedFeatures) {
                oldRequestedFeatures = newRequestedFeatures;
                Connection.Send(new RequestedFeatures {
                    features = newRequestedFeatures
                });
            }
        }

        [CanBeNull] static XRSessionSubsystem subsystem => Sender.Instance.arSession.subsystem;
    }
    
    
    [Serializable]
    public class GetConfigurationDescriptorsRequest : BlockingMessage {
    }


    [Serializable]
    public struct ConfigurationDescriptorSerializable {
        IntPtr identifier;
        Feature capabilities;
        int rank;


        public static ConfigurationDescriptorSerializable Create(ConfigurationDescriptor d) {
            return new ConfigurationDescriptorSerializable {
                identifier = d.identifier,
                capabilities = d.capabilities,
                rank = d.rank
            };
        }

        internal ConfigurationDescriptor Deserialize() {
            return new ConfigurationDescriptor(identifier, capabilities, rank);
        }
    }


    [Serializable]
    public class GetConfigurationDescriptorsResponse : BlockingMessage {
        [NotNull] readonly ConfigurationDescriptorSerializable[] descriptors;


        public GetConfigurationDescriptorsResponse([NotNull] ConfigurationDescriptorSerializable[] descriptors) {
            this.descriptors = descriptors;
        }

        [NotNull]
        public ConfigurationDescriptor[] Deserialize() {
            return descriptors.Select(_ => _.Deserialize()).ToArray();
        }
    }


    [Serializable]
    public struct RequestedFeatures {
        public Feature features;
    }
}
#endif
