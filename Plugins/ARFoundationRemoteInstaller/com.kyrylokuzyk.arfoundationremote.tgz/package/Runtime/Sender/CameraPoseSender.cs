﻿using System;
using JetBrains.Annotations;
using UnityEngine;


namespace ARFoundationRemote.Runtime {
    public class CameraPoseSender : MonoBehaviour {
        readonly Throttler throttler = new Throttler(() => 15, 3);
        Transform cameraTransform;
        [CanBeNull] public static CameraPoseSender Instance { get; private set; }

        
        void Awake() {
            Instance = this;
            cameraTransform = FindObjectOfType<Sender>().origin.GetCamera().transform;
        }

        void LateUpdate() {
            if (!Settings.cameraVideoSettings.syncCameraPoseWithVideo && Sender.isConnected && throttler.CheckIfAvailableAndRecordUsage()) {
                SendCameraPose();
            }
        }

        public void SendCameraPose() {
            throttler.RecordUsage();
            Connection.Send(new CameraPoseData {
                position = Vector3Serializable.Create(cameraTransform.localPosition),
                rotation = QuaternionSerializable.Create(cameraTransform.localRotation)
            });
        }
    }


    [Serializable]
    public struct CameraPoseData {
        public Vector3Serializable position;
        public QuaternionSerializable rotation;
    }
}
