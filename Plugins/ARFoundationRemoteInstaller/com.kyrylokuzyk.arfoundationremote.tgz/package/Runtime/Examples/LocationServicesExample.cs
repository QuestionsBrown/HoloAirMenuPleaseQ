using ARFoundationRemote;
using UnityEngine;
using ARFoundationRemote.Runtime;
using Input = ARFoundationRemote.Input; // THIS LINE IS REQUIRED FOR LOCATION SERVICES TO WORK WITH AR FOUNDATION EDITOR REMOTE
#if !ENABLE_AR_FOUNDATION_REMOTE_LOCATION_SERVICES
    using LocationServiceStatus = ARFoundationRemote.LocationServiceStatusDummy;
#endif


namespace ARFoundationRemoteExamples {
    public class LocationServicesExample : MonoBehaviour {
        [SerializeField] float desiredAccuracyInMeters = 10f;
        [SerializeField] float updateDistanceInMeters = 10f;
        [SerializeField] int fontSize = 35;

        [Header("Location data (read-only)")]
        [SerializeField] bool isEnabledByUser;
        [SerializeField] LocationServiceStatus status;
        [SerializeField] LocationInfoSerializable lastData;


        void Awake() {
            if (Defines.isAndroid) {
                LocationServicesSender.RequestFineLocationPermission();
            }

            if (!Defines.enableLocationServices) {
                Debug.LogError(LocationServiceRemote.missingDefineError);
            }
        }
        
        void OnGUI() {
            var style = new GUIStyle(GUI.skin.button) {fontSize = fontSize};
            if (GUI.Button(new Rect(0, 0, 400, 200), "Start", style)) {
                Input.location.Start(desiredAccuracyInMeters, updateDistanceInMeters);
            } else if (GUI.Button(new Rect(0, 200, 400, 200), "Stop", style)) {
                Input.location.Stop();
            }
        }


        void Update() {
            isEnabledByUser = Input.location.isEnabledByUser;
            status = Input.location.status;
            lastData = Input.location.status == LocationServiceStatus.Running ? LocationInfoSerializable.Create(Input.location.lastData) : default;
        }
    }
}
