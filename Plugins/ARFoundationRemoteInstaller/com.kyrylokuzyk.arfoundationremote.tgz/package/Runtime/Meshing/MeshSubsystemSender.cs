﻿#if UNITY_2019_3_OR_NEWER
    using MeshId = UnityEngine.XR.MeshId;
#else
    using MeshGenerationResult = UnityEngine.Experimental.XR.MeshGenerationResult;
    using MeshId = UnityEngine.Experimental.XR.TrackableId;
    using XRMeshSubsystem = UnityEngine.Experimental.XR.XRMeshSubsystem;
    using MeshInfo = UnityEngine.Experimental.XR.MeshInfo;
    using MeshVertexAttributes = UnityEngine.Experimental.XR.MeshVertexAttributes;
    using MeshChangeState = UnityEngine.Experimental.XR.MeshChangeState;
    using MeshGenerationStatus = UnityEngine.Experimental.XR.MeshGenerationStatus;
    using System.Collections;
#endif
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using JetBrains.Annotations;
    using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.XR;
using UnityEngine.XR.ARSubsystems;
using Debug = UnityEngine.Debug;


namespace ARFoundationRemote.Runtime {
    public class MeshSubsystemSender : MonoBehaviour {
        [CanBeNull] XRMeshSubsystem realSubsystem;
        readonly HashSet<Mesh> meshes = new HashSet<Mesh>();
        readonly Throttler meshInfoUpdateThrottler = new Throttler(() => 3);


        void OnEnable() {
            Connection.Register<MeshingDataEditor>(receive);
        }

        void OnDisable() {
            Connection.UnRegister<MeshingDataEditor>();
        }

        void receive(MeshingDataEditor meshingData) {
            if (realSubsystem == null) {
                realSubsystem = XRGeneralSettingsRemote.GetRealSubsystem();
                logInitialization($"realSubsystem != null: {realSubsystem != null}");
            }
            
            if (realSubsystem == null) {
                log("realSubsystem == null, skipping Editor message");
                if (meshingData.enableMeshing == true) {
                    logInitialization($"realSubsystem == null: {realSubsystem == null}");
                    Sender.AddRuntimeErrorOnce("- Meshing is not supported on this device");
                }
                
                return;
            }

            var density = meshingData.meshDensity;
            if (density.HasValue) {
                var meshDensity = density.Value; 
                log($"realSubsystem.meshDensity = {meshDensity};");
                realSubsystem.meshDensity = meshDensity;
                return;
            }

            var boundingVolumeData = meshingData.boundingVolumeData;
            if (boundingVolumeData.HasValue) {
                var volumeData = boundingVolumeData.Value;
                var originPos = volumeData.origin.Value;
                var extents = volumeData.extents.Value;
                log($"SetBoundingVolume {originPos}, {extents}");
                realSubsystem.SetBoundingVolume(originPos, extents);
                return;
            }

            var enableMeshing = meshingData.enableMeshing;
            if (enableMeshing.HasValue) {
                if (enableMeshing.Value) {
                    log("realSubsystem.Start()");
                    realSubsystem.Start();
                } else {
                    log("realSubsystem.Stop()");
                    reset();
                    if (realSubsystem != null && realSubsystem.running) {
                        realSubsystem.Stop();
                    }
                    
                    realSubsystem = null;    
                }
                
                return;
            }

            var maybeGenerateMeshAsyncRequest = meshingData.generateMeshAsyncRequest;
            Assert.IsNotNull(realSubsystem);
            if (maybeGenerateMeshAsyncRequest.HasValue) {
                if (!realSubsystem.running) {
                    return;
                }
                
                var editorRequest = maybeGenerateMeshAsyncRequest.Value;
                log("GenerateMeshAsyncRequest " + editorRequest.meshId);
                var meshId = editorRequest.meshId.Value;

                var mesh = new Mesh();
                meshes.Add(mesh);
                var attributes = editorRequest.attributes;
                realSubsystem.GenerateMeshAsync(meshId, mesh, null, attributes, result => {
                        log("onMeshGenerationComplete " + result.MeshId);
                        if (mesh != null) {
                            Assert.IsNotNull(mesh, "IsNotNull(mesh)");

                            bool success = true;
                            if (result.Mesh == null) {
                                log("result.Mesh == null");
                                success = false;
                            } else if (meshId != result.MeshId) {
                                Debug.LogError("realSubsystem.GenerateMeshAsync meshId != result.MeshId");
                                success = false;
                            } else if (mesh != result.Mesh) {
                                Debug.LogError($"realSubsystem.GenerateMeshAsync mesh != result.Mesh, mesh != null: {mesh != null}, result.Mesh != null: {result.Mesh != null}");
                                success = false;
                            }

                            var subMeshIndex = 0;
                            var indices = mesh.GetIndices(subMeshIndex);
                            if (indices.All(_ => _ == 0)) {
                                // don't know why, but sometimes indices will have all zero values
                                // this causes mesh flickering
                                success = false;
                            }

                            var resultSerialized = MeshGenerationResultSerializable.Create(result);
                            if (success) {
                            #if (UNITY_IOS || UNITY_EDITOR) && ARKIT_INSTALLED && ARFOUNDATION_4_0_2_OR_NEWER
                                // send mesh classifications before generateMeshAsyncResponse
                                var meshClassifications = tryGetFaceClassifications(meshId.trackableId());
                                if (meshClassifications != null) {
                                    Connection.Send(new MeshClassificationData(MeshIdSerializable.Create(meshId), meshClassifications));
                                }
                            #endif

                                Connection.Send(new MeshingDataPlayer {
                                    generateMeshAsyncResponse = new GenerateMeshAsyncResponse(resultSerialized, new GenerateMeshAsyncResponseData {
                                        vertices = mesh.vertices.Select(Vector3Serializable.Create).ToArray(),
                                        indices = indices,
                                        normals = attributes.HasFlag(MeshVertexAttributes.Normals) ? mesh.normals.Select(Vector3Serializable.Create).ToArray() : null,
                                        tangents = attributes.HasFlag(MeshVertexAttributes.Tangents) ? mesh.tangents.Select(Vector4Serializable.Create).ToArray() : null,
                                        uvs = attributes.HasFlag(MeshVertexAttributes.UVs) ? mesh.uv.Select(Vector2Serializable.Create).ToArray() : null,
                                        colors = attributes.HasFlag(MeshVertexAttributes.Colors) ? mesh.colors.Select(ColorSerializable.Create).ToArray() : null
                                    })
                                });
                            } else {
                                resultSerialized.Status = MeshGenerationStatus.UnknownError;
                                Connection.Send(new MeshingDataPlayer {
                                    generateMeshAsyncResponse = new GenerateMeshAsyncResponse(resultSerialized, null)
                                });
                            }
                        } else {
                            log($"mesh was destroyed {meshId}");
                        }

                        var removed = meshes.Remove(mesh);
                        // Assert.IsTrue(removed); // can be false if reset() was called before callback 
                        Destroy(mesh);
                    }
                    #if UNITY_2021_2_OR_NEWER
                    , editorRequest.consumeTransform ? MeshGenerationOptions.ConsumeTransform : MeshGenerationOptions.None
                    #endif
                );

                return;
            }

            #if (UNITY_IOS || UNITY_EDITOR) && ARKIT_INSTALLED && ARFOUNDATION_4_0_2_OR_NEWER
            var setClassificationEnabled = meshingData.setClassificationEnabled;
            if (setClassificationEnabled.HasValue) {
                var classificationEnabled = setClassificationEnabled.Value;
                log("ARKitMeshSubsystemExtensions.SetClassificationEnabled " + classificationEnabled);
                UnityEngine.XR.ARKit.ARKitMeshSubsystemExtensions.SetClassificationEnabled(null, classificationEnabled);
                Assert.AreEqual(classificationEnabled, isClassificationEnabled);
                return;
            }

            var getClassificationEnabled = meshingData.getClassificationEnabled;
            if (getClassificationEnabled.HasValue) {
                Connection.SendResponseInstantly(new MeshingDataPlayer {
                    classificationEnabled = isClassificationEnabled
                }, meshingData);
                
                return;
            }
            #endif

            throw new Exception(meshingData.AllFieldsAndPropsToString());
        }
        
        void reset() {
            foreach (var _ in meshes) {
                Assert.IsNotNull(_);
                Destroy(_);
            }
            
            meshes.Clear();
        }

        #if (UNITY_IOS || UNITY_EDITOR) && ARKIT_INSTALLED && ARFOUNDATION_4_0_2_OR_NEWER
            [CanBeNull]
            UnityEngine.XR.ARKit.ARMeshClassification[] tryGetFaceClassifications(TrackableId meshId) {
                if (isClassificationEnabled) {
                    using (var result = UnityEngine.XR.ARKit.ARKitMeshSubsystemExtensions.GetFaceClassifications(realSubsystem, meshId, Unity.Collections.Allocator.Temp)) {
                        return result.ToArray();
                    }
                } else {
                    return null;
                }
            }
            
            bool isClassificationEnabled => UnityEngine.XR.ARKit.ARKitMeshSubsystemExtensions.GetClassificationEnabled(null);
        #endif

   
        [Conditional("_")]
        static void logInitialization(string s) {
            Debug.Log("MeshSubsystem: " + s);
        }
        
        [Conditional("_")]
        public static void log(string s) {
            Debug.Log("MeshSubsystem: " + s);
        }
        
        [Conditional("_")]
        public static void errorOccursSometimes(string s) {
            Debug.LogError("Mesh sender error: " + s);
        }
        
        void Update() {
            if (meshInfoUpdateThrottler.CheckIfAvailableAndRecordUsage()) {
                var infos = new List<MeshInfo>();
                if (realSubsystem != null && realSubsystem.running) {
                    if (realSubsystem.TryGetMeshInfos(infos)) {
                        log("send meshInfos " + infos.Count);
                        Connection.Send(new MeshingDataPlayer {
                            meshInfos = infos.Select(MeshInfoSerializable.Create).ToList()
                        });
                    }

                    #if UNITY_2021_2_OR_NEWER
                    var updatedMeshTransforms = realSubsystem.GetUpdatedMeshTransforms(Unity.Collections.Allocator.Temp);
                    if (updatedMeshTransforms.IsCreated) {
                        using (updatedMeshTransforms) {
                            if (updatedMeshTransforms.Length > 0) {
                                log("send updatedMeshTransforms " + updatedMeshTransforms.Length);
                                Connection.Send(new MeshingDataPlayer {
                                    updatedMeshTransforms = updatedMeshTransforms.Select(MeshTransformSerializable.Create).ToArray()
                                });
                            }
                        }
                    }
                    #endif
                }    
            }
        }
    }


    [Serializable]
    public class MeshTransformSerializable {
        MeshIdSerializable meshId;
        ulong timestamp;
        Vector3Serializable position;
        QuaternionSerializable rotation;
        Vector3Serializable scale;
        

        #if UNITY_2021_2_OR_NEWER
        public static MeshTransformSerializable Create(MeshTransform _) {
            return new MeshTransformSerializable {
                meshId = MeshIdSerializable.Create(_.MeshId),
                timestamp = _.Timestamp,
                position = Vector3Serializable.Create(_.Position),
                rotation = QuaternionSerializable.Create(_.Rotation),
                scale = Vector3Serializable.Create(_.Scale)
            };
        }

        public MeshTransform Deserialize() {
            return new MeshTransform(meshId.Value, timestamp, position.Value, rotation.Quaternion, scale.Value);
        }
        #endif
    }
    
    
    [Serializable]
    public class MeshingDataPlayer : BlockingMessage {
        [CanBeNull] public List<MeshInfoSerializable> meshInfos;
        [CanBeNull] public GenerateMeshAsyncResponse generateMeshAsyncResponse;
        public bool? classificationEnabled;
        [CanBeNull] public MeshTransformSerializable[] updatedMeshTransforms;
    }


    [Serializable]
    public class MeshingDataEditor : BlockingMessage {
        public bool? enableMeshing;
        public GenerateMeshAsyncRequest? generateMeshAsyncRequest;
        public float? meshDensity;
        public SetBoundingVolumeCallData? boundingVolumeData;
        public bool? setClassificationEnabled;
        public bool? getClassificationEnabled; // bool value in not used
    }

    
    [Serializable]
    public struct SetBoundingVolumeCallData {
        public Vector3Serializable origin;
        public Vector3Serializable extents;
    }
    
    
    [Serializable]
    public struct GenerateMeshAsyncRequest {
        public MeshIdSerializable meshId;
        public MeshVertexAttributes attributes;
        public bool consumeTransform;

        
        public override string ToString() {
            return $"{meshId.Value}, {attributes}";
        }
    }


    [Serializable]
    public class GenerateMeshAsyncResponse {
        [NotNull] public readonly MeshGenerationResultSerializable result;
        [CanBeNull] public readonly GenerateMeshAsyncResponseData data;

        
        public GenerateMeshAsyncResponse([NotNull] MeshGenerationResultSerializable result, [CanBeNull] GenerateMeshAsyncResponseData data) {
            this.result = result;
            this.data = data;
        }
    }


    [Serializable]
    public class GenerateMeshAsyncResponseData {
        [NotNull] public Vector3Serializable[] vertices;
        [NotNull] public int[] indices;
        [CanBeNull] public Vector3Serializable[] normals;
        [CanBeNull] public Vector4Serializable[] tangents;
        [CanBeNull] public Vector2Serializable[] uvs;
        [CanBeNull] public ColorSerializable[] colors;
    }
    

    #if (UNITY_IOS || UNITY_EDITOR) && ARKIT_INSTALLED && ARFOUNDATION_4_0_2_OR_NEWER
    [Serializable]
    public class MeshClassificationData {
        public readonly MeshIdSerializable meshId;
        [NotNull] public readonly UnityEngine.XR.ARKit.ARMeshClassification[] faceClassifications;

        public MeshClassificationData(MeshIdSerializable meshId, [NotNull] UnityEngine.XR.ARKit.ARMeshClassification[] faceClassifications) {
            this.meshId = meshId;
            this.faceClassifications = faceClassifications;
        }
    }
    #endif


    [Serializable]
    [StructLayout(LayoutKind.Sequential)]
    public struct MeshInfoSerializable : ISerializableTrackable<MeshInfo> {
        MeshIdSerializable MeshId;
        public MeshChangeState ChangeState;
        int PriorityHint;

        public static MeshInfoSerializable Create(MeshInfo info) => new Union {nonSerializable = info}.serializable;

        public TrackableId trackableId => MeshId.Value.trackableId();
        
        public MeshInfo Value => new Union {serializable = this}.nonSerializable;

        public MeshInfoSerializable WithState(MeshChangeState state) {
            return new MeshInfoSerializable {
                MeshId = MeshId,
                ChangeState = state,
                PriorityHint = PriorityHint
            };
        }

        [StructLayout(LayoutKind.Explicit)]
        struct Union {
            [FieldOffset(0)] public MeshInfoSerializable serializable;
            [FieldOffset(0)] public MeshInfo nonSerializable;
        }
    }
    

    [Serializable]
    public class MeshGenerationResultSerializable {
        static Reflector<MeshGenerationResult> reflector = new Reflector<MeshGenerationResult>();
        
        public MeshIdSerializable MeshId { get; private set; }
        public MeshGenerationStatus Status;
        MeshVertexAttributes Attributes;
        ulong Timestamp;
        Vector3Serializable Position;
        QuaternionSerializable Rotation;
        Vector3Serializable Scale;


        public static MeshGenerationResultSerializable Create(MeshGenerationResult _) {
            return new MeshGenerationResultSerializable {
                MeshId = MeshIdSerializable.Create(_.MeshId),
                Status = _.Status,
                Attributes = _.Attributes,
                #if UNITY_2021_2_OR_NEWER
                Timestamp = _.Timestamp,
                Position = Vector3Serializable.Create(_.Position),
                Rotation = QuaternionSerializable.Create(_.Rotation),
                Scale = Vector3Serializable.Create(_.Scale)
                #endif
            };
        }
        
        public MeshGenerationResult Deserialize([NotNull] Mesh mesh, [CanBeNull] MeshCollider meshCollider, MeshGenerationStatus statusOverride) {
            Assert.IsNotNull(mesh);
            var resultBuilder = reflector.GetResultBuilder();
            resultBuilder.SetPropertyBackingField("MeshId", MeshId.Value);
            resultBuilder.SetPropertyBackingField("Mesh", mesh);
            resultBuilder.SetPropertyBackingField("MeshCollider", meshCollider);
            resultBuilder.SetPropertyBackingField("Status", statusOverride);
            resultBuilder.SetPropertyBackingField("Attributes", Attributes);
            #if UNITY_2021_2_OR_NEWER
            resultBuilder.SetPropertyBackingField("Timestamp", Timestamp);
            resultBuilder.SetPropertyBackingField("Position", Position.Value);
            resultBuilder.SetPropertyBackingField("Rotation", Rotation.Quaternion);
            resultBuilder.SetPropertyBackingField("Scale", Scale.Value);
            #endif
            return resultBuilder.Result;
        }
    }
    
    
    [Serializable]
    [StructLayout(LayoutKind.Sequential)]
    public struct MeshIdSerializable {
        ulong m_SubId1, m_SubId2;


        public static MeshIdSerializable Create(MeshId id) {
            return new union {nonSerializable = id}.serializable;
        }

        public MeshId Value => new union {serializable = this}.nonSerializable;
            
        [StructLayout(LayoutKind.Explicit)]
        struct union {
            // MeshId LayoutKind is not Sequential. This may cause problems
            [FieldOffset(0)] public MeshIdSerializable serializable;
            [FieldOffset(0)] public MeshId nonSerializable;
        }
    }


    public class GenerateMeshAsyncReceiverData {
        public Mesh mesh;
        [CanBeNull] public MeshCollider meshCollider;
        public Action<MeshGenerationResult> onMeshGenerationComplete;
        public MeshVertexAttributes attributes;
    }
}
