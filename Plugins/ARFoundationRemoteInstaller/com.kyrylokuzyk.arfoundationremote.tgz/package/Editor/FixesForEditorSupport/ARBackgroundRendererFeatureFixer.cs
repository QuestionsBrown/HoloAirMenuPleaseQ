﻿using System.IO;
using UnityEditor;


namespace ARFoundationRemote.Editor {
    public static class ARBackgroundRendererFeatureFixer {
        public static bool ApplyFixIfNeeded() {
            var path = FixesForEditorSupport.GetARFoundationRuntimeScriptPath<UnityEngine.XR.ARFoundation.ARBackgroundRendererFeature>();
            var script = AssetDatabase.LoadAssetAtPath<MonoScript>(path);
            var text = script.text;
            var fix = @"#undef UNITY_EDITOR
";
            if (text.Contains(fix)) {
                // Debug.Log("fix already applied");
                return false;
            }

            var withFix = text.Insert(0, fix);
            File.WriteAllText(AssetDatabase.GetAssetPath(script), withFix);
            return true;
        }
    }
}
