﻿#if ARFOUNDATION_4_0_2_OR_NEWER
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using ARFoundationRemote.Runtime;
using JetBrains.Annotations;
using Unity.Collections;
using UnityEditor;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;
using Debug = UnityEngine.Debug;
using Object = UnityEngine.Object;


namespace ARFoundationRemote.Editor {
    /// This errors also appears in real debug builds, so this is not the problem with plugin itself:
    ///     Texture descriptor dimension should not change from None to Tex2D.
    ///     UnityEngine.XR.ARFoundation.Samples.DisplayDepthImage:Update() (at Assets/Scripts/DisplayDepthImage.cs:250)
    /// _Bug in <see cref="XROcclusionSubsystem.TryAcquireEnvironmentDepthConfidenceCpuImage"/>:
    ///     XRCpuImage is constructed with environmentDepthCpuImageApi instead of environmentDepthConfidenceCpuImageApi
    public class OcclusionSubsystem : XROcclusionSubsystem {
        [CanBeNull] static Material _cameraMaterial;
        
        
        /// todoo fetch supported features from the AR device
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void RegisterDescriptor() {
            if (!Global.IsPluginEnabled()) {
                return;
            }

            log("RegisterDescriptor");
            var isIOS = EditorUserBuildSettings.activeBuildTarget == BuildTarget.iOS;
            var type = typeof(OcclusionSubsystem);
            var cinfo = new XROcclusionSubsystemCinfo {
                id = nameof(OcclusionSubsystem),
                #if UNITY_2020_2_OR_NEWER
                    providerType = typeof(OcclusionSubsystemProvider),
                    subsystemTypeOverride = type,
                #else
                    implementationType = type,
                #endif
                #if AR_SUBSYSTEMS_4_2_OR_NEWER || AR_FOUNDATION_5_0_OR_NEWER
                    humanSegmentationDepthImageSupportedDelegate = () => isIOS ? Supported.Supported : Supported.Unsupported,
                    humanSegmentationStencilImageSupportedDelegate = () => isIOS ? Supported.Supported : Supported.Unsupported,
                    environmentDepthImageSupportedDelegate = () => Supported.Supported, // iOS 14 is required or ARCore
                    environmentDepthConfidenceImageSupportedDelegate = () => Supported.Supported,
                    environmentDepthTemporalSmoothingSupportedDelegate = () => Supported.Supported
                #else
                    supportsHumanSegmentationDepthImage = isIOS, // A12 CPU is required
                    supportsHumanSegmentationStencilImage = isIOS, // A12 CPU is required
                    #if AR_SUBSYSTEMS_4_1_1_OR_NEWER
                        queryForSupportsEnvironmentDepthImage = () => true, // iOS 14 is required
                        queryForSupportsEnvironmentDepthConfidenceImage = () => true
                    #endif
                #endif
            };
        
            Register(cinfo);
        }

        public OcclusionSubsystem() {
            log("OcclusionSubsystem");
        }
        
        #if !UNITY_2020_2_OR_NEWER
        protected override Provider CreateProvider() => new OcclusionSubsystemProvider();
        #endif
        
        
        class OcclusionSubsystemProvider : Provider {
            [CanBeNull] TextureAndDescriptor 
                humanStencil,
                humanDepth,
                #pragma warning disable 649
                environmentDepth,
                environmentDepthConfidence;
                #pragma warning restore
            bool enabled = true;
            
            
            public override void Start() {
                enableRemoteManager(true);
                Connection.Register<OcclusionData>(occlusionData => {
                    tryDeserialize(occlusionData.humanStencil, ref humanStencil);
                    tryDeserialize(occlusionData.humanDepth, ref humanDepth);
                });
                
                #if ARFOUNDATION_4_1_OR_NEWER
                Connection.Register<OcclusionDataDepth>(occlusionData => {
                    tryDeserialize(occlusionData.environmentDepth, ref environmentDepth);
                    tryDeserialize(occlusionData.environmentDepthConfidence, ref environmentDepthConfidence);    
                });
                #endif
            }

            public override void Stop() {
                enableRemoteManager(false);
                Connection.UnRegister<OcclusionData>();
                #if ARFOUNDATION_4_1_OR_NEWER
                Connection.UnRegister<OcclusionDataDepth>();
                #endif
            }

            IEnumerable<TextureAndDescriptor> getNonNullTextures() {
                return new[] {humanStencil, humanDepth, environmentDepth, environmentDepthConfidence}.Where(_ => _ != null);
            }

            public override void Destroy() {
                foreach (var _ in getNonNullTextures()) {
                    _.DestroyTexture();
                }
            }

            void enableRemoteManager(bool enable) {
                Connection.Send(new OcclusionDataEditor {
                    enableOcclusion = enable
                });
            }

            HumanSegmentationStencilMode _humanStencilMode;
            public override HumanSegmentationStencilMode requestedHumanStencilMode {
                get => _humanStencilMode;
                set {
                    if (_humanStencilMode != value) {
                        _humanStencilMode = value;
                        Connection.Send(new OcclusionDataEditor {
                            requestedHumanStencilMode = value
                        });
                    }
                }
            }

            public override HumanSegmentationStencilMode currentHumanStencilMode => _humanStencilMode;

            HumanSegmentationDepthMode _humanDepthMode;
            public override HumanSegmentationDepthMode requestedHumanDepthMode {
                get => _humanDepthMode;
                set {
                    if (_humanDepthMode != value) {
                        _humanDepthMode = value;
                        Connection.Send(new OcclusionDataEditor {
                            requestedHumanDepthMode = value
                        });
                    }
                }
            }

            public override HumanSegmentationDepthMode currentHumanDepthMode => _humanDepthMode;

            public override bool TryGetHumanStencil(out XRTextureDescriptor descriptor) {
                return tryGetDescriptor(out descriptor, humanStencil);
            }

            public override bool TryGetHumanDepth(out XRTextureDescriptor descriptor) {
                return tryGetDescriptor(out descriptor, humanDepth);
            }

            static bool tryGetDescriptor(out XRTextureDescriptor descriptor, [CanBeNull] TextureAndDescriptor pair) {
                if (pair != null) {
                    var _ = pair.descriptor;
                    if (_.HasValue) {
                        descriptor = _.Value;
                        return true;    
                    }
                }
                
                descriptor = default;
                return false;
            }

            public override NativeArray<XRTextureDescriptor> GetTextureDescriptors(XRTextureDescriptor defaultDescriptor, Allocator allocator) {
                    var result = getNonNullTextures()
                        .Select(_ => _.descriptor)
                        .Where(_ => _.HasValue)
                        .Select(_ => _.Value)
                        .ToArray();
                    
                    return new NativeArray<XRTextureDescriptor>(result, allocator);
            }

            public override void GetMaterialKeywords(out List<string> enabledKeywords, out List<string> disabledKeywords) {
                switch (EditorUserBuildSettings.activeBuildTarget) {
                    case BuildTarget.iOS:
                        getIOSKeywords(out enabledKeywords, out disabledKeywords);
                        break;
                    case BuildTarget.Android:
                        getAndroidKeywords(out enabledKeywords, out disabledKeywords);
                        break;
                    default:
                        enabledKeywords = null;
                        disabledKeywords = null;
                        break;
                }
            }

            void getAndroidKeywords(out List<string> enabledKeywords, out List<string> disabledKeywords) {
                if (IsEnvDepthEnabled())
                {
                    enabledKeywords = AndroidKeywords.m_EnvironmentDepthEnabledMaterialKeywords;
                    disabledKeywords = null;
                }
                else
                {
                    enabledKeywords = null;
                    disabledKeywords = AndroidKeywords.m_EnvironmentDepthEnabledMaterialKeywords;
                }
            }

            static class AndroidKeywords {
                public static readonly List<string> m_EnvironmentDepthEnabledMaterialKeywords = new List<string>() {k_EnvironmentDepthEnabledMaterialKeyword};
                const string k_EnvironmentDepthEnabledMaterialKeyword = "ARCORE_ENVIRONMENT_DEPTH_ENABLED";
            }
            
            void getIOSKeywords(out List<string> enabledKeywords, out List<string> disabledKeywords) {
                bool isHumanDepthEnabled = currentHumanDepthMode != HumanSegmentationDepthMode.Disabled || currentHumanStencilMode != HumanSegmentationStencilMode.Disabled;

                if (IsEnvDepthEnabled()
                    && (!isHumanDepthEnabled
                        || isEnvironmentOcclusionPreferred()))
                {
                    enabledKeywords = IOSKeywords.m_EnvironmentDepthEnabledMaterialKeywords;
                    disabledKeywords = IOSKeywords.m_HumanEnabledMaterialKeywords;
                }
                else if (isHumanDepthEnabled)
                {
                    enabledKeywords = IOSKeywords.m_HumanEnabledMaterialKeywords;
                    disabledKeywords = IOSKeywords.m_EnvironmentDepthEnabledMaterialKeywords;
                }
                else
                {
                    enabledKeywords = null;
                    disabledKeywords = IOSKeywords.m_AllDisabledMaterialKeywords;
                }
            }

            bool isEnvironmentOcclusionPreferred() {
                #if ARFOUNDATION_4_1_OR_NEWER
                    return currentOcclusionPreferenceMode == OcclusionPreferenceMode.PreferEnvironmentOcclusion;
                #else
                    return false;
                #endif
            }

            bool IsEnvDepthEnabled() {
                #if ARFOUNDATION_4_1_OR_NEWER
                    return currentEnvironmentDepthMode != EnvironmentDepthMode.Disabled;
                #else
                    return false;
                #endif
            }

            static class IOSKeywords {
                public static readonly List<string> m_EnvironmentDepthEnabledMaterialKeywords = new List<string>() {k_EnvironmentDepthEnabledMaterialKeyword};
                const string k_EnvironmentDepthEnabledMaterialKeyword = "ARKIT_ENVIRONMENT_DEPTH_ENABLED";
                public static readonly List<string> m_HumanEnabledMaterialKeywords = new List<string>() {k_HumanEnabledMaterialKeyword};
                const string k_HumanEnabledMaterialKeyword = "ARKIT_HUMAN_SEGMENTATION_ENABLED";
                public static readonly List<string> m_AllDisabledMaterialKeywords = new List<string>() {k_HumanEnabledMaterialKeyword, k_EnvironmentDepthEnabledMaterialKeyword};
            }
            
            #if ARFOUNDATION_4_0_2_OR_NEWER
            static CpuImagesReceiver.CpuImageApiSingleton api => CpuImagesReceiver.Instance.api;
            public override XRCpuImage.Api humanDepthCpuImageApi => api;
            public override XRCpuImage.Api humanStencilCpuImageApi => api;
            public override bool TryAcquireHumanDepthCpuImage(out XRCpuImage.Cinfo cinfo) {
                return api.TryAcquireCpuImage(CpuImageType.HumanDepth, out cinfo);
            }

            public override bool TryAcquireHumanStencilCpuImage(out XRCpuImage.Cinfo cinfo) {
                return api.TryAcquireCpuImage(CpuImageType.HumanStencil, out cinfo);
            }
            #endif
            
            #if ARFOUNDATION_4_1_OR_NEWER
            EnvironmentDepthMode _environmentDepthMode;
            public override EnvironmentDepthMode currentEnvironmentDepthMode => _environmentDepthMode;
            public override EnvironmentDepthMode requestedEnvironmentDepthMode {
                get => _environmentDepthMode;
                set {
                    if (_environmentDepthMode != value) {
                        _environmentDepthMode = value;
                        Connection.Send(new OcclusionDataDepthEditor {
                            requestedEnvironmentDepthMode = value
                        });
                    }
                }
            }

            OcclusionPreferenceMode _occlusionPreferenceMode;
            public override OcclusionPreferenceMode currentOcclusionPreferenceMode => _occlusionPreferenceMode;
            public override OcclusionPreferenceMode requestedOcclusionPreferenceMode {
                get => _occlusionPreferenceMode;
                set {
                    if (_occlusionPreferenceMode != value) {
                        _occlusionPreferenceMode = value;
                        Connection.Send(new OcclusionDataDepthEditor {
                            requestedOcclusionPreferenceMode = value
                        });
                    }
                }
            }

            public override bool TryGetEnvironmentDepth(out XRTextureDescriptor descriptor) {
                return tryGetDescriptor(out descriptor, environmentDepth);
            }

            public override bool TryGetEnvironmentDepthConfidence(out XRTextureDescriptor descriptor) {
                return tryGetDescriptor(out descriptor, environmentDepthConfidence);
            }

            public override bool TryAcquireEnvironmentDepthCpuImage(out XRCpuImage.Cinfo cinfo) {
                var type = 
                    #if AR_FOUNDATION_4_2_OR_NEWER
                    environmentDepthTemporalSmoothingEnabled ? CpuImageType.SmoothedEnvironmentDepth : CpuImageType.RawEnvironmentDepth;
                    #else
                    CpuImageType.SmoothedEnvironmentDepth;
                    #endif
                return api.TryAcquireCpuImage(type, out cinfo);
            }
            
            public override bool TryAcquireEnvironmentDepthConfidenceCpuImage(out XRCpuImage.Cinfo cinfo) {
                return api.TryAcquireCpuImage(CpuImageType.EnvironmentDepthConfidence, out cinfo);
            }

            public override XRCpuImage.Api environmentDepthCpuImageApi => api;
            public override XRCpuImage.Api environmentDepthConfidenceCpuImageApi => api;
            #endif
            
            #if AR_FOUNDATION_4_2_OR_NEWER
            public override bool TryAcquireSmoothedEnvironmentDepthCpuImage(out XRCpuImage.Cinfo cinfo) {
                return api.TryAcquireCpuImage(CpuImageType.SmoothedEnvironmentDepth, out cinfo);
            }

            public override bool TryAcquireRawEnvironmentDepthCpuImage(out XRCpuImage.Cinfo cinfo) {
                return api.TryAcquireCpuImage(CpuImageType.RawEnvironmentDepth, out cinfo);
            }
            
            public override bool environmentDepthTemporalSmoothingEnabled => environmentDepthTemporalSmoothingRequested;
            public override bool environmentDepthTemporalSmoothingRequested { get; set; }
            #endif
            
            void tryDeserialize(SerializedTextureAndPropId? ser, [CanBeNull] ref TextureAndDescriptor cached) {
                if (!enabled) {
                    return;
                }
            
                if (ser.HasValue) {
                    var value = ser.Value;
                    if (cameraMaterial != null) {
                        var propName = value.propName;
                        if (propName != null && !SupportCheck.CheckCameraAndOcclusionSupport(cameraMaterial, propName)) {
                            enabled = false;
                            return;
                        }
                    }
                
                    if (cached == null) {
                        cached = new TextureAndDescriptor();
                    }
                
                    cached.Update(value);
                }
            }
        }

        [CanBeNull]
        static Material cameraMaterial {
            get {
                if (_cameraMaterial == null) {
                    var bg = Object.FindObjectOfType<ARCameraBackground>();
                    if (bg != null) {
                        _cameraMaterial = bg.material;
                    }
                }

                return _cameraMaterial;
            }
        }
        

        [Conditional("_")]
        static void log(string msg) {
            Debug.Log(msg);
        }
    }
}
#endif
