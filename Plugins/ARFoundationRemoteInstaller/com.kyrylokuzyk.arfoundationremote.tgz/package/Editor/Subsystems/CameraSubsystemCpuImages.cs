#if ARFOUNDATION_4_0_2_OR_NEWER
    using CameraImageCinfo = UnityEngine.XR.ARSubsystems.XRCpuImage.Cinfo;
#else
    using System;
    using UnityEngine;
#endif
using ARFoundationRemote.Runtime;
using UnityEngine.XR.ARSubsystems;


namespace ARFoundationRemote.Editor {
    public partial class CameraSubsystem {
        partial class CameraSubsystemProvider {
            public override bool
                #if ARFOUNDATION_4_0_2_OR_NEWER
                TryAcquireLatestCpuImage
                #else
                TryAcquireLatestImage
                #endif
                (out CameraImageCinfo cameraImageCinfo) {
                if (CpuImagesReceiver.Instance.api.TryAcquireCpuImage(CpuImageType.Camera, out var i)) {
                    cameraImageCinfo = new CameraImageCinfo(i.nativeHandle, i.dimensions, i.planeCount, i.timestamp, i.format);
                    return true;
                } else {
                    cameraImageCinfo = default;
                    return false;
                }
            }
     

            #if ARFOUNDATION_4_0_2_OR_NEWER
            public override XRCpuImage.Api cpuImageApi => CpuImagesReceiver.Instance.api;
            #else
            static CpuImageApiArf3 api => CpuImagesReceiver.Instance.api;
            
            public override bool NativeHandleValid(int nativeHandle) {
                return api.NativeHandleValid(nativeHandle);
            }

            public override bool TryGetPlane(int nativeHandle, int planeIndex, out CameraImagePlaneCinfo planeCinfo) {
                if (api.TryGetPlane(nativeHandle, planeIndex, out var i)) {
                    planeCinfo = new CameraImagePlaneCinfo(i.dataPtr, i.dataLength, i.rowStride, i.pixelStride);
                    return true;
                } else {
                    planeCinfo = default;
                    return false;
                }
            }

            public override void DisposeImage(int nativeHandle) {
                api.DisposeImage(nativeHandle);
            }
      
            public override bool TryGetConvertedDataSize(int nativeHandle, Vector2Int dimensions, TextureFormat format, out int size) {
                return api.TryGetConvertedDataSize(nativeHandle, dimensions, format, out size);
            }

            public override int ConvertAsync(int nativeHandle, XRCameraImageConversionParams conversionParams) {
                return api.ConvertAsync(nativeHandle, conversionParams);
            }

            public override AsyncCameraImageConversionStatus GetAsyncRequestStatus(int requestId) {
                return api.GetAsyncRequestStatus(requestId);
            }

            public override bool TryGetAsyncRequestData(int requestId, out IntPtr dataPtr, out int dataLength) {
                return api.TryGetAsyncRequestData(requestId, out dataPtr, out dataLength);
            }

            public override void DisposeAsyncRequest(int requestId) {
                api.DisposeAsyncRequest(requestId);
            }

            public override bool TryConvert(int nativeHandle, XRCameraImageConversionParams conversionParams, IntPtr destinationBuffer, int bufferLength) {
                return api.TryConvert(nativeHandle, conversionParams, destinationBuffer, bufferLength);
            }

            public override void ConvertAsync(int nativeHandle, XRCameraImageConversionParams conversionParams, OnImageRequestCompleteDelegate callback, IntPtr context) {
                api.ConvertAsync(nativeHandle, conversionParams, (status, _params, ptr, length, intPtr) => callback(status, _params, ptr, length, intPtr), context);
            }
            #endif
        }
    }
}
