﻿using ARFoundationRemote.Runtime;
using System.Collections.Generic;
using System.Linq;
using Unity.Collections;
using UnityEditor;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;


namespace ARFoundationRemote.Editor {
    public class RaycastSubsystem : XRRaycastSubsystem {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void RegisterDescriptor() {
            if (!Global.IsPluginEnabled()) {
                return;
            }

            var thisType = typeof(RaycastSubsystem);
            XRRaycastSubsystemDescriptor.RegisterDescriptor(new XRRaycastSubsystemDescriptor.Cinfo {
                id = thisType.Name,
                #if UNITY_2020_2_OR_NEWER
                    providerType = typeof(RaycastSubsystemProvider),
                    subsystemTypeOverride = thisType,
                #else
                    subsystemImplementationType = thisType,
                #endif
                supportedTrackableTypes = getSupportedTrackableTypes(),
                supportsWorldBasedRaycast = true // world-based raycast is a fallback option if screen-based raycast is not supported
            });
        }

        /// <see cref="UnityEngine.XR.ARCore.ARCoreRaycastSubsystem.RegisterDescriptor()"/> doesn't support <see cref="TrackableType.PlaneWithinInfinity"/>, but supports <see cref="TrackableType.Depth"/> 
        static TrackableType getSupportedTrackableTypes() {
            var result = TrackableType.PlaneWithinPolygon |
                         TrackableType.PlaneWithinBounds |
                         TrackableType.PlaneEstimated;

            if (EditorUserBuildSettings.activeBuildTarget == BuildTarget.Android) {
                #if AR_SUBSYSTEMS_4_2_OR_NEWER
                result |= TrackableType.Depth;
                #endif
            } else {
                result |= TrackableType.PlaneWithinInfinity;
            }

            return result;
        }

        #if !UNITY_2020_2_OR_NEWER
        protected override Provider CreateProvider() => new RaycastSubsystemProvider();
        #endif

        class RaycastSubsystemProvider: Provider {
            const int cooldownFrames = 3;
            int lastBlockingCallFrame = -cooldownFrames;
            bool didDisplayTooManyBlockingCallsError;


            /// override to fix _bug in <see cref="ARRaycastManager.RaycastFallback"/>
            ///     fixed version: <see cref="ARPointCloudManagerAppendMethodFixer"/>
            /// code duplication because <see cref="IRaycaster"/> interface is internal
            public override NativeArray<XRRaycastHit> Raycast(XRRaycastHit defaultRaycastHit, Ray sessionSpaceRay, TrackableType trackableTypeMask, Allocator allocator) {
                trackableTypeMask &= getSupportedTrackableTypes();
                if (hasDepthTrackableType(trackableTypeMask) && canPerformBlockingCall()) {
                    var response = Connection.BlockUntilReceive<RaycastResponse>(new RaycastRequest {
                        rayOrigin = Vector3Serializable.Create(sessionSpaceRay.origin),
                        rayDirection = Vector3Serializable.Create(sessionSpaceRay.direction),
                        trackableTypeMask = trackableTypeMask
                    });

                    var hits = response.hits.Select(_ => _.Deserialize()).ToArray();
                    return hits.Any() ? new NativeArray<XRRaycastHit>(hits, allocator) : default;
                }
                    
                var result = new List<XRRaycastHit>();
                if ((trackableTypeMask & TrackableType.Planes) != 0) {
                    var planeManager = Object.FindObjectOfType<ARPlaneManager>();
                    if (planeManager != null) {
                        var hits = planeManager.Raycast(sessionSpaceRay, trackableTypeMask, Allocator.Temp);
                        if (hits.IsCreated) {
                            result.AddRange(hits);
                            hits.Dispose();
                        }
                    } else {
                        Debug.LogError($"{Constants.packageName}: please add ARPlaneManager to raycast against detected planes.");
                    }
                }

                if ((trackableTypeMask & TrackableType.FeaturePoint) != 0) {
                    var pointCloudManager = Object.FindObjectOfType<ARPointCloudManager>();
                    if (pointCloudManager != null) {
                        var hits = pointCloudManager.Raycast(sessionSpaceRay, trackableTypeMask, Allocator.Temp);
                        if (hits.IsCreated) {
                            result.AddRange(hits);
                            hits.Dispose();
                        }
                    } else {
                        Debug.LogError($"{Constants.packageName}: please add ARPointCloudManager to raycast against detected cloud points.");
                    }
                }

                return result.Any() ? new NativeArray<XRRaycastHit>(result.ToArray(), allocator) : default;
            }

            static bool hasDepthTrackableType(TrackableType mask) {
                #if AR_SUBSYSTEMS_4_2_OR_NEWER
                return (mask & TrackableType.Depth) != 0;
                #else
                return false;
                #endif
            }

            bool canPerformBlockingCall() {
                if (Time.frameCount - lastBlockingCallFrame >= cooldownFrames) {
                    lastBlockingCallFrame = Time.frameCount;
                    return true;
                }
                
                if (!didDisplayTooManyBlockingCallsError) {
                    Debug.LogError($"{Constants.packageName}: the plugin makes a blocking request to the AR Companion app every time the ARRaycastManager.Raycast() is called with TrackableType.Depth. If a new raycast is made less than {cooldownFrames} frames since the last one, the TrackableType.Depth will be ignored.\n");
                    didDisplayTooManyBlockingCallsError = true;
                }
                
                return false;
            }
        }
    }
}
