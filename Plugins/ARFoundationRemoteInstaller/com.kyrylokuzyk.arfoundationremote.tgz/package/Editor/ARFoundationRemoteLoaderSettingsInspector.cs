using System.Collections.Generic;
using ARFoundationRemote.Runtime;
using UnityEditor;
using UnityEngine;


namespace ARFoundationRemote.Editor {
    [CustomEditor(typeof(ARFoundationRemoteLoaderSettings))]
    public class ARFoundationRemoteLoaderSettingsInspector : UnityEditor.Editor {
        List<UnityEditor.Editor> editors;


        void OnEnable() {
            editors = new List<UnityEditor.Editor> {CreateEditor(Settings.Instance)};
            if (Defines.isARFoundation4_0_OrNewer) {
                editors.Add(CreateEditor(ObjectTrackingLibraries.Instance));
            }
        }

        public override void OnInspectorGUI() {
            foreach (var _ in editors) {
                _.OnInspectorGUI();
            }
            
            TryDrawVersionUpgrade();
        }
        
        public static void TryDrawVersionUpgrade() {
            #if AR_FOUNDATION_REMOTE_2_0_OR_NEWER
            return;
            #endif

            #pragma warning disable 162
            GUILayout.Space(32);
            GUILayout.Label("New version available!", EditorStyles.boldLabel);
            GUILayout.Space(8);
            GUILayout.Label("Want even more awesome features?\n" +
                            "Upgrade to <b>AR Foundation Remote 2.0</b> with a <color=#E24747><b>discount</b></color>.", 
                new GUIStyle(GUI.skin.label) {wordWrap = true, richText = true, margin = new RectOffset(4, 4, 4, 4)});
            GUILayout.Space(8);
            if (GUILayout.Button("View on Asset Store", GUI.skin.button)) {
                Application.OpenURL("https://assetstore.unity.com/packages/slug/201106");
            }
            #pragma warning restore 162
        }
    }
}
