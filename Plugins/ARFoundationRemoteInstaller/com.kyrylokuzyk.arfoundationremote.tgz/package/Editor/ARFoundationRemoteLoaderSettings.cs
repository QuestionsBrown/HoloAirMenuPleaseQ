﻿using System;
using ARFoundationRemote.Runtime;
using UnityEngine;
using UnityEngine.XR.Management;


namespace ARFoundationRemote.Editor {
    [Serializable]
    [XRConfigurationData(Constants.packageName, Constants.packageName + nameof(ARFoundationRemoteLoaderSettings))]
    public class ARFoundationRemoteLoaderSettings: ScriptableObject {
    }
}
