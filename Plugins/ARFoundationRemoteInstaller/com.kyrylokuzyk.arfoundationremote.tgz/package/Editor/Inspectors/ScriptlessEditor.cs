// credits http://answers.unity.com/answers/903590/view.html 

namespace ARFoundationRemote.Runtime {
    public abstract class ScriptlessEditor : UnityEditor.Editor {
        private static readonly string[] propertiesToExclude = new [] {"m_Script"};
        
        public override void OnInspectorGUI() {
            serializedObject.Update();
            DrawPropertiesExcluding(serializedObject, propertiesToExclude);
            serializedObject.ApplyModifiedProperties();
        }
    }
}
