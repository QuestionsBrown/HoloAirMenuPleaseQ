using UnityEditor;
using UnityEngine;


namespace ARFoundationRemote.Runtime {
    [CustomEditor(typeof(ObjectTrackingLibraries))]
    public class ObjectTrackingLibrariesInspector : UnityEditor.Editor {
        public override void OnInspectorGUI() {
            serializedObject.Update();
            #if ARFOUNDATION_4_0_OR_NEWER
            ObjectTrackingLibraries objectTrackingLibraries;
            EditorGUILayout.PropertyField(serializedObject.FindProperty(nameof(objectTrackingLibraries.objectLibraries)), new GUIContent("Embedded Object Libraries"));
            #endif
            if (!Defines.isARFoundation4_0_OrNewer) {
                GUILayout.Label("Object Tracking is only supported in AR Foundation 4.0 or newer.", new GUIStyle(GUI.skin.label) {wordWrap = true});
            }
            
            serializedObject.ApplyModifiedProperties();
        }
    }
}
