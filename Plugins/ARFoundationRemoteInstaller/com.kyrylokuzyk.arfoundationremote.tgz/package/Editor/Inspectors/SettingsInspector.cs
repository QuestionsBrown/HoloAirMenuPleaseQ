using UnityEditor;


namespace ARFoundationRemote.Runtime {
    [CustomEditor(typeof(Settings))]
    public class SettingsInspector : ScriptlessEditor {
    }
}
