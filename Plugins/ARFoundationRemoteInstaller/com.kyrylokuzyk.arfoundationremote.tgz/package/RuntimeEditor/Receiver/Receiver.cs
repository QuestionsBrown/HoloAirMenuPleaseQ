﻿#if UNITY_EDITOR
using System.Collections;
using System.Diagnostics;
using ARFoundationRemote.Editor;
using ARFoundationRemote.Runtime;
using UnityEditor;
using UnityEditor.PackageManager;
using UnityEngine;
using UnityEngine.Assertions;
using Debug = UnityEngine.Debug;


namespace ARFoundationRemote.RuntimeEditor {
    [InitializeOnLoad]
    public class Receiver: MonoBehaviour, IConnectionDelegate {
        static Receiver() {
            logDestruction("static Receiver()");
            EditorApplication.playModeStateChanged += onPlaymodeStateChanged;
        }
        
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void beforeSceneLoad() {
            if (!Global.IsPluginEnabled()) {
                return;
            }
        
            Assert.IsTrue(FindObjectsOfType<Receiver>().Length == 0);
            Assert.IsTrue(Application.isPlaying);
            var receiver = Utils.TryCreatePersistentEditorObject<Receiver>();
            Assert.IsNotNull(receiver);
            Connection.Instance.StartConnection(receiver);
            Connection.Send(Settings.Instance.arCompanionSettings);
        }

        static void onPlaymodeStateChanged(PlayModeStateChange state) {
            logDestruction(state.ToString());
            Global.playModeState = state;
            if (state == PlayModeStateChange.EnteredEditMode) {
                Connection.ClearReceiverConnection();
                #if UNITY_2019_3_OR_NEWER
                XRMeshSubsystemRemote.ClearDelegate();
                #endif
                Global.IsInitialized = null;
            }
        }

        void Awake() {
            GitRepoCheck.ExitPlaymodeIfRepoIsPublic(this);
        }

        void OnEnable() {
            Connection.Register<PackageVersionData[]>(companionAppPackages => StartCoroutine(checkPackagesCor(companionAppPackages)));
            Connection.Register<InputHandlingData>(_ => _.AssertIsEqualTo(InputHandlingData.Create()));
            Connection.Register<CompanionAppError>(_ => Debug.LogError($"{Constants.packageName} Companion App: {_.error}"));
        }

        void OnDisable() {
            Connection.UnRegister<PackageVersionData[]>();
            Connection.UnRegister<InputHandlingData>();
            Connection.UnRegister<CompanionAppError>();
            Connection.Instance.PauseConnection(this);
        }

        void Start() {
            logDestruction("Receiver.Start()");
        }

        static IEnumerator checkPackagesCor(PackageVersionData[] companionAppPackages) {
            if (!Settings.Instance.debugSettings.checkPackageVersions) {
                yield break;
            }
            
            var listRequest = Client.List(true, true);
            while (!listRequest.IsCompleted) {
                yield return null;
            }
                
            Assert.AreEqual(StatusCode.Success, listRequest.Status);
            PackageVersionData.CheckVersions(companionAppPackages, PackageVersionData.Create(listRequest.Result));
        }
        
        void IConnectionDelegate.OnConnected() {
            ReviewRequest.RecordUsage();
        }

        void IConnectionDelegate.OnDisconnected() {
            Debug.LogError($"{Constants.packageName}: Editor lost connection with AR Companion app. Please restart Editor scene.");
        }

        void OnDestroy() {
            clearTexturesCache();
        }

        /// Destroy may not be called from edit mode in <see cref="onPlaymodeStateChanged"/> after EnteredEditMode 
        static void clearTexturesCache() {
            Texture2DSerializable.ClearCache();
        }


        [Conditional("_")]
        public static void logDestruction(string s) {
            Debug.Log(s);
        }
    }
}
#endif
