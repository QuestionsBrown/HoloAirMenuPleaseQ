#if UNITY_EDITOR
#if ARFOUNDATION_4_0_2_OR_NEWER
    using XRCameraImagePlane = UnityEngine.XR.ARSubsystems.XRCpuImage.Plane;
    using CameraImageFormat = UnityEngine.XR.ARSubsystems.XRCpuImage.Format;
    using CameraImagePlaneCinfo = UnityEngine.XR.ARSubsystems.XRCpuImage.Plane.Cinfo;
    using AsyncCameraImageConversionStatus = UnityEngine.XR.ARSubsystems.XRCpuImage.AsyncConversionStatus;
    using XRCameraImageConversionParams = UnityEngine.XR.ARSubsystems.XRCpuImage.ConversionParams;
    using CameraImageCinfo = UnityEngine.XR.ARSubsystems.XRCpuImage.Cinfo;
#else
    using XRCpuImage = UnityEngine.XR.ARSubsystems.XRCameraImage; 
    using CameraImagePlaneCinfo = ARFoundationRemote.Runtime.CameraImagePlaneCinfoWrapper;
    using OnImageRequestCompleteDelegate = ARFoundationRemote.Runtime.OnImageRequestCompleteDelegateWrapper;
    using CameraImageCinfo = ARFoundationRemote.Runtime.CameraImageCinfoWrapper;
#endif
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using JetBrains.Annotations;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using UnityEditor;
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.XR.ARSubsystems;
using Debug = UnityEngine.Debug;
using Object = UnityEngine.Object;


namespace ARFoundationRemote.Runtime {
    public class CpuImagesReceiver : MonoBehaviour {
        public CpuImageApiSingleton api { get; } = new CpuImageApiSingleton();
        public static CpuImagesReceiver Instance { get; private set; }


        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        static void register() {
            Instance = Utils.TryCreatePersistentEditorObject<CpuImagesReceiver>();
        }

        void OnEnable() {
            if (Settings.cameraVideoSettings.maxCpuImagesFps > Settings.cameraVideoSettings.maxVideoFps) {
                Debug.LogWarning("maxCpuImagesFps can't be greater than maxVideoFps");
            }
            
            Connection.Register<CpuImageResponse>(api.Receive);
            Connection.Register<ConvertedCpuImage>(_ => {
                CpuImageReceiver.logCpuImages("receive converted image");
                api.receivers[_.type].maybeConvertedImage = _;
            });
            Connection.Register<FirstCpuImageReceived>(_ => {
                CpuImageReceiver.logCpuImages($"FirstCpuImageReceived {_.type}");
                api.receivers[_.type].isSupported = true;
            });
        }

        void OnDisable() {
            Connection.UnRegister<CpuImageResponse>();
            Connection.UnRegister<ConvertedCpuImage>();
            Connection.UnRegister<FirstCpuImageReceived>();
        }

        void Update() {
            api.Update();
        }


        /// Singleton CPU image API is needed to fix this _bug in AR Foundation:
        /// https://github.com/Unity-Technologies/arfoundation-samples/issues/878
        /// <see cref="XROcclusionSubsystem.TryAcquireEnvironmentDepthConfidenceCpuImage"/>
        public class CpuImageApiSingleton :
            #if ARFOUNDATION_4_0_2_OR_NEWER
            XRCpuImage.Api
            #else
            CpuImageApiArf3
            #endif
        {
            internal readonly Dictionary<CpuImageType, CpuImageReceiver> receivers = new Dictionary<CpuImageType, CpuImageReceiver>();

            public bool TryAcquireCpuImage(CpuImageType type, out CameraImageCinfo cameraImageCinfo) {
                return getOrAddReceiver(type).TryAcquireCpuImage(out cameraImageCinfo);
            }

            CpuImageReceiver getOrAddReceiver(CpuImageType type) {
                if (receivers.TryGetValue(type, out var result)) {
                    return result;
                } else {
                    var newReceiver = new CpuImageReceiver(type);
                    receivers.Add(type, newReceiver);
                    return newReceiver;
                }
            }

            CpuImageReceiver getReceiver(int nativeHandleOrRequestId) {
                var key = (CpuImageType) (nativeHandleOrRequestId - CpuImageReceiver.dummyShift);
                return receivers[key];
            }
               
            public void Receive(CpuImageResponse response) {
                receivers[response.type].Receive(response);
            }

            public override int ConvertAsync(int nativeHandle, XRCameraImageConversionParams conversionParams) {
                return getReceiver(nativeHandle).ConvertAsync(nativeHandle, conversionParams);
            }

            public override void ConvertAsync(int nativeHandle, XRCameraImageConversionParams conversionParams, OnImageRequestCompleteDelegate callback, IntPtr context) {
                getReceiver(nativeHandle).ConvertAsync(nativeHandle, conversionParams, callback, context);
            }

            public override void DisposeImage(int nativeHandle) {
                getReceiver(nativeHandle).DisposeImage(nativeHandle);
            }

            #if ARFOUNDATION_4_0_2_OR_NEWER
            public override bool FormatSupported(XRCpuImage image, TextureFormat format) {
                // return true for simplicity
                // AR Companion app will display an error if !FormatSupported
                return true;
            }
            #endif

            public override bool TryConvert(int nativeHandle, XRCameraImageConversionParams conversionParams, IntPtr destinationBuffer, int bufferLength) {
                return getReceiver(nativeHandle).TryConvert(nativeHandle, conversionParams, destinationBuffer, bufferLength);
            }

            public override void DisposeAsyncRequest(int requestId) {
                getReceiver(requestId).DisposeAsyncRequest(requestId);
            }

            public override bool NativeHandleValid(int nativeHandle) {
                return getReceiver(nativeHandle).NativeHandleValid(nativeHandle);
            }

            public override bool TryGetPlane(int nativeHandle, int planeIndex, out CameraImagePlaneCinfo planeCinfo) {
                return getReceiver(nativeHandle).TryGetPlane(nativeHandle, planeIndex, out planeCinfo);
            }

            public override AsyncCameraImageConversionStatus GetAsyncRequestStatus(int requestId) {
                return getReceiver(requestId).GetAsyncRequestStatus(requestId);
            }

            public override bool TryGetAsyncRequestData(int requestId, out IntPtr dataPtr, out int dataLength) {
                return getReceiver(requestId).TryGetAsyncRequestData(requestId, out dataPtr, out dataLength);
            }

            public override bool TryGetConvertedDataSize(int nativeHandle, Vector2Int dimensions, TextureFormat format, out int size) {
                return getReceiver(nativeHandle).TryGetConvertedDataSize(nativeHandle, dimensions, format, out size);
            }

            public void Update() {
                foreach (var _ in receivers.Values) {
                    _.Update();
                }
            }
        }
    }


    internal class CpuImageReceiver :
        #if ARFOUNDATION_4_0_2_OR_NEWER
        XRCpuImage.Api
        #else
        CpuImageApiArf3
        #endif
    {
        readonly CpuImageType type;
        XRCpuImageSerializable? cpuImage;
        [CanBeNull] public ConvertedCpuImage maybeConvertedImage;
        ConversionParamsSerializable? prevConversionParams;
        Dictionary<int, NativeArray<byte>> planeDataArrays;
        NativeArray<byte>? convertedData;
        XRCameraImageConversionParams? asyncConversionConversionParams;
        bool canSendCpuImageRequest = true;
        [CanBeNull] BlockingMessageAndFrame<CpuImageResponse> blockingResponse;
        bool acquireCpuImageBlocking = true;
        public bool isSupported;

        int dummyNativeHandleAndRequestId => (int) type + dummyShift;
        public const int dummyShift = 42;


        public CpuImageReceiver(CpuImageType type) {
            this.type = type;
            Connection.Send(new CpuImageRequest {type = type});
        }

        /// The first <see cref="XRCameraSubsystem.TryAcquireLatestCpuImage"/> call blocks the AR Companion's main thead and waits for the potential <see cref="XRCpuImage.Convert"/>.
        /// There is no way to predict if the XRCpuImage.Convert() will be called, so only the first CPU image acquisition is blocking.
        /// The XRCpuImage.Convert() will work successfully until conversion parameters are changed.
        /// After the conversion parameters change, XRCpuImage.Convert() will throw exceptions for several frames.
        public bool TryAcquireCpuImage(out CameraImageCinfo cameraImageCinfo) {
            if (!isSupported) {
                cameraImageCinfo = default;
                return false;
            }
            
            if (canSendCpuImageRequest) {
                canSendCpuImageRequest = false;
                logCpuImages($"SendCpuImageRequest {type}");
                var request = new CpuImageRequest { type = type };
                if (acquireCpuImageBlocking) {
                    Assert.IsFalse(prevConversionParams.HasValue);
                    acquireCpuImageBlocking = false;
                    var blockingMessage = Connection.BlockUntilReceive<BlockingMessageContainer<CpuImageResponse>>(request).payload;
                    setCpuImage(blockingMessage.cpuImage);
                    blockingResponse = new BlockingMessageAndFrame<CpuImageResponse>(blockingMessage);
                } else {
                    Connection.Send(request);
                }
            } else {
                logCpuImages($"!canSendCpuImageRequest {type}");
            }
            
            if (cpuImage.HasValue) {
                logCpuImages($"TryAcquireCpuImage, nativeHandle: {dummyNativeHandleAndRequestId}");
                var image = cpuImage.Value;
                Assert.IsNull(planeDataArrays, $"{Constants.packageName}: please Dispose() the previous XRCpuImage before calling TryAcquireLatestCpuImage() again.");
                planeDataArrays = new Dictionary<int, NativeArray<byte>>();
                cameraImageCinfo = new CameraImageCinfo(dummyNativeHandleAndRequestId, new Vector2Int(image.width, image.height), image.planeCount, image.timestamp, image.format);
                return true;
            } else {
                cameraImageCinfo = default;
                return false;
            }
        }

        public void Receive(CpuImageResponse response) {
            Assert.AreEqual(response.type, type);
            logCpuImages($"Receive cpu image, type: {type} ({(int) type}), {response.cpuImage.ToString()}");
            setCpuImage(response.cpuImage);
        }

        void setCpuImage(XRCpuImageSerializable image) {
            cpuImage = image;
            canSendCpuImageRequest = true;
        }

        public override bool NativeHandleValid(int nativeHandle) {
            validateNativeHandle(nativeHandle);
            return true;
        }

        void validateNativeHandle(int nativeHandle) {
            Assert.AreNotEqual(nativeHandle, 0, "native handle should not be zero because XRCpuImage.Dispose() will quit early");
            Assert.AreEqual(dummyNativeHandleAndRequestId, nativeHandle, $"dummyNativeHandleAndRequestId: {dummyNativeHandleAndRequestId}, nativeHandle: {nativeHandle}");
        }

        public override unsafe bool TryGetPlane(int nativeHandle, int planeIndex, out CameraImagePlaneCinfo planeCinfo) {
            validateNativeHandle(nativeHandle);
            Assert.IsTrue(cpuImage.HasValue);
            var planes = cpuImage.Value.serializedPlanes;
            logCpuImages($"TryGetPlane, planeIndex: {planeIndex}, planes.Length: {planes.Length}, cpuImage: {cpuImage.Value.ToString()}");
            if (planes.Length == 0) {
                Debug.LogError($"{Constants.packageName}: please enable the '{ObjectNames.NicifyVariableName(nameof(Settings.Instance.arCompanionSettings.CPUImagePlaneMode))}' in the plugin's settings.");
                planeCinfo = default;
                return false;
            }
            
            Assert.IsTrue(planeIndex < planes.Length, $"Wrong plane index: {planeIndex}, total planes count: {planes.Length}");
            var maybePlane = planes[planeIndex];
            if (maybePlane.HasValue) {
                var plane = maybePlane.Value;
                var nativeArray = getPlaneData(plane, planeIndex);
                logCpuImages($"planeIndex: {planeIndex}, count: {nativeArray.Length}");
                planeCinfo = new CameraImagePlaneCinfo(new IntPtr(nativeArray.GetUnsafeReadOnlyPtr()), nativeArray.Length, plane.rowStride, plane.pixelStride);
                return true;
            } else {
                planeCinfo = default;
                return false;    
            }
        }

        NativeArray<byte> getPlaneData(XRCpuImagePlaneSerializable plane, int planeIndex) {
            var nativeArray = getExistingOrCreateNativeDataArray(plane, planeIndex);
            var sizeDiff = nativeArray.Length - plane.originalDataLength;
            switch (sizeDiff) {
                case 0:
                    return nativeArray;
                case 1:
                    #if UNITY_2019_2
                    Debug.LogWarning($"{Constants.packageName}: raw image plane data size is {nativeArray.Length} instead of the original size of {plane.originalDataLength}.");
                    return nativeArray;
                    #else
                    return nativeArray.GetSubArray(0, plane.originalDataLength);
                    #endif
                default:
                    throw new Exception();
            }
        }

        NativeArray<byte> getExistingOrCreateNativeDataArray(XRCpuImagePlaneSerializable plane, int planeIndex) {
            if (planeDataArrays.TryGetValue(planeIndex, out var nativeArray)) {
                return nativeArray;
            } else {
                var newArray = plane.getData(Allocator.Persistent);
                planeDataArrays[planeIndex] = newArray;
                return newArray;
            }
        }

        public override void DisposeImage(int nativeHandle) {
            validateNativeHandle(nativeHandle);
            Assert.IsNotNull(planeDataArrays);
            Assert.IsTrue(cpuImage.HasValue);
            logCpuImages($"DisposeImage, nativeHandle: {nativeHandle}");
            foreach (var _ in planeDataArrays.Values) {
                _.Dispose();
            }

            planeDataArrays.Clear();
            planeDataArrays = null;
            cpuImage = null;
            maybeConvertedImage = null;
            if (convertedData.HasValue) {
                Assert.IsTrue(convertedData.Value.IsCreated);
                convertedData.Value.Dispose();
                convertedData = null;
            }
        }

        public override bool TryGetConvertedDataSize(int nativeHandle, Vector2Int dimensions, TextureFormat format, out int size) {
            validateNativeHandle(nativeHandle);
            size = getConvertedDataSize(dimensions, format);
            return true;
        }

        static int getConvertedDataSize(Vector2Int dimensions, TextureFormat format) {
            var tex = new Texture2D(1, 1, format, false);
            var pixelSize = tex.GetRawTextureData().Length;
            var result = pixelSize * dimensions.x * dimensions.y;
            Object.Destroy(tex);
            return result;
        }

        /// <see cref="XRCpuImage.AsyncConversion"/>
        #region

        public override int ConvertAsync(int nativeHandle, XRCameraImageConversionParams conversionParams) {
            validateNativeHandle(nativeHandle);
            Assert.IsFalse(asyncConversionConversionParams.HasValue, $"{Constants.packageName}: please Dispose() the previous AsyncConversion before creating a new one.");
            asyncConversionConversionParams = conversionParams;
            sendConversionParams(conversionParams);
            var result = dummyNativeHandleAndRequestId;
            validateAsyncConversion(result);
            return result;
        }

        public override AsyncCameraImageConversionStatus GetAsyncRequestStatus(int requestId) {
            validateAsyncConversion(requestId);
            Assert.IsTrue(asyncConversionConversionParams.HasValue);
            var converted = tryGetConvertedImage(asyncConversionConversionParams.Value);
            return converted != null ? AsyncCameraImageConversionStatus.Ready : AsyncCameraImageConversionStatus.Pending;
        }

        public override unsafe bool TryGetAsyncRequestData(int requestId, out IntPtr dataPtr, out int dataLength) {
            validateAsyncConversion(requestId);
            if (maybeConvertedImage != null) {
                var bytes = maybeConvertedImage.bytes;
                Assert.IsFalse(convertedData.HasValue);
                var nativeArray = new NativeArray<byte>(bytes, Allocator.Persistent);
                convertedData = nativeArray;
                dataPtr = new IntPtr(nativeArray.GetUnsafeReadOnlyPtr());
                dataLength = bytes.Length;
                return true;
            }

            dataPtr = IntPtr.Zero;
            dataLength = 0;
            return true;
        }

        public override void DisposeAsyncRequest(int requestId) {
            validateAsyncConversion(requestId);
            asyncConversionConversionParams = null;
        }

        void validateAsyncConversion(int requestId) {
            Assert.AreEqual(dummyNativeHandleAndRequestId, requestId);
            Assert.IsTrue(asyncConversionConversionParams.HasValue);
        }

        #endregion

        public override bool TryConvert(int nativeHandle, XRCameraImageConversionParams conversionParams, IntPtr destinationBuffer, int bufferLength) {
            logCpuImages($"TryConvert, {conversionParams.AllFieldsAndPropsToString()}");
            validateNativeHandle(nativeHandle);
            Assert.AreEqual(bufferLength, getConvertedDataSize(conversionParams.outputDimensions, conversionParams.outputFormat));
            if (blockingResponse != null) {
                var payload = new CpuImageRequest {
                    type = type,
                    conversionParams = ConversionParamsSerializable.Create(conversionParams)
                };
                
                Connection.Instance.SendInstantly(new BlockingMessageContainer<CpuImageRequest>(blockingResponse.message.GetBlockingMessageGuid(), payload, out var payloadGuid));
                blockingResponse = null;
                maybeConvertedImage = Connection.Instance.BlockUntilReceive<ConvertedCpuImage>(payloadGuid);
            }
            
            sendConversionParams(conversionParams);
            var converted = tryGetConvertedImage(conversionParams);
            if (converted != null) {
                Marshal.Copy(converted.bytes, 0, destinationBuffer, bufferLength);
                return true;
            }

            throw new InvalidOperationException($"{Constants.packageName}: XRCpuImage.Convert() failed because the image is not yet received from AR Companion app. " +
                                                "Please try-catch the call to XRCpuImage.Convert(). Real XR providers can also throw exceptions here, so catching them is a good practice anyway.\n\n" +
                                                "XRCpuImage.GetConvertedDataSize() can also throw exceptions on real devices, so try-catching the XRCpuImage.GetConvertedDataSize() is also a good idea.\n");
        }

        public override unsafe void ConvertAsync(int nativeHandle, XRCameraImageConversionParams conversionParams, OnImageRequestCompleteDelegate callback, IntPtr context) {
            validateNativeHandle(nativeHandle);
            Assert.IsFalse(asyncConversionConversionParams.HasValue, $"{Constants.packageName}: AsyncConversion was running. The plugin supports only one conversion at a time.");
            sendConversionParams(conversionParams);
            var converted = tryGetConvertedImage(conversionParams);
            if (converted != null) {
                Assert.IsTrue(maybeConvertedImage != null);
                var bytes = maybeConvertedImage.bytes;
                using (var nativeArray = new NativeArray<byte>(bytes, Allocator.Temp)) {
                    callback(AsyncCameraImageConversionStatus.Ready,
                        conversionParams,
                        new IntPtr(nativeArray.GetUnsafeReadOnlyPtr()),
                        bytes.Length,
                        context
                    );
                }
            } else {
                callback(AsyncCameraImageConversionStatus.Failed, conversionParams, IntPtr.Zero, 0, context);
            }
        }

        void sendConversionParams(XRCameraImageConversionParams conversionParams) {
            var newParams = ConversionParamsSerializable.Create(conversionParams);
            if (!newParams.Equals(prevConversionParams)) {
                prevConversionParams = newParams;
                logCpuImages($"sendConversionParams: {newParams.Deserialize().AllFieldsAndPropsToString()}");
                Connection.Send(new CpuImageRequest {
                    type = type,
                    conversionParams = newParams
                });
            }
        }

        [CanBeNull]
        ConvertedCpuImage tryGetConvertedImage(XRCameraImageConversionParams conversionParams) {
            if (maybeConvertedImage != null) {
                var convertedImage = maybeConvertedImage;
                if (convertedImage.conversionParams.Deserialize() == conversionParams) {
                    return convertedImage;
                } else {
                    logCpuImages("convertedImage.conversionParams.Deserialize() != conversionParams");
                }
            } else {
                logCpuImages("maybeConvertedImage == null");
            }

            return null;
        }


        [Conditional("_")]
        internal static void logCpuImages(string msg) {
            Debug.Log($"frame {Time.frameCount}, {msg}");
        }

        public void Update() {
            unblockCompanionAppIfNewFrame();
        }

        void unblockCompanionAppIfNewFrame() {
            if (blockingResponse != null && blockingResponse.frame != Time.frameCount) {
                Connection.Instance.SendInstantly(new BlockingMessageContainer<CpuImageRequest>(blockingResponse.message.GetBlockingMessageGuid(), new CpuImageRequest(), out _));
                blockingResponse = null;
            }
        }


        class BlockingMessageAndFrame<T> where T: BlockingMessage {
            [NotNull] public readonly T message;
            public readonly int frame;
            
            public BlockingMessageAndFrame([NotNull] T msg) {
                message = msg;
                frame = Time.frameCount;
            }
        }
    }
}
#endif
