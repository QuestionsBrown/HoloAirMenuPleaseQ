#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using ARFoundationRemote.Editor;
using ARFoundationRemote.Runtime;
using JetBrains.Annotations;
using UnityEditor;
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.Networking;
using Debug = UnityEngine.Debug;


[InitializeOnLoad]
public static class GitRepoCheck {
    const string installerFolderName = "ARFoundationRemoteInstaller";
    static DirectoryInfo dataPathParent => Directory.GetParent(Application.dataPath);
    static char slash => Path.DirectorySeparatorChar;
    
    const string isRepoPrivateKey = "ARFoundationRemote_isRepoPublic";
    static bool isRepoPrivate {
        get => EditorPrefs.GetInt(isRepoPrivateKey, 0) == 1;
        set {
            log($"isRepoPrivate: {value}");
            EditorPrefs.SetInt(isRepoPrivateKey, value ? 1 : 0);
        }
    }


    static GitRepoCheck() {
        const string firstInitDoneKey = "ARFoundationRemote_FirstInitDone";
        if (!SessionState.GetBool(firstInitDoneKey, false)) {
            log("GitRepoCheck() first init");
            isRepoPrivate = false;
            SessionState.SetBool(firstInitDoneKey, true);
        }
    }
    
    public static void ExitPlaymodeIfRepoIsPublic(MonoBehaviour mb) {
        if (IsPluginAddedToIgnore() == false && !isRepoPrivate) {
            mb.StartCoroutine(exitPlaymodeIfRepoIsPublicCor());
        }
    }

    static IEnumerator exitPlaymodeIfRepoIsPublicCor() {
        log("exitPlaymodeIfRepoIsPublicCor()");
        var requests = getRemoteGitUrls().Select(startRepoCheckRequest).ToArray();
        while (requests.Any(_ => !_.isDone)) {
            yield return null;
        }

        isRepoPrivate = requests.All(_ => !isSuccess(_));
        if (!isRepoPrivate) {
            var msg = $"Your repository is public but the '{installerFolderName}' folder is not added to the ignore list! Please don't commit the plugin to public repositories!";
            EditorUtility.DisplayDialog(Constants.packageName, msg, "Ok");
            EditorApplication.isPlaying = false;
        }
        
        foreach (var _ in requests) {
            _.Dispose();
        }
    }

    static IEnumerable<string> getRemoteGitUrls() {
        var gitIgnoreFile = GetGitIgnoreFile();
        if (gitIgnoreFile == null) {
            return Enumerable.Empty<string>(); 
        }
        
        var configFilePath = $"{gitIgnoreFile.Directory}{slash}.git{slash}config";
        log(configFilePath);
        if (!File.Exists(configFilePath)) {
            log("file not exists");
            return Enumerable.Empty<string>(); 
        }

        var iniReader = new IniReader(configFilePath);
        log($"sections: {string.Join(", ", iniReader.GetSections())}");
        return iniReader
            .GetSections()
            .Where(_ => _.Contains("remote"))
            .Select(section => iniReader.GetValue("url", section))
            .Where(_ => !string.IsNullOrEmpty(_));
    }
    
    /// https://stackoverflow.com/a/54964584/1951038
    static bool isPublicRepoUrlBlocking(string url) {
        var request = startRepoCheckRequest(url);
        using (request) {
            var stopwatch = Stopwatch.StartNew();
            while (!request.isDone) {
                if (stopwatch.Elapsed > TimeSpan.FromSeconds(5)) {
                    throw new Exception("Git url check timeout. Please check internet connection.");
                }
            
                Thread.Sleep(100);
            }
        
            log($"responseCode:{request.responseCode}");
            return isSuccess(request);    
        }
    }

    static UnityWebRequest startRepoCheckRequest(string url) {
        var request = UnityWebRequest.Get($"{url}/info/refs?service=git-upload-pack");
        request.SendWebRequest();
        return request;
    }
    
    static bool isSuccess(UnityWebRequest request) {
        Assert.IsTrue(request.isDone);
        return request.responseCode == 200;
    }
    
    [Conditional("_")]
    static void log(string s) {
        Debug.Log(s);
    }

    public static void AddGitIgnore() {
        log("AddGitIgnore()");
        var gitIgnore = GetGitIgnoreFile();
        if (gitIgnore == null) {
            log("gitignore not found in any parent folder");
            return;
        }
        
        var path = gitIgnore.FullName;
        log($"gitignore found at path {path}");
        var lines = File.ReadAllLines(path).ToList();
        if (lines.All(_ => !_.Contains(installerFolderName))) {
            var insertIndex = string.IsNullOrEmpty(lines.Last().Trim()) ? lines.Count - 1 : lines.Count;
            lines.Insert(insertIndex, $"{installerFolderName}");
            File.WriteAllLines(path, lines);
        }
    }

    [CanBeNull]
    static FileInfo GetGitIgnoreFile() {
        var currentFolder = dataPathParent;
        while (true) {
            var path = $"{currentFolder}{slash}.gitignore";
            if (File.Exists(path)) {
                return new FileInfo(path);
            }

            currentFolder = currentFolder.Parent;
            if (currentFolder == null) {
                return null;
            }
        }
    }

    public static bool? IsPluginAddedToIgnore() {
        var ignoreFile = GetGitIgnoreFile();
        if (ignoreFile == null) {
            return null;
        }
        
        return File.ReadAllText(ignoreFile.FullName).Contains(installerFolderName);
    }

    public static bool RemovePluginFromGitIgnore() {
        log("IsPublicRepo()");
        if (getRemoteGitUrls().Any(isPublicRepoUrlBlocking)) {
            EditorUtility.DisplayDialog("Your repository is public!", 
                "Please don't commit the plugin to public repositories!", 
                "Ok");
            return false;
        }
        
        var response = EditorUtility.DisplayDialogComplex($"{Constants.packageName}", 
            "Have you purchased a plugin license for every team member who will use the plugin?", 
            "No, I need more licenses.", 
            "Yes, I've purchased a license for every team member.", 
            "More info.");
        switch (response) {
            case 0:
                Application.OpenURL(ReviewRequest.getStoreUrl());
                return false;
            case 1:
                var gitIgnore = GetGitIgnoreFile();
                if (gitIgnore == null) {
                    return true;
                }
                
                var path = gitIgnore.FullName;
                var lines = File.ReadAllLines(path).ToList();
                bool removed = false;
                for (int i = lines.Count - 1; i >= 0; i--) {
                    if (lines[i].Contains(installerFolderName)) {
                        lines.RemoveAt(i);
                        removed = true;
                    }
                }

                if (removed) {
                    File.WriteAllLines(path, lines);
                }
                
                return removed;
            case 2:
                Application.OpenURL("https://support.unity3d.com/hc/en-us/articles/208601846");
                return false;
            default:
                throw new Exception();
        }
    }
}
#endif
