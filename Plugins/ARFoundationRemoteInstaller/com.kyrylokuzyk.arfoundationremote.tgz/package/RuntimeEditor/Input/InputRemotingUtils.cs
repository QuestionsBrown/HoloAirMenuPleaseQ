#if UNITY_EDITOR
using ARFoundationRemote.Runtime;
using UnityEditor;
using UnityEngine;


namespace ARFoundationRemote.RuntimeEditor {
    public static class InputRemotingUtils {
        static bool loggedOnce;
        
        
        public static void CheckGameViewIsFocused() {
            if (!loggedOnce && getFocusedWindowTypeName() != "GameView") {
                Debug.LogError($"{Constants.packageName}: please focus Game View to simulate {InputHandlingData.oldInputManagerName} UI events in Editor.");
                loggedOnce = true;
            }
        }
        
        static string getFocusedWindowTypeName() {
            var focusedWindow = EditorWindow.focusedWindow;
            return focusedWindow != null ? focusedWindow.GetType().Name : "";
        }
    }
}
#endif
