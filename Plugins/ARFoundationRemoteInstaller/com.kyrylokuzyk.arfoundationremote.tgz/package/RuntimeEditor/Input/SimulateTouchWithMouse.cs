﻿#if UNITY_EDITOR
using System.Diagnostics;
using ARFoundationRemote.Runtime;
using UnityEngine;
using UnityEngine.Assertions;
using Debug = UnityEngine.Debug;


namespace ARFoundationRemote.RuntimeEditor {
    internal class SimulateTouchWithMouse {
        public static SimulateTouchWithMouse Instance { get; } = new SimulateTouchWithMouse();
        float lastUpdateTime = -1;
        Vector3 prevMousePos;
        Touch? prevTouch;

        
        public void UpdateSimulatedTouch() {
            Assert.IsTrue(Defines.isLegacyInputManagerEnabled);
            var currentTime = Time.time;
            if (currentTime != lastUpdateTime) {
                lastUpdateTime = currentTime;
                var curMousePos = UnityEngine.Input.mousePosition;
                var delta = curMousePos - prevMousePos;
                prevMousePos = curMousePos;
                var touch = createTouch(getPhase(delta), delta);
                if (!prevTouch.Equals(touch)) {
                    prevTouch = touch;
                    Input.simulatedMouseTouch = touch;
                    
                    #if AR_FOUNDATION_REMOTE_2_0_OR_NEWER
                    var payload = touch.HasValue ? new[] {TouchSerializable.Create(touch.Value)} : new TouchSerializable[0];
                    // Debug.Log($"record simulated touch {Time.time} {string.Join(", ", payload.Select(_ => _.AllFieldsAndPropsToString()))}");
                    Connection.TryRecordMessage(new LegacyInputData {
                        legacyTouches = payload
                    });
                    #endif
                }
            }
        }

        static TouchPhase? getPhase(Vector3 delta) {
            if (UnityEngine.Input.GetMouseButtonDown(0)) {
                if (UnityEngine.Input.GetMouseButtonUp(0)) {
                    Debug.LogError($"{Constants.packageName}: mouse button was pressed and released the same frame. It's not possible to simulate touch with mouse in this case.");
                    #if AR_FOUNDATION_REMOTE_2_0_OR_NEWER
                    if (Connection.receiverConnection is RecordingReceiverConnection recordingConnection) {
                        recordingConnection.OnError("session recording may be corrupted if mouse was over UI element while making a record.");
                    }

                    #endif
                    return null;
                }

                return TouchPhase.Began;
            } else if (UnityEngine.Input.GetMouseButton(0)) {
                Assert.IsFalse(UnityEngine.Input.GetMouseButtonUp(0));
                return delta.sqrMagnitude < 0.01f ? TouchPhase.Stationary : TouchPhase.Moved;
            } else if (UnityEngine.Input.GetMouseButtonUp(0)) {
                Assert.IsFalse(UnityEngine.Input.GetMouseButtonDown(0));
                return TouchPhase.Ended;
            }

            return null;
        }

        static Touch? createTouch(TouchPhase? phase, Vector3 delta) {
            if (!phase.HasValue) {
                return null;
            }

            var curMousePos = LegacyInputReceiver.Instance.mousePosFromOnGUIEvent;
            var touch = new Touch {
                phase = phase.Value,
                type = TouchType.Direct,
                position = curMousePos,
                rawPosition = curMousePos,
                fingerId = Constants.simulatedMouseFingerId,
                tapCount = 1,
                deltaTime = Time.deltaTime,
                deltaPosition = delta
            };
            
            LogTouch(touch, "fake");
            return touch;
        }

        [Conditional("_")]
        public static void LogTouch(Touch t, string s) {
            Debug.Log(s + t.fingerId + t.phase + t.position + $" {Time.time}");
        }
    }
}
#endif
