#if UNITY_2019_3_OR_NEWER
    using MeshId = UnityEngine.XR.MeshId;
#else
    using MeshGenerationResult = UnityEngine.Experimental.XR.MeshGenerationResult;
    using MeshId = UnityEngine.Experimental.XR.TrackableId;
    using XRMeshSubsystem = UnityEngine.Experimental.XR.XRMeshSubsystem;
    using XRMeshSubsystemDescriptor = UnityEngine.Experimental.XR.XRMeshSubsystemDescriptor;
    using MeshInfo = UnityEngine.Experimental.XR.MeshInfo;
    using MeshVertexAttributes = UnityEngine.Experimental.XR.MeshVertexAttributes;
#endif
using System;
using System.Collections.Generic;
using System.Diagnostics;
using JetBrains.Annotations;
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.XR;
using UnityEngine.XR.Management;
using Debug = UnityEngine.Debug;


namespace ARFoundationRemote.Runtime {
    public interface IXRMeshSubsystem : ISubsystem {
        /// clears infos after the first call so the second subsequent call in the same frame will always return empty List
        bool TryGetMeshInfos(List<MeshInfo> meshInfosOut);
        void GenerateMeshAsync(
            MeshId meshId,
            [NotNull] Mesh mesh,
            [CanBeNull] MeshCollider meshCollider,
            MeshVertexAttributes attributes,
            [NotNull] Action<MeshGenerationResult> onMeshGenerationComplete);
        float meshDensity { get; set; }
        bool SetBoundingVolume(Vector3 origin, Vector3 extents);
        
        #if UNITY_2021_2_OR_NEWER
        void GenerateMeshAsync(
            MeshId meshId,
            [NotNull] Mesh mesh,
            [CanBeNull] MeshCollider meshCollider,
            MeshVertexAttributes attributes,
            [NotNull] Action<MeshGenerationResult> onMeshGenerationComplete, 
            MeshGenerationOptions options
        );
        
        Unity.Collections.NativeArray<MeshTransform> GetUpdatedMeshTransforms(Unity.Collections.Allocator allocator);
        #endif
    }
    
    
    public class XRMeshSubsystemRemote : IXRMeshSubsystem {
        static IXRMeshSubsystem subsystemDelegate;

        
        public static void SetDelegate([NotNull] IXRMeshSubsystem del) {
            log("SetDelegate");
            Assert.IsNull(subsystemDelegate);
            subsystemDelegate = del;
        }

        public static void ClearDelegate() {
            log("ClearDelegate");
            Assert.IsNotNull(subsystemDelegate);
            subsystemDelegate = null;
        }

        bool IXRMeshSubsystem.TryGetMeshInfos(List<MeshInfo> meshInfosOut) {
            return subsystemDelegate.TryGetMeshInfos(meshInfosOut);
        }

        void IXRMeshSubsystem.GenerateMeshAsync(
            MeshId meshId,
            Mesh mesh,
            MeshCollider meshCollider,
            MeshVertexAttributes attributes,
            Action<MeshGenerationResult> onMeshGenerationComplete) {
            subsystemDelegate.GenerateMeshAsync(meshId, mesh, meshCollider, attributes, onMeshGenerationComplete);
        }

        float IXRMeshSubsystem.meshDensity {
            get => subsystemDelegate.meshDensity;
            set => subsystemDelegate.meshDensity = value;
        }

        bool IXRMeshSubsystem.SetBoundingVolume(Vector3 origin, Vector3 extents) {
            return subsystemDelegate.SetBoundingVolume(origin, extents);
        }

        void ISubsystem.Start() {
            subsystemDelegate.Start();
        }

        void ISubsystem.Stop() {
            subsystemDelegate.Stop();
        }

        void ISubsystem.Destroy() {
            subsystemDelegate.Destroy();
        }

        bool ISubsystem.running => subsystemDelegate.running;

        #if UNITY_2021_2_OR_NEWER
        void IXRMeshSubsystem.GenerateMeshAsync(
            MeshId meshId,
            Mesh mesh, 
            MeshCollider meshCollider, 
            MeshVertexAttributes attributes, 
            Action<MeshGenerationResult> onMeshGenerationComplete, 
            MeshGenerationOptions options) {
            subsystemDelegate.GenerateMeshAsync(meshId, mesh, meshCollider, attributes, onMeshGenerationComplete, options);
        }

        Unity.Collections.NativeArray<MeshTransform> IXRMeshSubsystem.GetUpdatedMeshTransforms(Unity.Collections.Allocator allocator) {
            return subsystemDelegate.GetUpdatedMeshTransforms(allocator);
        }
        #endif
        
        [Conditional("_")]
        static void log(string s) {
            Debug.Log(s);
        }
    }


    public class XRGeneralSettingsRemote {
        public static readonly XRGeneralSettingsRemote Instance = new XRGeneralSettingsRemote();

        public class _Manager {
            public readonly _Loader activeLoader = new _Loader();

            public class _Loader {
                [NotNull] 
                static readonly IXRMeshSubsystem subsystem = new XRMeshSubsystemRemote();

                [CanBeNull]
                public T GetLoadedSubsystem<T>() where T : class, IXRMeshSubsystem {
                    if (Application.isEditor) {
                        var result = subsystem as T;
                        Assert.IsNotNull(result);
                        return result;
                    } else {
                        throw new Exception();
                    }
                }
            }
        }

        public readonly _Manager Manager = new _Manager();

        [CanBeNull]
        public static XRMeshSubsystem GetRealSubsystem() {
            var xrGeneralSettings = XRGeneralSettings.Instance;
            if (xrGeneralSettings != null) {
                var manager = xrGeneralSettings.Manager;
                if (manager != null) {
                    // MeshSubsystemSender.Awake() can be called before Sender.Awake() 
                    manager.InitializeLoaderSyncIfNotInitialized();

                    var loader = manager.activeLoader;
                    if (loader != null) {
                        return loader.GetLoadedSubsystem<XRMeshSubsystem>();
                    }
                }
            }

            return null;
        }

        [CanBeNull]
        public static IXRMeshSubsystem GetMeshSubsystem() {
            return Instance.Manager.activeLoader.GetLoadedSubsystem<IXRMeshSubsystem>();
        }
    }


    public static class SubsystemManagerRemote {
        public static void GetSubsystemDescriptors(List<XRMeshSubsystemDescriptorRemote> sSubsystemDescriptors) {
            sSubsystemDescriptors.Clear();
            sSubsystemDescriptors.Add(new XRMeshSubsystemDescriptorRemote());
        }
    }

    public class XRMeshSubsystemDescriptorRemote {
        public string id { get; } = nameof(XRMeshSubsystemDescriptorRemote);

        public IXRMeshSubsystem Create() {
            return XRGeneralSettingsRemote.GetMeshSubsystem();
        }
    }
}
